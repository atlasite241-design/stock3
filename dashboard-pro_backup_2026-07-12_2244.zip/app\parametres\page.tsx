'use client'

import React, { useEffect, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Cloud,
  Database,
  FileDown,
  FileSpreadsheet,
  FileUp,
  Info,
  RefreshCcw,
  RotateCcw,
  Save,
  Store,
  Trash2,
} from 'lucide-react'
import AppShell from '@/components/AppShell'
import Modal from '@/components/Modal'
import { useToast } from '@/components/Toast'
import {
  createBackup,
  deleteBackup,
  exportAllJSON,
  exportProductsCSV,
  fmtDH,
  importAllJSON,
  listBackups,
  parseProductsCSV,
  resetDemoData,
  restoreBackup,
  useDroguerie,
  type Backup,
} from '@/lib/store'

function Content() {
  const { ready, products, sales, clients, suppliers, settings, importProducts, saveSettings } =
    useDroguerie()
  const toast = useToast()

  const [form, setForm] = useState(settings)
  const [resetOpen, setResetOpen] = useState(false)
  const [backups, setBackups] = useState<Backup[]>([])
  const [restoreTarget, setRestoreTarget] = useState<Backup | null>(null)
  const jsonInputRef = useRef<HTMLInputElement>(null)
  const csvInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (ready) {
      setForm(settings)
      setBackups(listBackups())
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready])

  if (!ready) {
    return <div className="flex h-64 items-center justify-center text-sm text-gray-400 dark:text-zinc-500">Chargement…</div>
  }

  const saveForm = () => {
    saveSettings({
      ...form,
      storeName: form.storeName.trim() || 'Droguerie Pro',
      tva: Math.max(0, Number(form.tva) || 0),
    })
    toast('✓ Paramètres enregistrés')
  }

  const doBackup = () => {
    createBackup(`Sauvegarde du ${new Date().toLocaleString('fr-FR')}`)
    setBackups(listBackups())
    toast('✓ Sauvegarde locale créée')
  }

  const doRestore = () => {
    if (!restoreTarget) return
    restoreBackup(restoreTarget)
    toast('✓ Sauvegarde restaurée')
    setRestoreTarget(null)
    setTimeout(() => window.location.reload(), 600)
  }

  const onImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => {
      if (importAllJSON(String(reader.result))) {
        toast('✓ Données importées — rechargement…')
        setTimeout(() => window.location.reload(), 600)
      } else {
        toast('Fichier de sauvegarde invalide', 'error')
      }
    }
    reader.readAsText(file)
    e.target.value = ''
  }

  const onImportCSV = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => {
      const rows = parseProductsCSV(String(reader.result))
      if (rows.length === 0) {
        toast('Aucun produit valide trouvé dans le fichier', 'error')
        return
      }
      const { added, updated } = importProducts(rows)
      toast(`✓ Import : ${added} ajoutés, ${updated} mis à jour`)
    }
    reader.readAsText(file)
    e.target.value = ''
  }

  const confirmReset = () => {
    resetDemoData()
    window.location.reload()
  }

  return (
    <>
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
        <h1 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-3xl">Paramètres</h1>
        <p className="mt-1 text-sm text-gray-500 dark:text-zinc-400">Boutique, TVA, import/export et sauvegardes.</p>
      </motion.div>

      <div className="grid gap-6 xl:grid-cols-2">
        {/* Store info */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05, duration: 0.4 }}
          className="glass-card p-6"
        >
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-50 dark:bg-amber-500/10 text-amber-500">
              <Store className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-gray-900 dark:text-white">Ma boutique</h2>
              <p className="text-xs text-gray-500 dark:text-zinc-400">Affiché sur les tickets et factures</p>
            </div>
          </div>

          <div className="mt-5 space-y-4">
            <div>
              <label className="field-label">Nom de la boutique</label>
              <input
                type="text"
                value={form.storeName}
                onChange={(e) => setForm({ ...form, storeName: e.target.value })}
                className="input-field"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="field-label">Téléphone</label>
                <input
                  type="tel"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  className="input-field"
                />
              </div>
              <div>
                <label className="field-label">TVA (%)</label>
                <input
                  type="number"
                  min="0"
                  value={form.tva}
                  onChange={(e) => setForm({ ...form, tva: Number(e.target.value) })}
                  className="input-field"
                />
              </div>
            </div>
            <div>
              <label className="field-label">Adresse</label>
              <input
                type="text"
                value={form.address}
                onChange={(e) => setForm({ ...form, address: e.target.value })}
                className="input-field"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="field-label">Devise</label>
                <input
                  type="text"
                  value={form.currency}
                  onChange={(e) => setForm({ ...form, currency: e.target.value })}
                  className="input-field"
                />
              </div>
              <div>
                <label className="field-label">Message du ticket</label>
                <input
                  type="text"
                  value={form.ticketMessage}
                  onChange={(e) => setForm({ ...form, ticketMessage: e.target.value })}
                  className="input-field"
                />
              </div>
            </div>
            <button onClick={saveForm} className="btn-primary w-full">
              <Save className="h-4 w-4" />
              Enregistrer les paramètres
            </button>
          </div>
        </motion.div>

        <div className="space-y-6">
          {/* Import / Export */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.4 }}
            className="glass-card p-6"
          >
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-sky-50 dark:bg-sky-500/10 text-sky-500 dark:text-sky-400">
                <FileSpreadsheet className="h-5 w-5" />
              </div>
              <div>
                <h2 className="text-base font-semibold text-gray-900 dark:text-white">Import / Export</h2>
                <p className="text-xs text-gray-500 dark:text-zinc-400">Excel / CSV et sauvegarde complète</p>
              </div>
            </div>

            <div className="mt-5 grid grid-cols-2 gap-3">
              <button onClick={() => exportProductsCSV(products)} className="btn-secondary">
                <FileDown className="h-4 w-4" />
                Export produits CSV
              </button>
              <button onClick={() => csvInputRef.current?.click()} className="btn-secondary">
                <FileUp className="h-4 w-4" />
                Import produits CSV
              </button>
              <button onClick={exportAllJSON} className="btn-secondary">
                <Database className="h-4 w-4" />
                Export complet JSON
              </button>
              <button onClick={() => jsonInputRef.current?.click()} className="btn-secondary">
                <FileUp className="h-4 w-4" />
                Import JSON
              </button>
            </div>
            <p className="mt-3 text-xs text-gray-400 dark:text-zinc-500">
              L&apos;import CSV met à jour les produits existants (par code-barres) et ajoute les nouveaux.
            </p>
            <input ref={csvInputRef} type="file" accept=".csv,text/csv" onChange={onImportCSV} className="hidden" />
            <input ref={jsonInputRef} type="file" accept=".json,application/json" onChange={onImportJSON} className="hidden" />
          </motion.div>

          {/* Backups */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15, duration: 0.4 }}
            className="glass-card p-6"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 dark:bg-emerald-500/10 text-emerald-500 dark:text-emerald-400">
                  <Cloud className="h-5 w-5" />
                </div>
                <div>
                  <h2 className="text-base font-semibold text-gray-900 dark:text-white">Sauvegardes</h2>
                  <p className="text-xs text-gray-500 dark:text-zinc-400">{backups.length}/5 sauvegardes locales</p>
                </div>
              </div>
              <button onClick={doBackup} className="btn-primary !h-9 text-xs">
                <Save className="h-3.5 w-3.5" />
                Sauvegarder
              </button>
            </div>

            <div className="mt-4 space-y-2">
              {backups.map((b) => (
                <div key={b.id} className="flex items-center gap-3 rounded-xl bg-gray-50/60 dark:bg-white/5 px-3 py-2.5">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white dark:bg-[#12121a] text-emerald-500 dark:text-emerald-400">
                    <Database className="h-4 w-4" />
                  </span>
                  <span className="min-w-0 flex-1 truncate text-sm font-medium text-gray-800 dark:text-zinc-100">
                    {new Date(b.date).toLocaleString('fr-FR')}
                  </span>
                  <button
                    onClick={() => setRestoreTarget(b)}
                    className="rounded-lg p-1.5 text-gray-400 dark:text-zinc-500 transition hover:bg-amber-50 hover:text-amber-600 dark:group-hover:text-white"
                    title="Restaurer"
                  >
                    <RotateCcw className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => {
                      deleteBackup(b.id)
                      setBackups(listBackups())
                    }}
                    className="rounded-lg p-1.5 text-gray-400 dark:text-zinc-500 transition hover:bg-rose-50 hover:text-rose-500 dark:group-hover:text-white"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
              {backups.length === 0 && (
                <p className="py-4 text-center text-xs text-gray-400 dark:text-zinc-500">Aucune sauvegarde locale</p>
              )}
            </div>

            <button onClick={() => setResetOpen(true)} className="btn-danger mt-4 w-full">
              <RefreshCcw className="h-4 w-4" />
              Réinitialiser les données de démonstration
            </button>
          </motion.div>
        </div>
      </div>

      {/* Stats + about */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.4 }}
        className="glass-card p-6"
      >
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gray-100 dark:bg-white/10 text-gray-500 dark:text-zinc-400">
            <Info className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-base font-semibold text-gray-900 dark:text-white">Droguerie Pro v2.0</h2>
            <p className="text-xs text-gray-500 dark:text-zinc-400">
              {products.length} produits · {sales.length} ventes · {clients.length} clients ·{' '}
              {suppliers.length} fournisseurs
            </p>
          </div>
        </div>
        <p className="mt-4 text-sm leading-relaxed text-gray-500 dark:text-zinc-400">
          Application complète de gestion pour droguerie : caisse tactile avec scanner code-barres et
          caméra, catalogue avec catégories/marques/unités, gestion du stock et inventaire, achats et
          fournisseurs, devis et factures avec TVA, journal de caisse, rapports, alertes et
          utilisateurs. Chiffre d&apos;affaires total enregistré :{' '}
          <span className="font-semibold text-gray-900 dark:text-white">
            {fmtDH(sales.reduce((a, s) => a + s.total, 0))}
          </span>
          . Toutes les données sont stockées localement dans votre navigateur.
        </p>
      </motion.div>

      {/* Restore confirm */}
      <Modal open={!!restoreTarget} onClose={() => setRestoreTarget(null)} title="Restaurer cette sauvegarde ?" maxWidth="max-w-sm">
        <p className="text-sm text-gray-600 dark:text-zinc-400">
          Les données actuelles seront remplacées par la sauvegarde du{' '}
          <span className="font-semibold text-gray-900 dark:text-white">
            {restoreTarget && new Date(restoreTarget.date).toLocaleString('fr-FR')}
          </span>
          .
        </p>
        <div className="mt-5 grid grid-cols-2 gap-3">
          <button onClick={() => setRestoreTarget(null)} className="btn-secondary">
            Annuler
          </button>
          <button onClick={doRestore} className="btn-primary">
            <RotateCcw className="h-4 w-4" />
            Restaurer
          </button>
        </div>
      </Modal>

      {/* Reset confirm */}
      <Modal open={resetOpen} onClose={() => setResetOpen(false)} title="Réinitialiser les données ?" maxWidth="max-w-sm">
        <p className="text-sm text-gray-600 dark:text-zinc-400">
          Toutes les données actuelles seront <span className="font-semibold text-rose-600 dark:text-rose-400">supprimées</span> et
          remplacées par les données de démonstration.
        </p>
        <div className="mt-5 grid grid-cols-2 gap-3">
          <button onClick={() => setResetOpen(false)} className="btn-secondary">
            Annuler
          </button>
          <button onClick={confirmReset} className="btn-danger">
            <RefreshCcw className="h-4 w-4" />
            Réinitialiser
          </button>
        </div>
      </Modal>
    </>
  )
}

export default function ParametresPage() {
  return (
    <AppShell>
      <Content />
    </AppShell>
  )
}
