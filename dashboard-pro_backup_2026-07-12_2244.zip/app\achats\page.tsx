'use client'

import React, { useState } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { Eye, Plus, Search, Trash2, Truck } from 'lucide-react'
import AppShell from '@/components/AppShell'
import Modal from '@/components/Modal'
import Select from '@/components/Select'
import { useToast } from '@/components/Toast'
import { fmtDH, useDroguerie, type Purchase, type PurchaseItem } from '@/lib/store'

const STATUS_META: Record<Purchase['status'], { label: string; chip: string }> = {
  en_attente: { label: 'En attente', chip: 'border-amber-200 dark:border-amber-500/20 bg-amber-50 dark:bg-amber-500/10 text-amber-700 dark:text-amber-300' },
  recue: { label: 'Reçue', chip: 'border-emerald-200 dark:border-emerald-500/20 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400' },
  retournee: { label: 'Retournée', chip: 'border-rose-200 dark:border-rose-500/20 bg-rose-50 dark:bg-rose-500/10 text-rose-700 dark:text-rose-400' },
}

function Content() {
  const { ready, products, suppliers, purchases, addPurchase } = useDroguerie()
  const toast = useToast()

  const [newOpen, setNewOpen] = useState(false)
  const [supplierId, setSupplierId] = useState('')
  const [lines, setLines] = useState<PurchaseItem[]>([])
  const [lineProduct, setLineProduct] = useState('')
  const [lineQty, setLineQty] = useState('10')
  const [detail, setDetail] = useState<Purchase | null>(null)
  const [query, setQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState('Tous')

  if (!ready) {
    return <div className="flex h-64 items-center justify-center text-sm text-gray-400 dark:text-zinc-500">Chargement…</div>
  }

  const visible = purchases
    .filter((p) => statusFilter === 'Tous' || STATUS_META[p.status].label === statusFilter)
    .filter((p) => {
      const q = query.trim().toLowerCase()
      return !q || p.ref.toLowerCase().includes(q) || p.supplierName.toLowerCase().includes(q)
    })

  const addLine = () => {
    const p = products.find((x) => x.id === lineProduct)
    if (!p) {
      toast('Choisissez un produit', 'error')
      return
    }
    const qty = Math.max(1, Math.round(parseFloat(lineQty.replace(',', '.')) || 0))
    setLines((ls) => {
      const ex = ls.find((l) => l.productId === p.id)
      return ex
        ? ls.map((l) => (l.productId === p.id ? { ...l, qty: l.qty + qty } : l))
        : [...ls, { productId: p.id, name: p.name, cost: p.cost, qty }]
    })
    setLineProduct('')
    setLineQty('10')
  }

  const linesTotal = lines.reduce((a, l) => a + l.cost * l.qty, 0)

  const createOrder = () => {
    if (!supplierId) {
      toast('Choisissez un fournisseur', 'error')
      return
    }
    if (lines.length === 0) {
      toast('Ajoutez au moins un produit', 'error')
      return
    }
    const po = addPurchase(supplierId, lines)
    toast(`✓ Commande ${po?.ref ?? ''} créée`)
    setNewOpen(false)
    setLines([])
    setSupplierId('')
  }

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex flex-wrap items-end justify-between gap-4"
      >
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-3xl">Bons de commande</h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-zinc-400">Créez et suivez vos commandes fournisseurs.</p>
        </div>
        <button onClick={() => setNewOpen(true)} className="btn-primary">
          <Plus className="h-4 w-4" />
          Nouvelle commande
        </button>
      </motion.div>

      <div className="flex flex-wrap items-center gap-3">
        <div className="relative min-w-[220px] flex-1 sm:max-w-xs">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Référence ou fournisseur…"
            className="input-field pl-10"
          />
        </div>
        <Select
          value={statusFilter}
          onChange={setStatusFilter}
          options={['Tous', 'En attente', 'Reçue', 'Retournée']}
          className="w-auto min-w-[180px]"
        />
      </div>

      {/* Table */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.4 }}
        className="glass-card overflow-hidden"
      >
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px]">
            <thead>
              <tr className="border-b border-gray-100 dark:border-white/10 text-left text-[11px] font-bold uppercase tracking-wider text-gray-400 dark:text-zinc-500">
                <th className="px-5 py-3.5">Référence</th>
                <th className="px-5 py-3.5">Fournisseur</th>
                <th className="px-5 py-3.5">Articles</th>
                <th className="px-5 py-3.5">Total</th>
                <th className="px-5 py-3.5">Statut</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {visible.map((p) => (
                <tr key={p.id} className="group border-b border-gray-50 dark:border-white/5 transition-colors hover:bg-amber-50/40 dark:hover:bg-white/5">
                  <td className="px-5 py-3.5">
                    <p className="text-sm font-bold text-gray-900 dark:text-white">{p.ref}</p>
                    <p className="text-xs text-gray-400 dark:text-zinc-500">
                      {new Date(p.date).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short' })}
                    </p>
                  </td>
                  <td className="px-5 py-3.5 text-sm text-gray-700 dark:text-zinc-300">{p.supplierName}</td>
                  <td className="px-5 py-3.5 text-sm text-gray-600 dark:text-zinc-400 tabular-nums">
                    {p.items.reduce((a, i) => a + i.qty, 0)}
                  </td>
                  <td className="px-5 py-3.5 text-sm font-bold text-gray-900 dark:text-white tabular-nums">{fmtDH(p.total)}</td>
                  <td className="px-5 py-3.5">
                    <span className={`rounded-lg border px-2 py-1 text-xs font-bold ${STATUS_META[p.status].chip}`}>
                      {STATUS_META[p.status].label}
                    </span>
                  </td>
                  <td className="px-5 py-3.5">
                    <div className="flex items-center justify-end gap-1">
                      {p.status === 'en_attente' && (
                        <Link href="/achats/reception" className="btn-secondary !h-8 !px-2.5 text-xs">
                          <Truck className="h-3.5 w-3.5" />
                          Réceptionner
                        </Link>
                      )}
                      <button
                        onClick={() => setDetail(p)}
                        className="rounded-lg p-2 text-gray-400 dark:text-zinc-500 transition hover:bg-amber-50 hover:text-amber-600 dark:group-hover:text-white"
                        title="Détails"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {visible.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-5 py-10 text-center text-sm text-gray-400 dark:text-zinc-500">
                    Aucune commande dans cette vue
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* New order modal */}
      <Modal open={newOpen} onClose={() => setNewOpen(false)} title="Nouvelle commande fournisseur" maxWidth="max-w-xl">
        <div className="space-y-4">
          <div>
            <label className="field-label">Fournisseur *</label>
            <Select
              value={supplierId}
              onChange={setSupplierId}
              placeholder="— Choisir —"
              options={[{ value: '', label: '— Choisir —' }, ...suppliers.map((s) => ({ value: s.id, label: s.name }))]}
            />
          </div>

          <div>
            <label className="field-label">Ajouter des produits</label>
            <div className="flex gap-2">
              <Select
                value={lineProduct}
                onChange={setLineProduct}
                placeholder="— Produit —"
                className="flex-1"
                options={[
                  { value: '', label: '— Produit —' },
                  ...products.map((p) => ({ value: p.id, label: `${p.name} (achat : ${fmtDH(p.cost)})` })),
                ]}
              />
              <input
                type="number"
                min="1"
                value={lineQty}
                onChange={(e) => setLineQty(e.target.value)}
                className="input-field w-24"
              />
              <button onClick={addLine} className="btn-secondary shrink-0 !px-3">
                <Plus className="h-4 w-4" />
              </button>
            </div>
          </div>

          {lines.length > 0 && (
            <div className="space-y-1.5">
              {lines.map((l) => (
                <div key={l.productId} className="flex items-center gap-3 rounded-xl bg-gray-50 dark:bg-white/5 px-3 py-2">
                  <span className="flex-1 text-sm font-medium text-gray-800 dark:text-zinc-100">{l.name}</span>
                  <span className="text-xs text-gray-500 dark:text-zinc-400 tabular-nums">
                    {l.qty} × {fmtDH(l.cost)}
                  </span>
                  <span className="text-sm font-bold text-gray-900 dark:text-white tabular-nums">{fmtDH(l.qty * l.cost)}</span>
                  <button
                    onClick={() => setLines(lines.filter((x) => x.productId !== l.productId))}
                    className="rounded p-1 text-gray-400 dark:text-zinc-500 hover:bg-rose-50 hover:text-rose-500"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
              <div className="flex justify-between rounded-xl bg-gradient-to-r from-amber-50 dark:from-amber-500/10 to-yellow-50 dark:to-yellow-500/5 px-3 py-2.5">
                <span className="text-sm font-semibold text-gray-600 dark:text-zinc-400">Total commande</span>
                <span className="text-base font-bold text-gray-900 dark:text-white tabular-nums">{fmtDH(linesTotal)}</span>
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3 pt-1">
            <button onClick={() => setNewOpen(false)} className="btn-secondary">
              Annuler
            </button>
            <button onClick={createOrder} className="btn-primary">
              <Truck className="h-4 w-4" />
              Créer la commande
            </button>
          </div>
        </div>
      </Modal>

      {/* Detail modal */}
      <Modal open={!!detail} onClose={() => setDetail(null)} title={`Commande ${detail?.ref ?? ''}`} maxWidth="max-w-sm">
        {detail && (
          <>
            <p className="text-xs text-gray-500 dark:text-zinc-400">
              {new Date(detail.date).toLocaleString('fr-FR')} — {detail.supplierName}
            </p>
            <div className="mt-3 space-y-2">
              {detail.items.map((i) => (
                <div key={i.productId} className="flex items-center justify-between gap-3 rounded-xl bg-gray-50 dark:bg-white/5 px-3 py-2.5">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-gray-900 dark:text-white">{i.name}</p>
                    <p className="text-xs text-gray-500 dark:text-zinc-400 tabular-nums">
                      {i.qty} × {fmtDH(i.cost)}
                    </p>
                  </div>
                  <p className="shrink-0 text-sm font-bold text-gray-900 dark:text-white tabular-nums">{fmtDH(i.cost * i.qty)}</p>
                </div>
              ))}
            </div>
            <div className="mt-4 space-y-1 rounded-xl bg-gradient-to-r from-amber-50 dark:from-amber-500/10 to-yellow-50 dark:to-yellow-500/5 p-4">
              <div className="flex justify-between text-sm text-gray-600 dark:text-zinc-400">
                <span>Statut</span>
                <span className="font-semibold">{STATUS_META[detail.status].label}</span>
              </div>
              <div className="flex justify-between text-sm text-gray-600 dark:text-zinc-400">
                <span>Payé</span>
                <span className="font-semibold tabular-nums">{fmtDH(detail.paid)}</span>
              </div>
              <div className="flex justify-between pt-1 text-base font-bold text-gray-900 dark:text-white">
                <span>Total</span>
                <span className="tabular-nums">{fmtDH(detail.total)}</span>
              </div>
            </div>
          </>
        )}
      </Modal>
    </>
  )
}

export default function AchatsPage() {
  return (
    <AppShell>
      <Content />
    </AppShell>
  )
}
