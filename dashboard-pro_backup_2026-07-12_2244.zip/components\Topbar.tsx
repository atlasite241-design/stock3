'use client'

import React, { useEffect, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { AlertTriangle, Bell, Menu, Moon, Search, Settings, Sun } from 'lucide-react'
import { loadProducts, type Product } from '@/lib/store'
import type { Theme } from '@/lib/theme'

export default function Topbar({
  onMenuClick,
  theme,
  onToggleTheme,
}: {
  onMenuClick: () => void
  theme: Theme
  onToggleTheme: () => void
}) {
  const router = useRouter()
  const [query, setQuery] = useState('')
  const [bellOpen, setBellOpen] = useState(false)
  const [lowStock, setLowStock] = useState<Product[]>([])

  useEffect(() => {
    setLowStock(loadProducts().filter((p) => p.stock <= p.minStock))
  }, [])

  const submitSearch = () => {
    const q = query.trim()
    if (q) {
      setQuery('')
      router.push(`/produits?q=${encodeURIComponent(q)}`)
    }
  }

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-gray-200 bg-white/80 px-4 backdrop-blur-xl dark:border-white/10 dark:bg-[#0a0a0f]/80 sm:px-6 lg:px-8">
      <button
        onClick={onMenuClick}
        className="rounded-xl p-2 text-gray-500 transition hover:bg-gray-100 hover:text-gray-900 dark:text-zinc-400 dark:hover:bg-white/5 dark:hover:text-white lg:hidden"
      >
        <Menu className="h-5 w-5" />
      </button>

      {/* Search */}
      <div className="relative hidden max-w-md flex-1 sm:block">
        <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400 dark:text-zinc-500" />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && submitSearch()}
          placeholder="Rechercher un produit… (Entrée)"
          className="h-10 w-full rounded-xl border border-gray-200 bg-gray-50 pl-10 pr-4 text-sm text-gray-900 placeholder-gray-400 outline-none transition focus:border-amber-400 focus:bg-white focus:ring-2 focus:ring-amber-400/25 dark:border-white/10 dark:bg-white/5 dark:text-white dark:placeholder-zinc-500 dark:focus:bg-white/[0.08]"
        />
      </div>

      <div className="ml-auto flex items-center gap-1.5">
        {/* Theme toggle */}
        <button
          onClick={onToggleTheme}
          className="rounded-xl p-2.5 text-gray-500 transition hover:bg-gray-100 hover:text-gray-900 dark:text-zinc-400 dark:hover:bg-white/5 dark:hover:text-white"
          title={theme === 'dark' ? 'Passer en mode clair' : 'Passer en mode sombre'}
        >
          {theme === 'dark' ? <Sun className="h-[18px] w-[18px]" /> : <Moon className="h-[18px] w-[18px]" />}
        </button>

        {/* Notifications */}
        <div className="relative">
          <button
            onClick={() => setBellOpen((o) => !o)}
            className="relative rounded-xl p-2.5 text-gray-500 transition hover:bg-gray-100 hover:text-gray-900 dark:text-zinc-400 dark:hover:bg-white/5 dark:hover:text-white"
          >
            <Bell className="h-[18px] w-[18px]" />
            {lowStock.length > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-rose-500 px-1 text-[9px] font-bold text-white">
                {lowStock.length}
              </span>
            )}
          </button>

          {bellOpen && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setBellOpen(false)} />
              <div className="absolute right-0 top-12 z-50 w-80 rounded-2xl border border-gray-200 bg-white p-2 shadow-xl dark:border-white/10 dark:bg-[#12121a]">
                <p className="px-3 py-2 text-xs font-bold uppercase tracking-wider text-gray-400 dark:text-zinc-500">
                  Alertes stock ({lowStock.length})
                </p>
                {lowStock.length === 0 ? (
                  <p className="px-3 pb-3 text-sm text-gray-500 dark:text-zinc-400">Aucune alerte — tout va bien ✓</p>
                ) : (
                  <div className="max-h-72 overflow-y-auto">
                    {lowStock.slice(0, 6).map((p) => (
                      <Link
                        key={p.id}
                        href="/stock"
                        onClick={() => setBellOpen(false)}
                        className="flex items-center gap-3 rounded-xl px-3 py-2.5 transition hover:bg-amber-50 dark:hover:bg-amber-500/10"
                      >
                        <span className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${p.stock === 0 ? 'bg-rose-50 text-rose-500 dark:bg-rose-500/10' : 'bg-amber-50 text-amber-500 dark:bg-amber-500/10'}`}>
                          <AlertTriangle className="h-4 w-4" />
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-sm font-medium text-gray-900 dark:text-white">{p.name}</span>
                          <span className="block text-xs text-gray-500 dark:text-zinc-400">
                            {p.stock === 0 ? 'Rupture de stock' : `${p.stock} restants (min. ${p.minStock})`}
                          </span>
                        </span>
                      </Link>
                    ))}
                  </div>
                )}
                <Link
                  href="/stock"
                  onClick={() => setBellOpen(false)}
                  className="mt-1 block rounded-xl bg-gray-50 px-3 py-2.5 text-center text-xs font-bold text-gray-700 transition hover:bg-amber-50 hover:text-amber-700 dark:bg-white/5 dark:text-zinc-300 dark:hover:bg-amber-500/10 dark:hover:text-amber-400"
                >
                  Gérer le stock →
                </Link>
              </div>
            </>
          )}
        </div>

        <Link
          href="/parametres"
          className="rounded-xl p-2.5 text-gray-500 transition hover:bg-gray-100 hover:text-gray-900 dark:text-zinc-400 dark:hover:bg-white/5 dark:hover:text-white"
        >
          <Settings className="h-[18px] w-[18px]" />
        </Link>

        <div className="mx-2 h-6 w-px bg-gray-200 dark:bg-white/10" />

        <Link
          href="/parametres"
          className="flex items-center gap-3 rounded-xl p-1.5 transition hover:bg-gray-100 dark:hover:bg-white/5 sm:pr-3"
        >
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-amber-400 to-yellow-500 text-xs font-bold text-gray-900">
            YA
          </div>
          <div className="hidden text-left sm:block">
            <p className="text-[13px] font-semibold leading-tight text-gray-900 dark:text-white">Yassir A.</p>
            <p className="text-[11px] leading-tight text-gray-500 dark:text-zinc-400">Gérant</p>
          </div>
        </Link>
      </div>
    </header>
  )
}
