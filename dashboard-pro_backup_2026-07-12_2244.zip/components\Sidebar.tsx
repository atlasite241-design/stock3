'use client'

import React, { useEffect, useState } from 'react'
import Link from 'next/link'
import { usePathname, useSearchParams } from 'next/navigation'
import type { LucideIcon } from 'lucide-react'
import {
  BarChart3,
  Bell,
  Boxes,
  ChevronDown,
  Coins,
  LayoutDashboard,
  Monitor,
  Package,
  Settings,
  ShoppingCart,
  Store,
  Truck,
  UserCog,
  Users,
  Wallet,
  X,
} from 'lucide-react'

interface NavChild {
  href: string
  label: string
}

interface NavItem {
  label: string
  icon: LucideIcon
  href?: string
  children?: NavChild[]
}

const NAV: NavItem[] = [
  { label: 'Tableau de bord', icon: LayoutDashboard, href: '/' },
  {
    label: 'Point de vente (POS)',
    icon: Monitor,
    children: [
      { href: '/caisse', label: 'Nouvelle vente (POS tactile)' },
      { href: '/caisse?suspend=1', label: 'Suspendre une vente' },
      { href: '/caisse?resume=1', label: 'Reprendre une vente' },
    ],
  },
  {
    label: 'Produits',
    icon: Package,
    children: [
      { href: '/produits', label: 'Produits' },
      { href: '/produits/categories', label: 'Catégories' },
      { href: '/produits/marques', label: 'Marques' },
      { href: '/produits/unites', label: 'Unités' },
      { href: '/produits/codes-barres', label: 'Codes-barres' },
    ],
  },
  {
    label: 'Stock',
    icon: Boxes,
    children: [
      { href: '/stock', label: 'Stock actuel' },
      { href: '/stock/mouvements?type=entree', label: 'Entrées' },
      { href: '/stock/mouvements?type=sortie', label: 'Sorties' },
      { href: '/stock/mouvements?type=ajustement', label: 'Ajustements' },
      { href: '/stock/inventaire', label: 'Inventaire' },
      { href: '/stock/mouvements', label: 'Historique' },
    ],
  },
  {
    label: 'Achats',
    icon: Truck,
    children: [
      { href: '/achats', label: 'Bons de commande' },
      { href: '/achats/reception', label: 'Réception marchandise' },
      { href: '/achats/factures', label: 'Factures fournisseurs' },
      { href: '/achats/retours', label: 'Retours fournisseurs' },
      { href: '/achats/historique', label: 'Historique des achats' },
      { href: '/achats/paiements', label: 'Paiements fournisseurs' },
    ],
  },
  {
    label: 'Ventes',
    icon: ShoppingCart,
    children: [
      { href: '/ventes/devis', label: 'Devis' },
      { href: '/ventes/bon-livraison', label: 'Bon de livraison' },
      { href: '/ventes/factures', label: 'Factures' },
      { href: '/ventes/retours', label: 'Retours clients' },
      { href: '/ventes/avoirs', label: 'Avoirs' },
      { href: '/ventes', label: 'Historique des ventes' },
    ],
  },
  {
    label: 'Clients',
    icon: Users,
    children: [
      { href: '/clients', label: 'Liste' },
      { href: '/clients/nouveau', label: 'Nouveau client' },
      { href: '/clients/historique', label: 'Historique' },
      { href: '/clients/credits', label: 'Crédits' },
      { href: '/clients/paiements', label: 'Paiements' },
      { href: '/clients/fidelite', label: 'Fidélité' },
    ],
  },
  {
    label: 'Fournisseurs',
    icon: Truck,
    children: [
      { href: '/fournisseurs', label: 'Liste fournisseur' },
      { href: '/fournisseurs/nouveau', label: 'Nouveau fournisseur' },
      { href: '/fournisseurs/historique', label: 'Historique' },
      { href: '/achats/paiements', label: 'Paiements' },
      { href: '/fournisseurs/soldes', label: 'Soldes' },
    ],
  },
  {
    label: 'Caisse',
    icon: Wallet,
    children: [
      { href: '/caisse-journal?action=open', label: 'Ouverture' },
      { href: '/caisse-journal?action=close', label: 'Fermeture' },
      { href: '/depenses', label: 'Dépenses' },
      { href: '/caisse-journal?action=recette', label: 'Recettes' },
      { href: '/caisse-journal?action=transfert', label: 'Transfert' },
      { href: '/caisse-journal', label: 'Journal de caisse' },
    ],
  },
  { label: 'Rapports', icon: BarChart3, href: '/rapports' },
  { label: 'Alertes', icon: Bell, href: '/alertes' },
  { label: 'Utilisateurs', icon: UserCog, href: '/utilisateurs' },
  { label: 'Paramètres', icon: Settings, href: '/parametres' },
]

const basePath = (href: string) => href.split('?')[0]

export default function Sidebar({ open, onClose }: { open: boolean; onClose: () => void }) {
  const pathname = usePathname()
  const searchParams = useSearchParams()
  const currentFull = searchParams.toString() ? `${pathname}?${searchParams.toString()}` : pathname
  const [expanded, setExpanded] = useState<string[]>([])
  const [cartCount, setCartCount] = useState(0)

  useEffect(() => {
    const read = () => setCartCount(Number(sessionStorage.getItem('dp_cart_count') ?? '0'))
    read()
    window.addEventListener('droguerie-cart-change', read)
    return () => window.removeEventListener('droguerie-cart-change', read)
  }, [])

  // Auto-expand the group containing the current page
  useEffect(() => {
    const group = NAV.find((n) => n.children?.some((c) => basePath(c.href) === pathname))
    if (group && !expanded.includes(group.label)) {
      setExpanded((e) => [...e, group.label])
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname])

  const toggle = (label: string) =>
    setExpanded((e) => (e.includes(label) ? e.filter((x) => x !== label) : [...e, label]))

  const groupActive = (item: NavItem) =>
    item.children?.some((c) => basePath(c.href) === pathname) ?? false

  return (
    <>
      {open && (
        <div className="fixed inset-0 z-40 bg-gray-900/40 backdrop-blur-sm lg:hidden" onClick={onClose} />
      )}

      <aside
        className={`fixed inset-y-0 left-0 z-50 flex w-64 flex-col border-r border-gray-200 bg-white transition-transform duration-300 dark:border-white/10 dark:bg-[#0d0d14] ${
          open ? 'translate-x-0' : '-translate-x-full'
        } lg:translate-x-0`}
      >
        {/* Logo */}
        <div className="flex h-16 shrink-0 items-center justify-between border-b border-gray-100 px-5 dark:border-white/10">
          <Link href="/" className="flex items-center gap-3" onClick={onClose}>
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 to-yellow-500 shadow-lg shadow-amber-400/30">
              <Store className="h-4 w-4 text-gray-900" />
            </div>
            <span className="text-[15px] font-bold tracking-tight text-gray-900 dark:text-white">
              Droguerie{' '}
              <span className="bg-gradient-to-r from-amber-500 to-yellow-600 bg-clip-text text-transparent">
                Pro
              </span>
            </span>
          </Link>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-gray-400 transition hover:bg-gray-100 hover:text-gray-700 dark:text-zinc-500 dark:hover:bg-white/5 dark:hover:text-white lg:hidden"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto px-3 py-4">
          <div className="space-y-1">
            {NAV.map((item) => {
              if (!item.children) {
                const active = pathname === item.href
                return (
                  <Link
                    key={item.label}
                    href={item.href!}
                    onClick={onClose}
                    className={
                      active
                        ? 'group flex items-center gap-3 rounded-xl border border-amber-200 bg-amber-50 px-3 py-2.5 text-sm font-semibold text-amber-900 dark:border-amber-500/20 dark:bg-amber-500/10 dark:text-amber-300'
                        : 'group flex items-center gap-3 rounded-xl border border-transparent px-3 py-2.5 text-sm font-medium text-gray-500 transition-colors hover:bg-gray-50 hover:text-gray-900 dark:text-zinc-400 dark:hover:bg-white/5 dark:hover:text-white'
                    }
                  >
                    <item.icon
                      className={`h-[18px] w-[18px] ${
                        active
                          ? 'text-amber-500'
                          : 'text-gray-400 transition-colors group-hover:text-gray-600 dark:text-zinc-500 dark:group-hover:text-zinc-300'
                      }`}
                    />
                    <span className="flex-1">{item.label}</span>
                  </Link>
                )
              }

              const isOpen = expanded.includes(item.label)
              const active = groupActive(item)
              return (
                <div key={item.label}>
                  <button
                    onClick={() => toggle(item.label)}
                    className={`group flex w-full items-center gap-3 rounded-xl border px-3 py-2.5 text-sm transition-colors ${
                      active
                        ? 'border-amber-200 bg-amber-50 font-semibold text-amber-900 dark:border-amber-500/20 dark:bg-amber-500/10 dark:text-amber-300'
                        : 'border-transparent font-medium text-gray-500 hover:bg-gray-50 hover:text-gray-900 dark:text-zinc-400 dark:hover:bg-white/5 dark:hover:text-white'
                    }`}
                  >
                    <item.icon
                      className={`h-[18px] w-[18px] ${
                        active
                          ? 'text-amber-500'
                          : 'text-gray-400 transition-colors group-hover:text-gray-600 dark:text-zinc-500 dark:group-hover:text-zinc-300'
                      }`}
                    />
                    <span className="flex-1 text-left">{item.label}</span>
                    <ChevronDown
                      className={`h-4 w-4 text-gray-400 transition-transform dark:text-zinc-500 ${isOpen ? 'rotate-180' : ''}`}
                    />
                  </button>
                  {isOpen && (
                    <div className="ml-[26px] mt-1 space-y-0.5 border-l border-gray-100 pl-3 dark:border-white/10">
                      {item.children.map((c) => {
                        const childActive = c.href === currentFull
                        const disabled =
                          (c.label === 'Suspendre une vente' && cartCount === 0) ||
                          (c.label === 'Reprendre une vente' && cartCount > 0)

                        if (disabled) {
                          return (
                            <span
                              key={c.href + c.label}
                              title={c.label === 'Suspendre une vente' ? 'Le panier est vide' : 'Videz ou suspendez le panier actuel avant de reprendre une vente'}
                              className="block cursor-not-allowed rounded-lg px-3 py-2 text-[13px] font-medium text-gray-300 dark:text-zinc-600"
                            >
                              {c.label}
                            </span>
                          )
                        }

                        return (
                          <Link
                            key={c.href + c.label}
                            href={c.href}
                            onClick={onClose}
                            className={`block rounded-lg px-3 py-2 text-[13px] transition-colors ${
                              childActive
                                ? 'bg-amber-50 font-semibold text-amber-800 dark:bg-amber-500/10 dark:text-amber-300'
                                : 'font-medium text-gray-500 hover:bg-gray-50 hover:text-gray-900 dark:text-zinc-400 dark:hover:bg-white/5 dark:hover:text-white'
                            }`}
                          >
                            {c.label}
                          </Link>
                        )
                      })}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </nav>

        {/* Footer card */}
        <div className="shrink-0 p-4">
          <div className="relative overflow-hidden rounded-2xl border border-amber-200 bg-gradient-to-br from-amber-50 to-yellow-50 p-4 dark:border-amber-500/20 dark:from-amber-500/10 dark:to-yellow-500/[0.04]">
            <div className="absolute -right-6 -top-6 h-20 w-20 rounded-full bg-amber-200/50 blur-2xl dark:bg-amber-500/10" />
            <Coins className="h-5 w-5 text-amber-500" />
            <p className="mt-2 text-sm font-bold text-gray-900 dark:text-white">Droguerie Pro</p>
            <p className="mt-1 text-xs leading-relaxed text-gray-500 dark:text-zinc-400">
              Gestion complète : caisse, stock, achats &amp; rapports.
            </p>
          </div>
        </div>
      </aside>
    </>
  )
}
