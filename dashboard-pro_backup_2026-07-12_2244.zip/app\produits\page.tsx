'use client'

import React, { useEffect, useMemo, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import { Camera, Package, Pencil, Plus, Printer, Search, Trash2, Wand2 } from 'lucide-react'
import AppShell from '@/components/AppShell'
import Modal from '@/components/Modal'
import CameraScanner from '@/components/CameraScanner'
import { generateEan13 } from '@/components/EAN13'
import Select from '@/components/Select'
import { useToast } from '@/components/Toast'
import { exportProductsCSV, fmtDH, useDroguerie, type Product } from '@/lib/store'

const EMPTY_FORM = {
  name: '',
  barcode: '',
  category: '',
  brand: '',
  unit: 'Pièce',
  price: '',
  cost: '',
  stock: '',
  minStock: '5',
}

function ProduitsContent() {
  const { ready, products, categories, brands, units, addProduct, updateProduct, deleteProduct } =
    useDroguerie()
  const toast = useToast()

  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('Tous')
  const [modalOpen, setModalOpen] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [form, setForm] = useState(EMPTY_FORM)
  const [deleteTarget, setDeleteTarget] = useState<Product | null>(null)
  const [cameraOpen, setCameraOpen] = useState(false)
  const urlConsumed = useRef(false)

  useEffect(() => {
    if (urlConsumed.current) return
    urlConsumed.current = true
    const sp = new URLSearchParams(window.location.search)
    const q = sp.get('q')
    if (q) setQuery(q)
    if (sp.get('new') === '1') {
      setEditingId(null)
      const barcode = sp.get('barcode')
      setForm(barcode ? { ...EMPTY_FORM, barcode } : EMPTY_FORM)
      setModalOpen(true)
    }
  }, [])

  const catFilters = useMemo(
    () => ['Tous', ...Array.from(new Set(products.map((p) => p.category)))],
    [products]
  )

  const filtered = products.filter((p) => {
    const okCat = category === 'Tous' || p.category === category
    const q = query.trim().toLowerCase()
    const okQuery =
      !q || p.name.toLowerCase().includes(q) || p.barcode.includes(q) || p.brand.toLowerCase().includes(q)
    return okCat && okQuery
  })

  const openAdd = () => {
    setEditingId(null)
    setForm(EMPTY_FORM)
    setModalOpen(true)
  }

  const openEdit = (p: Product) => {
    setEditingId(p.id)
    setForm({
      name: p.name,
      barcode: p.barcode,
      category: p.category,
      brand: p.brand,
      unit: p.unit,
      price: String(p.price),
      cost: String(p.cost),
      stock: String(p.stock),
      minStock: String(p.minStock),
    })
    setModalOpen(true)
  }

  const num = (v: string) => parseFloat(v.replace(',', '.')) || 0

  const saveForm = () => {
    if (!form.name.trim()) {
      toast('Le nom du produit est requis', 'error')
      return
    }
    if (num(form.price) <= 0) {
      toast('Le prix de vente doit être supérieur à 0', 'error')
      return
    }
    const data = {
      name: form.name.trim(),
      barcode: form.barcode.trim(),
      category: form.category.trim() || 'Divers',
      brand: form.brand.trim(),
      unit: form.unit.trim() || 'Pièce',
      price: num(form.price),
      cost: num(form.cost),
      stock: Math.max(0, Math.round(num(form.stock))),
      minStock: Math.max(0, Math.round(num(form.minStock))),
    }
    if (editingId) {
      updateProduct(editingId, data)
      toast(`✓ ${data.name} modifié`)
    } else {
      addProduct(data)
      toast(`✓ ${data.name} ajouté`)
    }
    setModalOpen(false)
  }

  const confirmDelete = () => {
    if (!deleteTarget) return
    deleteProduct(deleteTarget.id)
    toast(`${deleteTarget.name} supprimé`)
    setDeleteTarget(null)
  }

  if (!ready) {
    return <div className="flex h-64 items-center justify-center text-sm text-gray-400 dark:text-zinc-500">Chargement…</div>
  }

  const stockBadge = (p: Product) =>
    p.stock === 0
      ? 'bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400'
      : p.stock <= p.minStock
        ? 'bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400'
        : 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex flex-wrap items-end justify-between gap-4"
      >
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-3xl">Produits</h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-zinc-400">{products.length} produit(s) au catalogue</p>
        </div>
        <div className="flex flex-wrap gap-3">
          <button onClick={() => window.print()} className="btn-secondary">
            <Printer className="h-4 w-4" />
            Imprimer
          </button>
          <button onClick={() => exportProductsCSV(products)} className="btn-secondary">
            Export CSV
          </button>
          <button onClick={openAdd} className="btn-primary">
            <Plus className="h-4 w-4" />
            Ajouter un produit
          </button>
        </div>
      </motion.div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative min-w-[240px] flex-1 sm:max-w-sm">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400 dark:text-zinc-500" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Nom, marque ou code-barres…"
            className="input-field pl-10"
          />
        </div>
        <Select value={category} onChange={setCategory} options={catFilters} className="w-auto min-w-[160px]" />
      </div>

      {/* Table */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.4 }}
        className="glass-card print-area overflow-hidden"
      >
        <div className="overflow-x-auto">
          <table className="w-full min-w-[860px]">
            <thead>
              <tr className="border-b border-gray-100 dark:border-white/10 text-left text-[11px] font-bold uppercase tracking-wider text-gray-400 dark:text-zinc-500">
                <th className="px-5 py-3.5">Produit</th>
                <th className="px-5 py-3.5">Catégorie</th>
                <th className="px-5 py-3.5">Marque / Unité</th>
                <th className="px-5 py-3.5">Prix achat</th>
                <th className="px-5 py-3.5">Prix vente</th>
                <th className="px-5 py-3.5">Marge</th>
                <th className="px-5 py-3.5">Stock</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((p) => (
                <tr key={p.id} className="group border-b border-gray-50 dark:border-white/5 transition-colors hover:bg-amber-50/40 dark:hover:bg-white/5">
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-3">
                      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 to-yellow-500 text-gray-900">
                        <Package className="h-4 w-4" />
                      </div>
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold text-gray-900 dark:text-white">{p.name}</p>
                        <p className="font-mono text-xs text-gray-400 dark:text-zinc-500">{p.barcode || '—'}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-3.5">
                    <span className="rounded-md bg-gray-100 dark:bg-white/10 px-2 py-1 text-xs font-semibold text-gray-600 dark:text-zinc-400">
                      {p.category}
                    </span>
                  </td>
                  <td className="px-5 py-3.5">
                    <p className="text-xs font-semibold text-gray-700 dark:text-zinc-300">{p.brand || '—'}</p>
                    <p className="text-xs text-gray-400 dark:text-zinc-500">{p.unit}</p>
                  </td>
                  <td className="px-5 py-3.5 text-sm text-gray-600 dark:text-zinc-400 tabular-nums">{fmtDH(p.cost)}</td>
                  <td className="px-5 py-3.5 text-sm font-semibold text-gray-900 dark:text-white tabular-nums">
                    {fmtDH(p.price)}
                  </td>
                  <td className="px-5 py-3.5 text-sm font-semibold text-emerald-600 dark:text-emerald-400 tabular-nums">
                    {p.cost > 0 ? `${(((p.price - p.cost) / p.cost) * 100).toFixed(0)}%` : '—'}
                  </td>
                  <td className="px-5 py-3.5">
                    <span className={`rounded-lg px-2 py-1 text-xs font-bold tabular-nums ${stockBadge(p)}`}>
                      {p.stock === 0 ? 'Rupture' : `${p.stock} ${p.unit}`}
                    </span>
                  </td>
                  <td className="px-5 py-3.5">
                    <div className="flex items-center justify-end gap-1">
                      <button
                        onClick={() => openEdit(p)}
                        className="rounded-lg p-2 text-gray-400 dark:text-zinc-500 transition hover:bg-amber-50 hover:text-amber-600 dark:group-hover:text-white"
                        title="Modifier"
                      >
                        <Pencil className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => setDeleteTarget(p)}
                        className="rounded-lg p-2 text-gray-400 dark:text-zinc-500 transition hover:bg-rose-50 hover:text-rose-500 dark:group-hover:text-white"
                        title="Supprimer"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-5 py-10 text-center text-sm text-gray-400 dark:text-zinc-500">
                    Aucun produit trouvé
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Add / edit modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingId ? 'Modifier le produit' : 'Ajouter un produit'}
      >
        <div className="space-y-4">
          <div>
            <label className="field-label">Nom du produit *</label>
            <input
              type="text"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="ex: Peinture blanche 5L"
              className="input-field"
            />
          </div>
          <div>
            <label className="field-label">Code-barres</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={form.barcode}
                onChange={(e) => setForm({ ...form, barcode: e.target.value })}
                onKeyDown={(e) => e.key === 'Enter' && e.preventDefault()}
                placeholder="Scannez ou générez"
                className="input-field font-mono"
              />
              <button
                onClick={() => setCameraOpen(true)}
                className="btn-secondary shrink-0 !px-3"
                title="Scanner avec la caméra"
              >
                <Camera className="h-4 w-4" />
              </button>
              <button
                onClick={() => setForm({ ...form, barcode: generateEan13() })}
                className="btn-secondary shrink-0 !px-3"
                title="Générer un code EAN-13"
              >
                <Wand2 className="h-4 w-4" />
              </button>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="field-label">Catégorie</label>
              <Select
                value={form.category}
                onChange={(v) => setForm({ ...form, category: v })}
                placeholder="— Choisir —"
                options={[{ value: '', label: '— Choisir —' }, ...categories.map((c) => ({ value: c.name, label: c.name }))]}
              />
            </div>
            <div>
              <label className="field-label">Marque</label>
              <Select
                value={form.brand}
                onChange={(v) => setForm({ ...form, brand: v })}
                placeholder="— Aucune —"
                options={[{ value: '', label: '— Aucune —' }, ...brands.map((b) => ({ value: b.name, label: b.name }))]}
              />
            </div>
            <div>
              <label className="field-label">Unité</label>
              <Select
                value={form.unit}
                onChange={(v) => setForm({ ...form, unit: v })}
                options={units.map((u) => ({ value: u.name, label: u.name }))}
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="field-label">Prix d&apos;achat (DH)</label>
              <input
                type="number"
                min="0"
                value={form.cost}
                onChange={(e) => setForm({ ...form, cost: e.target.value })}
                placeholder="0.00"
                className="input-field"
              />
            </div>
            <div>
              <label className="field-label">Prix de vente (DH) *</label>
              <input
                type="number"
                min="0"
                value={form.price}
                onChange={(e) => setForm({ ...form, price: e.target.value })}
                placeholder="0.00"
                className="input-field"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="field-label">Stock</label>
              <input
                type="number"
                min="0"
                value={form.stock}
                onChange={(e) => setForm({ ...form, stock: e.target.value })}
                placeholder="0"
                className="input-field"
              />
            </div>
            <div>
              <label className="field-label">Stock minimum (alerte)</label>
              <input
                type="number"
                min="0"
                value={form.minStock}
                onChange={(e) => setForm({ ...form, minStock: e.target.value })}
                placeholder="5"
                className="input-field"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3 pt-2">
            <button onClick={() => setModalOpen(false)} className="btn-secondary">
              Annuler
            </button>
            <button onClick={saveForm} className="btn-primary">
              {editingId ? 'Enregistrer' : 'Ajouter'}
            </button>
          </div>
        </div>
      </Modal>

      <CameraScanner
        open={cameraOpen}
        onClose={() => setCameraOpen(false)}
        onDetect={(code) => {
          setForm((f) => ({ ...f, barcode: code }))
          toast(`✓ Code scanné : ${code}`)
        }}
      />

      {/* Delete confirm */}
      <Modal
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        title="Supprimer le produit ?"
        maxWidth="max-w-sm"
      >
        <p className="text-sm text-gray-600 dark:text-zinc-400">
          <span className="font-semibold text-gray-900 dark:text-white">{deleteTarget?.name}</span> sera supprimé
          définitivement du catalogue.
        </p>
        <div className="mt-5 grid grid-cols-2 gap-3">
          <button onClick={() => setDeleteTarget(null)} className="btn-secondary">
            Annuler
          </button>
          <button onClick={confirmDelete} className="btn-danger">
            <Trash2 className="h-4 w-4" />
            Supprimer
          </button>
        </div>
      </Modal>
    </>
  )
}

export default function ProduitsPage() {
  return (
    <AppShell>
      <ProduitsContent />
    </AppShell>
  )
}
