'use client'

import React, { useState } from 'react'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import { Save, UserPlus, X } from 'lucide-react'
import AppShell from '@/components/AppShell'
import Select from '@/components/Select'
import { useToast } from '@/components/Toast'
import { useDroguerie } from '@/lib/store'

const EMPTY_FORM = {
  name: '',
  phone: '',
  email: '',
  address: '',
  city: '',
  cin: '',
  clientType: 'Particulier',
  creditLimit: '0',
  notes: '',
}

function Content() {
  const { addClient } = useDroguerie()
  const toast = useToast()
  const router = useRouter()
  const [form, setForm] = useState(EMPTY_FORM)

  const validate = () => {
    if (!form.name.trim()) {
      toast('Le nom complet est requis', 'error')
      return false
    }
    if (!form.phone.trim()) {
      toast('Le téléphone est requis', 'error')
      return false
    }
    return true
  }

  const buildPayload = () => ({
    name: form.name.trim(),
    phone: form.phone.trim(),
    email: form.email.trim(),
    address: form.address.trim(),
    city: form.city.trim(),
    cin: form.cin.trim(),
    clientType: form.clientType as 'Particulier' | 'Professionnel',
    creditLimit: Math.max(0, parseFloat(form.creditLimit.replace(',', '.')) || 0),
    notes: form.notes.trim(),
  })

  const save = (andNew: boolean) => {
    if (!validate()) return
    const client = addClient(buildPayload())
    toast(`✓ ${client.name} ajouté au fichier client`)
    if (andNew) {
      setForm(EMPTY_FORM)
    } else {
      router.push('/clients')
    }
  }

  return (
    <>
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
        <h1 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-3xl">Nouveau client</h1>
        <p className="mt-1 text-sm text-gray-500 dark:text-zinc-400">Créez une fiche client complète.</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05, duration: 0.4 }}
        className="glass-card max-w-3xl p-6"
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="field-label">Nom complet *</label>
            <input
              type="text"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="ex: Ahmed Bennani"
              className="input-field"
            />
          </div>
          <div>
            <label className="field-label">Téléphone *</label>
            <input
              type="tel"
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              placeholder="06 XX XX XX XX"
              className="input-field"
            />
          </div>
          <div>
            <label className="field-label">Email</label>
            <input
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              placeholder="client@exemple.com"
              className="input-field"
            />
          </div>
          <div>
            <label className="field-label">CIN (optionnel)</label>
            <input
              type="text"
              value={form.cin}
              onChange={(e) => setForm({ ...form, cin: e.target.value })}
              placeholder="ex: BK123456"
              className="input-field"
            />
          </div>
          <div className="sm:col-span-2">
            <label className="field-label">Adresse</label>
            <input
              type="text"
              value={form.address}
              onChange={(e) => setForm({ ...form, address: e.target.value })}
              placeholder="Rue, quartier…"
              className="input-field"
            />
          </div>
          <div>
            <label className="field-label">Ville</label>
            <input
              type="text"
              value={form.city}
              onChange={(e) => setForm({ ...form, city: e.target.value })}
              placeholder="ex: Casablanca"
              className="input-field"
            />
          </div>
          <div>
            <label className="field-label">Type de client</label>
            <Select
              value={form.clientType}
              onChange={(v) => setForm({ ...form, clientType: v })}
              options={['Particulier', 'Professionnel']}
            />
          </div>
          <div>
            <label className="field-label">Plafond de crédit (DH)</label>
            <input
              type="number"
              min="0"
              value={form.creditLimit}
              onChange={(e) => setForm({ ...form, creditLimit: e.target.value })}
              placeholder="0"
              className="input-field"
            />
          </div>
          <div className="sm:col-span-2">
            <label className="field-label">Notes</label>
            <textarea
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              placeholder="Remarques internes…"
              rows={3}
              className="input-field !h-auto resize-none py-2.5"
            />
          </div>
        </div>

        <div className="mt-6 flex flex-wrap justify-end gap-3">
          <button onClick={() => router.push('/clients')} className="btn-secondary">
            <X className="h-4 w-4" />
            Annuler
          </button>
          <button onClick={() => save(true)} className="btn-secondary">
            <UserPlus className="h-4 w-4" />
            Enregistrer et Nouveau
          </button>
          <button onClick={() => save(false)} className="btn-primary">
            <Save className="h-4 w-4" />
            Enregistrer
          </button>
        </div>
      </motion.div>
    </>
  )
}

export default function NouveauClientPage() {
  return (
    <AppShell>
      <Content />
    </AppShell>
  )
}
