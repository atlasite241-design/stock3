'use client'

import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { Check, Pencil, Plus, ShieldCheck, Trash2, UserCog, X } from 'lucide-react'
import AppShell from '@/components/AppShell'
import Modal from '@/components/Modal'
import Select from '@/components/Select'
import { useToast } from '@/components/Toast'
import { useDroguerie, type AppUser } from '@/lib/store'

const ROLES: AppUser['role'][] = ['Administrateur', 'Caissier', 'Vendeur']

const ROLE_META: Record<AppUser['role'], { chip: string }> = {
  Administrateur: { chip: 'border-violet-200 dark:border-violet-500/20 bg-violet-50 dark:bg-violet-500/10 text-violet-700 dark:text-violet-400' },
  Caissier: { chip: 'border-sky-200 dark:border-sky-500/20 bg-sky-50 dark:bg-sky-500/10 text-sky-700' },
  Vendeur: { chip: 'border-amber-200 dark:border-amber-500/20 bg-amber-50 dark:bg-amber-500/10 text-amber-700 dark:text-amber-300' },
}

// Permission matrix per role
const PERMISSIONS: { key: string; label: string }[] = [
  { key: 'pos', label: 'Point de vente' },
  { key: 'produits', label: 'Gérer les produits' },
  { key: 'stock', label: 'Gérer le stock' },
  { key: 'achats', label: 'Achats & fournisseurs' },
  { key: 'rapports', label: 'Voir les rapports' },
  { key: 'caisse', label: 'Ouvrir/fermer la caisse' },
  { key: 'parametres', label: 'Paramètres & utilisateurs' },
]

const ROLE_PERMS: Record<AppUser['role'], string[]> = {
  Administrateur: PERMISSIONS.map((p) => p.key),
  Caissier: ['pos', 'caisse', 'stock'],
  Vendeur: ['pos', 'produits'],
}

function Content() {
  const { ready, users, activity, addUser, updateUser, deleteUser } = useDroguerie()
  const toast = useToast()

  const [tab, setTab] = useState<'equipe' | 'permissions' | 'journal'>('equipe')
  const [modalOpen, setModalOpen] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [form, setForm] = useState<{ name: string; phone: string; role: AppUser['role']; active: boolean }>({
    name: '',
    phone: '',
    role: 'Caissier',
    active: true,
  })
  const [deleteTarget, setDeleteTarget] = useState<AppUser | null>(null)

  if (!ready) {
    return <div className="flex h-64 items-center justify-center text-sm text-gray-400 dark:text-zinc-500">Chargement…</div>
  }

  const openAdd = () => {
    setEditingId(null)
    setForm({ name: '', phone: '', role: 'Caissier', active: true })
    setModalOpen(true)
  }

  const openEdit = (u: AppUser) => {
    setEditingId(u.id)
    setForm({ name: u.name, phone: u.phone, role: u.role, active: u.active })
    setModalOpen(true)
  }

  const saveForm = () => {
    if (!form.name.trim()) {
      toast('Le nom est requis', 'error')
      return
    }
    if (editingId) {
      updateUser(editingId, form)
      toast(`✓ ${form.name} modifié`)
    } else {
      addUser(form)
      toast(`✓ ${form.name} ajouté`)
    }
    setModalOpen(false)
  }

  const tabs = [
    { key: 'equipe' as const, label: 'Employés' },
    { key: 'permissions' as const, label: 'Rôles & permissions' },
    { key: 'journal' as const, label: "Journal d'activité" },
  ]

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex flex-wrap items-end justify-between gap-4"
      >
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-3xl">Utilisateurs</h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-zinc-400">Employés, rôles, permissions et journal d&apos;activité.</p>
        </div>
        {tab === 'equipe' && (
          <button onClick={openAdd} className="btn-primary">
            <Plus className="h-4 w-4" />
            Ajouter un employé
          </button>
        )}
      </motion.div>

      <div className="flex flex-wrap gap-2">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`rounded-xl px-3.5 py-2 text-xs font-semibold transition ${
              tab === t.key
                ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-gray-900 shadow-lg shadow-amber-400/25'
                : 'border border-gray-200 dark:border-white/10 bg-white dark:bg-[#12121a] text-gray-600 dark:text-zinc-400 hover:border-amber-300 hover:bg-amber-50'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Team */}
      {tab === 'equipe' && (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="glass-card overflow-hidden"
        >
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px]">
              <thead>
                <tr className="border-b border-gray-100 dark:border-white/10 text-left text-[11px] font-bold uppercase tracking-wider text-gray-400 dark:text-zinc-500">
                  <th className="px-5 py-3.5">Employé</th>
                  <th className="px-5 py-3.5">Téléphone</th>
                  <th className="px-5 py-3.5">Rôle</th>
                  <th className="px-5 py-3.5">Statut</th>
                  <th className="px-5 py-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id} className="group border-b border-gray-50 dark:border-white/5 transition-colors hover:bg-amber-50/40 dark:hover:bg-white/5">
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-3">
                        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 to-yellow-500 text-xs font-bold text-gray-900">
                          {u.name.split(' ').slice(0, 2).map((w) => w[0]).join('')}
                        </div>
                        <p className="text-sm font-semibold text-gray-900 dark:text-white">{u.name}</p>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 text-sm text-gray-600 dark:text-zinc-400 tabular-nums">{u.phone || '—'}</td>
                    <td className="px-5 py-3.5">
                      <span className={`rounded-lg border px-2 py-1 text-xs font-bold ${ROLE_META[u.role].chip}`}>
                        {u.role}
                      </span>
                    </td>
                    <td className="px-5 py-3.5">
                      <button
                        onClick={() => updateUser(u.id, { active: !u.active })}
                        className={`inline-flex items-center gap-1.5 rounded-lg px-2 py-1 text-xs font-bold transition ${
                          u.active
                            ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100'
                            : 'bg-gray-100 dark:bg-white/10 text-gray-500 dark:text-zinc-400 hover:bg-gray-200'
                        }`}
                      >
                        <span className={`h-1.5 w-1.5 rounded-full ${u.active ? 'bg-emerald-500' : 'bg-gray-400'}`} />
                        {u.active ? 'Actif' : 'Inactif'}
                      </button>
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => openEdit(u)}
                          className="rounded-lg p-2 text-gray-400 dark:text-zinc-500 transition hover:bg-amber-50 hover:text-amber-600 dark:group-hover:text-white"
                        >
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => setDeleteTarget(u)}
                          className="rounded-lg p-2 text-gray-400 dark:text-zinc-500 transition hover:bg-rose-50 hover:text-rose-500 dark:group-hover:text-white"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      )}

      {/* Permissions matrix */}
      {tab === 'permissions' && (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="glass-card overflow-hidden"
        >
          <div className="border-b border-gray-100 dark:border-white/10 px-5 py-4">
            <h2 className="flex items-center gap-2 text-base font-semibold text-gray-900 dark:text-white">
              <ShieldCheck className="h-4 w-4 text-amber-500" />
              Matrice des permissions
            </h2>
            <p className="text-xs text-gray-500 dark:text-zinc-400">Ce que chaque rôle peut faire dans l&apos;application</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[560px]">
              <thead>
                <tr className="border-b border-gray-100 dark:border-white/10 text-left text-[11px] font-bold uppercase tracking-wider text-gray-400 dark:text-zinc-500">
                  <th className="px-5 py-3.5">Permission</th>
                  {ROLES.map((r) => (
                    <th key={r} className="px-5 py-3.5 text-center">
                      {r}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {PERMISSIONS.map((perm) => (
                  <tr key={perm.key} className="border-b border-gray-50">
                    <td className="px-5 py-3 text-sm font-medium text-gray-900 dark:text-white">{perm.label}</td>
                    {ROLES.map((r) => (
                      <td key={r} className="px-5 py-3 text-center">
                        {ROLE_PERMS[r].includes(perm.key) ? (
                          <Check className="mx-auto h-4 w-4 text-emerald-500 dark:text-emerald-400" />
                        ) : (
                          <X className="mx-auto h-4 w-4 text-gray-300" />
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      )}

      {/* Activity log */}
      {tab === 'journal' && (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="glass-card p-6"
        >
          <h2 className="text-base font-semibold text-gray-900 dark:text-white">Journal d&apos;activité</h2>
          <p className="mt-0.5 text-xs text-gray-500 dark:text-zinc-400">Les dernières actions enregistrées dans l&apos;application</p>
          <div className="mt-4 space-y-1">
            {activity.slice(0, 40).map((a) => (
              <div key={a.id} className="flex items-start gap-3 rounded-xl p-2.5 transition-colors hover:bg-amber-50/50">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gray-100 dark:bg-white/10 text-gray-500 dark:text-zinc-400">
                  <UserCog className="h-4 w-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">{a.action}</p>
                  <p className="text-xs text-gray-400 dark:text-zinc-500">{a.user}</p>
                </div>
                <span className="shrink-0 pt-0.5 text-[11px] text-gray-400 dark:text-zinc-500">
                  {new Date(a.date).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short' })}{' '}
                  {new Date(a.date).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            ))}
            {activity.length === 0 && <p className="py-6 text-center text-sm text-gray-400 dark:text-zinc-500">Aucune activité</p>}
          </div>
        </motion.div>
      )}

      {/* Add/edit modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingId ? "Modifier l'employé" : 'Ajouter un employé'}
        maxWidth="max-w-sm"
      >
        <div className="space-y-4">
          <div>
            <label className="field-label">Nom complet *</label>
            <input
              type="text"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="ex: Hamid Tazi"
              className="input-field"
            />
          </div>
          <div>
            <label className="field-label">Téléphone</label>
            <input
              type="tel"
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              placeholder="06 XX XX XX XX"
              className="input-field"
            />
          </div>
          <div>
            <label className="field-label">Rôle</label>
            <Select
              value={form.role}
              onChange={(v) => setForm({ ...form, role: v as AppUser['role'] })}
              options={ROLES.map((r) => ({ value: r, label: r }))}
            />
          </div>
          <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-zinc-300">
            <input
              type="checkbox"
              checked={form.active}
              onChange={(e) => setForm({ ...form, active: e.target.checked })}
              className="h-4 w-4 rounded border-gray-300 dark:border-white/15 text-amber-500 focus:ring-amber-400"
            />
            Compte actif
          </label>
          <div className="grid grid-cols-2 gap-3 pt-2">
            <button onClick={() => setModalOpen(false)} className="btn-secondary">
              Annuler
            </button>
            <button onClick={saveForm} className="btn-primary">
              {editingId ? 'Enregistrer' : 'Ajouter'}
            </button>
          </div>
        </div>
      </Modal>

      {/* Delete confirm */}
      <Modal open={!!deleteTarget} onClose={() => setDeleteTarget(null)} title="Supprimer l'employé ?" maxWidth="max-w-sm">
        <p className="text-sm text-gray-600 dark:text-zinc-400">
          <span className="font-semibold text-gray-900 dark:text-white">{deleteTarget?.name}</span> perdra l&apos;accès à
          l&apos;application.
        </p>
        <div className="mt-5 grid grid-cols-2 gap-3">
          <button onClick={() => setDeleteTarget(null)} className="btn-secondary">
            Annuler
          </button>
          <button
            onClick={() => {
              deleteUser(deleteTarget!.id)
              toast(`${deleteTarget!.name} supprimé`)
              setDeleteTarget(null)
            }}
            className="btn-danger"
          >
            <Trash2 className="h-4 w-4" />
            Supprimer
          </button>
        </div>
      </Modal>
    </>
  )
}

export default function UtilisateursPage() {
  return (
    <AppShell>
      <Content />
    </AppShell>
  )
}
