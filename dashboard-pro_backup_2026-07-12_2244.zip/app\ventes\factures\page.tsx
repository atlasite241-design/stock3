'use client'

import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { FileText, Printer, Search } from 'lucide-react'
import AppShell from '@/components/AppShell'
import Modal from '@/components/Modal'
import { fmtDH, PAYMENT_META, useDroguerie, type Sale } from '@/lib/store'

function Content() {
  const { ready, sales, settings } = useDroguerie()
  const [query, setQuery] = useState('')
  const [invoice, setInvoice] = useState<Sale | null>(null)

  if (!ready) {
    return <div className="flex h-64 items-center justify-center text-sm text-gray-400 dark:text-zinc-500">Chargement…</div>
  }

  const visible = [...sales]
    .sort((a, b) => b.date.localeCompare(a.date))
    .filter((s) => {
      const q = query.trim().toLowerCase()
      return (
        !q ||
        s.id.toLowerCase().includes(q) ||
        (s.clientName ?? '').toLowerCase().includes(q)
      )
    })

  const invoiceNumber = (s: Sale) => `FCT-${s.id.slice(-6).toUpperCase()}`
  const ht = (s: Sale) => s.total / (1 + settings.tva / 100)

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex flex-wrap items-end justify-between gap-4"
      >
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-3xl">Factures</h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-zinc-400">
            Chaque vente peut être imprimée en facture avec TVA ({settings.tva}%).
          </p>
        </div>
        <div className="relative min-w-[240px]">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400 dark:text-zinc-500" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="N° ou client…"
            className="input-field pl-10"
          />
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.4 }}
        className="glass-card overflow-hidden"
      >
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px]">
            <thead>
              <tr className="border-b border-gray-100 dark:border-white/10 text-left text-[11px] font-bold uppercase tracking-wider text-gray-400 dark:text-zinc-500">
                <th className="px-5 py-3.5">N° Facture</th>
                <th className="px-5 py-3.5">Date</th>
                <th className="px-5 py-3.5">Client</th>
                <th className="px-5 py-3.5">Paiement</th>
                <th className="px-5 py-3.5">Total TTC</th>
                <th className="px-5 py-3.5 text-right">Facture</th>
              </tr>
            </thead>
            <tbody>
              {visible.slice(0, 50).map((s) => (
                <tr key={s.id} className="border-b border-gray-50 transition-colors hover:bg-amber-50/40">
                  <td className="px-5 py-3.5 text-sm font-bold text-gray-900 dark:text-white">{invoiceNumber(s)}</td>
                  <td className="px-5 py-3.5">
                    <p className="text-sm text-gray-700 dark:text-zinc-300">
                      {new Date(s.date).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })}
                    </p>
                    <p className="text-xs text-gray-400 dark:text-zinc-500">
                      {new Date(s.date).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </td>
                  <td className="px-5 py-3.5 text-sm text-gray-600 dark:text-zinc-400">{s.clientName ?? 'Client de passage'}</td>
                  <td className="px-5 py-3.5">
                    <span className={`rounded-lg border px-2 py-1 text-xs font-bold ${PAYMENT_META[s.payment].chip}`}>
                      {PAYMENT_META[s.payment].label}
                    </span>
                  </td>
                  <td className="px-5 py-3.5 text-sm font-bold text-gray-900 dark:text-white tabular-nums">{fmtDH(s.total)}</td>
                  <td className="px-5 py-3.5">
                    <div className="flex justify-end">
                      <button onClick={() => setInvoice(s)} className="btn-secondary !h-8 !px-3 text-xs">
                        <FileText className="h-3.5 w-3.5" />
                        Voir la facture
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {visible.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-5 py-10 text-center text-sm text-gray-400 dark:text-zinc-500">
                    Aucune vente trouvée
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Invoice modal */}
      <Modal open={!!invoice} onClose={() => setInvoice(null)} title="Facture" maxWidth="max-w-md">
        {invoice && (
          <>
            <div className="print-area rounded-xl border border-gray-200 dark:border-white/10 bg-white dark:bg-[#12121a] p-5">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-lg font-bold text-gray-900 dark:text-white">{settings.storeName}</p>
                  <p className="text-xs text-gray-500 dark:text-zinc-400">{settings.address}</p>
                  <p className="text-xs text-gray-500 dark:text-zinc-400">{settings.phone}</p>
                </div>
                <div className="text-right">
                  <p className="text-base font-bold text-amber-600 dark:text-amber-400">FACTURE</p>
                  <p className="text-xs font-semibold text-gray-700 dark:text-zinc-300">{invoiceNumber(invoice)}</p>
                  <p className="text-xs text-gray-500 dark:text-zinc-400">{new Date(invoice.date).toLocaleDateString('fr-FR')}</p>
                </div>
              </div>
              <p className="mt-4 text-sm text-gray-700 dark:text-zinc-300">
                Client : <span className="font-semibold">{invoice.clientName ?? 'Client de passage'}</span>
              </p>
              <table className="mt-3 w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-200 dark:border-white/10 text-left text-[11px] font-bold uppercase text-gray-400 dark:text-zinc-500">
                    <th className="py-2">Désignation</th>
                    <th className="py-2 text-center">Qté</th>
                    <th className="py-2 text-right">P.U. TTC</th>
                    <th className="py-2 text-right">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {invoice.items.map((i) => (
                    <tr key={i.productId} className="border-b border-gray-100 dark:border-white/10">
                      <td className="py-2 text-gray-800 dark:text-zinc-100">{i.name}</td>
                      <td className="py-2 text-center tabular-nums">{i.qty}</td>
                      <td className="py-2 text-right tabular-nums">{fmtDH(i.price)}</td>
                      <td className="py-2 text-right font-semibold tabular-nums">{fmtDH(i.price * i.qty)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="mt-3 flex justify-end">
                <div className="w-56 space-y-1 text-sm">
                  <div className="flex justify-between text-gray-600 dark:text-zinc-400">
                    <span>Total HT</span>
                    <span className="tabular-nums">{fmtDH(ht(invoice))}</span>
                  </div>
                  <div className="flex justify-between text-gray-600 dark:text-zinc-400">
                    <span>TVA ({settings.tva}%)</span>
                    <span className="tabular-nums">{fmtDH(invoice.total - ht(invoice))}</span>
                  </div>
                  <div className="flex justify-between rounded-lg bg-amber-50 dark:bg-amber-500/10 px-2 py-1.5 text-base font-bold text-gray-900 dark:text-white">
                    <span>Total TTC</span>
                    <span className="tabular-nums">{fmtDH(invoice.total)}</span>
                  </div>
                  <p className="pt-1 text-right text-xs text-gray-500 dark:text-zinc-400">
                    Réglé en {PAYMENT_META[invoice.payment].label}
                  </p>
                </div>
              </div>
              <p className="mt-4 text-center text-[11px] text-gray-400 dark:text-zinc-500">{settings.ticketMessage}</p>
            </div>
            <button onClick={() => window.print()} className="btn-primary mt-4 w-full">
              <Printer className="h-4 w-4" />
              Imprimer la facture
            </button>
          </>
        )}
      </Modal>
    </>
  )
}

export default function FacturesPage() {
  return (
    <AppShell>
      <Content />
    </AppShell>
  )
}
