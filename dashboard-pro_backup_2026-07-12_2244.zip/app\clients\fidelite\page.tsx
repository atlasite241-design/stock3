'use client'

import React, { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { Award, Gift, Save, Sparkles, Star } from 'lucide-react'
import AppShell from '@/components/AppShell'
import Modal from '@/components/Modal'
import Select from '@/components/Select'
import { useToast } from '@/components/Toast'
import { fmtDH, useDroguerie } from '@/lib/store'

function Content() {
  const { ready, clients, loyaltyMovements, settings, saveSettings, redeemPoints } = useDroguerie()
  const toast = useToast()

  const [pointsPerAmount, setPointsPerAmount] = useState(String(settings.pointsPerAmount))
  const [pointValueDH, setPointValueDH] = useState(String(settings.pointValueDH))
  const [redeemOpen, setRedeemOpen] = useState(false)
  const [redeemClientId, setRedeemClientId] = useState('')
  const [redeemAmount, setRedeemAmount] = useState('')

  const ledger = useMemo(() => {
    const map = new Map<string, { gained: number; used: number }>()
    loyaltyMovements.forEach((m) => {
      const e = map.get(m.clientId) ?? { gained: 0, used: 0 }
      if (m.type === 'gain') e.gained += m.points
      else e.used += m.points
      map.set(m.clientId, e)
    })
    return map
  }, [loyaltyMovements])

  if (!ready) {
    return <div className="flex h-64 items-center justify-center text-sm text-gray-400 dark:text-zinc-500">Chargement…</div>
  }

  const totalPoints = clients.reduce((a, c) => a + c.points, 0)
  const totalDiscountAvailable = clients.reduce((a, c) => a + c.discountBalance, 0)
  const redeemClient = clients.find((c) => c.id === redeemClientId)
  const redeemPointsNum = Math.max(0, Math.round(parseFloat(redeemAmount.replace(',', '.')) || 0))
  const redeemValue = redeemPointsNum * settings.pointValueDH

  const saveLoyaltySettings = () => {
    const ppa = Math.max(1, parseFloat(pointsPerAmount.replace(',', '.')) || settings.pointsPerAmount)
    const pv = Math.max(0.01, parseFloat(pointValueDH.replace(',', '.')) || settings.pointValueDH)
    saveSettings({ ...settings, pointsPerAmount: ppa, pointValueDH: pv })
    toast('✓ Paramètres de fidélité enregistrés')
  }

  const submitRedeem = () => {
    if (!redeemClient) {
      toast('Sélectionnez un client', 'error')
      return
    }
    if (redeemPointsNum <= 0 || redeemPointsNum > redeemClient.points) {
      toast('Nombre de points invalide', 'error')
      return
    }
    redeemPoints(redeemClient.id, redeemPointsNum)
    toast(`✓ ${redeemPointsNum} points convertis en ${fmtDH(redeemValue)} de remise pour ${redeemClient.name}`)
    setRedeemOpen(false)
    setRedeemClientId('')
    setRedeemAmount('')
  }

  const cards = [
    { label: 'Points en circulation', value: String(totalPoints), icon: Star, cls: 'bg-amber-50 dark:bg-amber-500/10 text-amber-500' },
    { label: 'Remises disponibles', value: fmtDH(totalDiscountAvailable), icon: Gift, cls: 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-500 dark:text-emerald-400' },
    { label: 'Clients fidélisés', value: String(clients.filter((c) => c.points > 0).length), icon: Award, cls: 'bg-sky-50 dark:bg-sky-500/10 text-sky-500 dark:text-sky-400' },
  ]

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex flex-wrap items-end justify-between gap-4"
      >
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-3xl">Fidélité</h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-zinc-400">Points accumulés, remises et paramètres du programme.</p>
        </div>
        <button onClick={() => setRedeemOpen(true)} className="btn-primary">
          <Sparkles className="h-4 w-4" />
          Convertir des points
        </button>
      </motion.div>

      <div className="grid gap-4 sm:grid-cols-3">
        {cards.map((c, i) => (
          <motion.div
            key={c.label}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 * i, duration: 0.4 }}
            className="glass-card glass-card-hover p-5"
          >
            <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${c.cls}`}>
              <c.icon className="h-5 w-5" />
            </div>
            <p className="mt-4 text-[13px] font-medium text-gray-500 dark:text-zinc-400">{c.label}</p>
            <p className="mt-1 text-[22px] font-bold leading-none tracking-tight text-gray-900 dark:text-white tabular-nums">
              {c.value}
            </p>
          </motion.div>
        ))}
      </div>

      <div className="grid gap-6 xl:grid-cols-3">
        {/* Clients ledger */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.4 }}
          className="glass-card overflow-hidden xl:col-span-2"
        >
          <div className="border-b border-gray-100 px-5 py-4 dark:border-white/10">
            <h2 className="text-base font-semibold text-gray-900 dark:text-white">Solde de points par client</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[560px]">
              <thead>
                <tr className="border-b border-gray-100 dark:border-white/10 text-left text-[11px] font-bold uppercase tracking-wider text-gray-400 dark:text-zinc-500">
                  <th className="px-5 py-3">Client</th>
                  <th className="px-5 py-3">Gagnés</th>
                  <th className="px-5 py-3">Utilisés</th>
                  <th className="px-5 py-3">Solde</th>
                  <th className="px-5 py-3">Remise dispo</th>
                </tr>
              </thead>
              <tbody>
                {clients
                  .filter((c) => c.points > 0 || c.discountBalance > 0)
                  .sort((a, b) => b.points - a.points)
                  .map((c) => {
                    const l = ledger.get(c.id) ?? { gained: c.points, used: 0 }
                    return (
                      <tr key={c.id} className="border-b border-gray-50 dark:border-white/5 transition-colors hover:bg-amber-50/40 dark:hover:bg-white/5">
                        <td className="px-5 py-3 text-sm font-semibold text-gray-900 dark:text-white">{c.name}</td>
                        <td className="px-5 py-3 text-sm text-emerald-600 dark:text-emerald-400 tabular-nums">+{l.gained}</td>
                        <td className="px-5 py-3 text-sm text-rose-500 dark:text-rose-400 tabular-nums">
                          {l.used > 0 ? `-${l.used}` : '—'}
                        </td>
                        <td className="px-5 py-3">
                          <span className="rounded-lg bg-amber-50 dark:bg-amber-500/10 px-2 py-1 text-xs font-bold text-amber-600 dark:text-amber-400 tabular-nums">
                            ⭐ {c.points}
                          </span>
                        </td>
                        <td className="px-5 py-3 text-sm font-semibold text-gray-700 dark:text-zinc-300 tabular-nums">
                          {c.discountBalance > 0 ? fmtDH(c.discountBalance) : '—'}
                        </td>
                      </tr>
                    )
                  })}
                {clients.filter((c) => c.points > 0 || c.discountBalance > 0).length === 0 && (
                  <tr>
                    <td colSpan={5} className="px-5 py-10 text-center text-sm text-gray-400 dark:text-zinc-500">
                      Aucun point accumulé pour le moment
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </motion.div>

        {/* Settings */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15, duration: 0.4 }}
          className="glass-card p-5"
        >
          <h2 className="text-base font-semibold text-gray-900 dark:text-white">Paramètres du programme</h2>
          <div className="mt-4 space-y-4">
            <div>
              <label className="field-label">1 point gagné tous les (DH dépensés)</label>
              <input
                type="number"
                min="1"
                value={pointsPerAmount}
                onChange={(e) => setPointsPerAmount(e.target.value)}
                className="input-field"
              />
            </div>
            <div>
              <label className="field-label">Valeur d&apos;un point (DH de remise)</label>
              <input
                type="number"
                min="0"
                step="0.5"
                value={pointValueDH}
                onChange={(e) => setPointValueDH(e.target.value)}
                className="input-field"
              />
            </div>
            <button onClick={saveLoyaltySettings} className="btn-primary w-full">
              <Save className="h-4 w-4" />
              Enregistrer
            </button>
          </div>
        </motion.div>
      </div>

      {/* Movements history */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.4 }}
        className="glass-card overflow-hidden"
      >
        <div className="border-b border-gray-100 px-5 py-4 dark:border-white/10">
          <h2 className="text-base font-semibold text-gray-900 dark:text-white">Historique des mouvements</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[560px]">
            <thead>
              <tr className="border-b border-gray-100 dark:border-white/10 text-left text-[11px] font-bold uppercase tracking-wider text-gray-400 dark:text-zinc-500">
                <th className="px-5 py-3">Date</th>
                <th className="px-5 py-3">Client</th>
                <th className="px-5 py-3">Type</th>
                <th className="px-5 py-3">Note</th>
                <th className="px-5 py-3 text-right">Points</th>
              </tr>
            </thead>
            <tbody>
              {loyaltyMovements.slice(0, 30).map((m) => (
                <tr key={m.id} className="border-b border-gray-50 dark:border-white/5">
                  <td className="px-5 py-3 text-sm text-gray-600 dark:text-zinc-400">
                    {new Date(m.date).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })}
                  </td>
                  <td className="px-5 py-3 text-sm font-semibold text-gray-900 dark:text-white">{m.clientName}</td>
                  <td className="px-5 py-3">
                    <span
                      className={`rounded-lg border px-2 py-1 text-xs font-bold ${
                        m.type === 'gain'
                          ? 'border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-500/20 dark:bg-emerald-500/10 dark:text-emerald-400'
                          : 'border-violet-200 bg-violet-50 text-violet-700 dark:border-violet-500/20 dark:bg-violet-500/10 dark:text-violet-400'
                      }`}
                    >
                      {m.type === 'gain' ? 'Gain' : 'Utilisation'}
                    </span>
                  </td>
                  <td className="px-5 py-3 text-sm text-gray-500 dark:text-zinc-400">{m.note}</td>
                  <td className={`px-5 py-3 text-right text-sm font-bold tabular-nums ${m.type === 'gain' ? 'text-emerald-600 dark:text-emerald-400' : 'text-violet-600 dark:text-violet-400'}`}>
                    {m.type === 'gain' ? '+' : '−'}
                    {m.points}
                  </td>
                </tr>
              ))}
              {loyaltyMovements.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-5 py-10 text-center text-sm text-gray-400 dark:text-zinc-500">
                    Aucun mouvement de fidélité
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Redeem modal */}
      <Modal open={redeemOpen} onClose={() => setRedeemOpen(false)} title="Convertir des points en remise" maxWidth="max-w-sm">
        <div className="space-y-4">
          <div>
            <label className="field-label">Client</label>
            <Select
              value={redeemClientId}
              onChange={setRedeemClientId}
              placeholder="— Choisir —"
              options={[
                { value: '', label: '— Choisir —' },
                ...clients.filter((c) => c.points > 0).map((c) => ({ value: c.id, label: `${c.name} (${c.points} pts)` })),
              ]}
            />
          </div>
          <div>
            <label className="field-label">Points à convertir</label>
            <input
              type="number"
              min="1"
              max={redeemClient?.points ?? undefined}
              value={redeemAmount}
              onChange={(e) => setRedeemAmount(e.target.value)}
              className="input-field"
            />
            {redeemClient && (
              <p className="mt-1.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400 tabular-nums">
                = {fmtDH(redeemValue)} de remise (solde : {redeemClient.points} pts)
              </p>
            )}
          </div>
          <div className="grid grid-cols-2 gap-3 pt-1">
            <button onClick={() => setRedeemOpen(false)} className="btn-secondary">
              Annuler
            </button>
            <button onClick={submitRedeem} className="btn-primary">
              <Gift className="h-4 w-4" />
              Convertir
            </button>
          </div>
        </div>
      </Modal>
    </>
  )
}

export default function FidelitePage() {
  return (
    <AppShell>
      <Content />
    </AppShell>
  )
}
