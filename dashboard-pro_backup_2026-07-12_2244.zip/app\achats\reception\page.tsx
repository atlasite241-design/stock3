'use client'

import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { Eye, PackageCheck, Search } from 'lucide-react'
import AppShell from '@/components/AppShell'
import Modal from '@/components/Modal'
import { useToast } from '@/components/Toast'
import { fmtDH, useDroguerie, type Purchase } from '@/lib/store'

function Content() {
  const { ready, purchases, receivePurchase } = useDroguerie()
  const toast = useToast()
  const [query, setQuery] = useState('')
  const [detail, setDetail] = useState<Purchase | null>(null)
  const [receiveTarget, setReceiveTarget] = useState<Purchase | null>(null)

  if (!ready) {
    return <div className="flex h-64 items-center justify-center text-sm text-gray-400 dark:text-zinc-500">Chargement…</div>
  }

  const pending = purchases
    .filter((p) => p.status === 'en_attente')
    .filter((p) => {
      const q = query.trim().toLowerCase()
      return !q || p.ref.toLowerCase().includes(q) || p.supplierName.toLowerCase().includes(q)
    })

  const confirmReceive = () => {
    if (!receiveTarget) return
    receivePurchase(receiveTarget.id)
    toast(`✓ ${receiveTarget.ref} réceptionnée — stock mis à jour`)
    setReceiveTarget(null)
  }

  return (
    <>
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
        <h1 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-3xl">Réception marchandise</h1>
        <p className="mt-1 text-sm text-gray-500 dark:text-zinc-400">
          Confirmez la réception d&apos;une commande — le stock et le solde fournisseur sont mis à jour automatiquement.
        </p>
      </motion.div>

      <div className="relative min-w-[220px] flex-1 sm:max-w-xs">
        <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Référence ou fournisseur…"
          className="input-field pl-10"
        />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.4 }}
        className="glass-card overflow-hidden"
      >
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px]">
            <thead>
              <tr className="border-b border-gray-100 dark:border-white/10 text-left text-[11px] font-bold uppercase tracking-wider text-gray-400 dark:text-zinc-500">
                <th className="px-5 py-3.5">Référence</th>
                <th className="px-5 py-3.5">Fournisseur</th>
                <th className="px-5 py-3.5">Date commande</th>
                <th className="px-5 py-3.5">Articles</th>
                <th className="px-5 py-3.5">Total</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {pending.map((p) => (
                <tr key={p.id} className="border-b border-gray-50 dark:border-white/5 transition-colors hover:bg-amber-50/40 dark:hover:bg-white/5">
                  <td className="px-5 py-3.5 text-sm font-bold text-gray-900 dark:text-white">{p.ref}</td>
                  <td className="px-5 py-3.5 text-sm text-gray-700 dark:text-zinc-300">{p.supplierName}</td>
                  <td className="px-5 py-3.5 text-sm text-gray-600 dark:text-zinc-400">
                    {new Date(p.date).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })}
                  </td>
                  <td className="px-5 py-3.5 text-sm text-gray-600 dark:text-zinc-400 tabular-nums">
                    {p.items.reduce((a, i) => a + i.qty, 0)}
                  </td>
                  <td className="px-5 py-3.5 text-sm font-bold text-gray-900 dark:text-white tabular-nums">{fmtDH(p.total)}</td>
                  <td className="px-5 py-3.5">
                    <div className="flex items-center justify-end gap-1">
                      <button onClick={() => setDetail(p)} className="rounded-lg p-2 text-gray-400 dark:text-zinc-500 transition hover:bg-sky-50 hover:text-sky-600" title="Voir le détail">
                        <Eye className="h-4 w-4" />
                      </button>
                      <button onClick={() => setReceiveTarget(p)} className="btn-primary !h-8 !px-2.5 text-xs">
                        <PackageCheck className="h-3.5 w-3.5" />
                        Réceptionner
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {pending.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-5 py-10 text-center text-sm text-gray-400 dark:text-zinc-500">
                    Aucune commande en attente de réception
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Detail modal */}
      <Modal open={!!detail} onClose={() => setDetail(null)} title={`Commande ${detail?.ref ?? ''}`} maxWidth="max-w-sm">
        {detail && (
          <div className="space-y-2">
            {detail.items.map((i) => (
              <div key={i.productId} className="flex items-center justify-between gap-3 rounded-xl bg-gray-50 dark:bg-white/5 px-3 py-2.5">
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium text-gray-900 dark:text-white">{i.name}</p>
                  <p className="text-xs text-gray-500 dark:text-zinc-400 tabular-nums">
                    {i.qty} × {fmtDH(i.cost)}
                  </p>
                </div>
                <p className="shrink-0 text-sm font-bold text-gray-900 dark:text-white tabular-nums">{fmtDH(i.cost * i.qty)}</p>
              </div>
            ))}
          </div>
        )}
      </Modal>

      {/* Receive confirm */}
      <Modal open={!!receiveTarget} onClose={() => setReceiveTarget(null)} title="Confirmer la réception ?" maxWidth="max-w-sm">
        <div className="flex items-start gap-3">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-50 dark:bg-emerald-500/10 text-emerald-500 dark:text-emerald-400">
            <PackageCheck className="h-5 w-5" />
          </span>
          <p className="text-sm text-gray-600 dark:text-zinc-400">
            <span className="font-semibold text-gray-900 dark:text-white">{receiveTarget?.ref}</span> — le stock des{' '}
            {receiveTarget?.items.reduce((a, i) => a + i.qty, 0)} article(s) sera ajouté et le solde fournisseur mis à jour de{' '}
            <span className="font-semibold">{fmtDH(receiveTarget?.total ?? 0)}</span>.
          </p>
        </div>
        <div className="mt-5 grid grid-cols-2 gap-3">
          <button onClick={() => setReceiveTarget(null)} className="btn-secondary">
            Annuler
          </button>
          <button onClick={confirmReceive} className="btn-primary">
            <PackageCheck className="h-4 w-4" />
            Confirmer
          </button>
        </div>
      </Modal>
    </>
  )
}

export default function ReceptionPage() {
  return (
    <AppShell>
      <Content />
    </AppShell>
  )
}
