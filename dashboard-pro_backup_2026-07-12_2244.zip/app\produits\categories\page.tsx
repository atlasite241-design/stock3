'use client'

import React from 'react'
import { FolderTree } from 'lucide-react'
import AppShell from '@/components/AppShell'
import AttributCrud from '@/components/AttributCrud'
import { useDroguerie } from '@/lib/store'

function Content() {
  const { ready, products, categories, categoryActions } = useDroguerie()
  if (!ready) {
    return <div className="flex h-64 items-center justify-center text-sm text-gray-400 dark:text-zinc-500">Chargement…</div>
  }
  return (
    <AttributCrud
      title="Catégories"
      subtitle="Organisez votre catalogue par rayon."
      icon={FolderTree}
      items={categories}
      usageOf={(name) => products.filter((p) => p.category === name).length}
      actions={categoryActions}
    />
  )
}

export default function CategoriesPage() {
  return (
    <AppShell>
      <Content />
    </AppShell>
  )
}
