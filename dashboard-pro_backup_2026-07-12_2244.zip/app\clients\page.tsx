'use client'

import React, { useMemo, useState } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import {
  AlertTriangle,
  ArrowDown,
  ArrowUp,
  ArrowUpDown,
  BellRing,
  Download,
  Eye,
  HandCoins,
  Pencil,
  Plus,
  Printer,
  Search,
  Trash2,
  Users,
  Wallet,
} from 'lucide-react'
import AppShell from '@/components/AppShell'
import Modal from '@/components/Modal'
import Select from '@/components/Select'
import { useToast } from '@/components/Toast'
import { fmtDH, PAYMENT_META, useDroguerie, type Client } from '@/lib/store'

type FilterKey = 'tous' | 'vip' | 'regulier' | 'retards'
type SortKey = 'name' | 'phone' | 'city' | 'totalSpent' | 'credit'

const segmentOf = (c: Client): 'VIP' | 'Nouveau' | 'Régulier' => {
  if (c.totalSpent >= 3000) return 'VIP'
  if (c.totalSpent < 500) return 'Nouveau'
  return 'Régulier'
}

const SEGMENT_CHIP: Record<string, string> = {
  VIP: 'bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-200 dark:border-amber-500/20',
  Nouveau: 'bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-sky-200 dark:border-sky-500/20',
  Régulier: 'bg-gray-100 dark:bg-white/10 text-gray-600 dark:text-zinc-400 border-gray-200 dark:border-white/10',
}

function ClientsContent() {
  const { ready, clients, sales, updateClient, deleteClient, settleCredit } = useDroguerie()
  const toast = useToast()

  const [editingId, setEditingId] = useState<string | null>(null)
  const [editModalOpen, setEditModalOpen] = useState(false)
  const [form, setForm] = useState({ name: '', phone: '' })
  const [deleteTarget, setDeleteTarget] = useState<Client | null>(null)
  const [settleTarget, setSettleTarget] = useState<Client | null>(null)
  const [settleAmount, setSettleAmount] = useState('')
  const [profileTarget, setProfileTarget] = useState<Client | null>(null)
  const [printTarget, setPrintTarget] = useState<Client | null>(null)
  const [filter, setFilter] = useState<FilterKey>('tous')
  const [query, setQuery] = useState('')
  const [cityFilter, setCityFilter] = useState('Toutes')
  const [typeFilter, setTypeFilter] = useState('Tous')
  const [sortKey, setSortKey] = useState<SortKey>('name')
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc')

  const lastVisitOf = useMemo(() => {
    const map = new Map<string, string>()
    sales.forEach((s) => {
      if (!s.clientId) return
      const cur = map.get(s.clientId)
      if (!cur || s.date > cur) map.set(s.clientId, s.date)
    })
    return map
  }, [sales])

  if (!ready) {
    return <div className="flex h-64 items-center justify-center text-sm text-gray-400 dark:text-zinc-500">Chargement…</div>
  }

  const totalCredit = clients.reduce((a, c) => a + c.credit, 0)
  const best = [...clients].sort((a, b) => b.totalSpent - a.totalSpent)[0]
  const overdueCount = clients.filter((c) => c.credit > 0).length
  const cities = ['Toutes', ...Array.from(new Set(clients.map((c) => c.city).filter(Boolean)))]

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'))
    } else {
      setSortKey(key)
      setSortDir('asc')
    }
  }

  const visible = clients
    .filter((c) => {
      if (filter === 'vip') return segmentOf(c) === 'VIP'
      if (filter === 'regulier') return segmentOf(c) === 'Régulier'
      if (filter === 'retards') return c.credit > 0
      return true
    })
    .filter((c) => cityFilter === 'Toutes' || c.city === cityFilter)
    .filter((c) => typeFilter === 'Tous' || c.clientType === typeFilter)
    .filter((c) => {
      const q = query.trim().toLowerCase()
      return !q || c.name.toLowerCase().includes(q) || c.phone.includes(q) || c.city.toLowerCase().includes(q)
    })
    .sort((a, b) => {
      const dir = sortDir === 'asc' ? 1 : -1
      if (sortKey === 'totalSpent' || sortKey === 'credit') return (a[sortKey] - b[sortKey]) * dir
      return a[sortKey].localeCompare(b[sortKey]) * dir
    })

  const openEdit = (c: Client) => {
    setEditingId(c.id)
    setForm({ name: c.name, phone: c.phone })
    setEditModalOpen(true)
  }

  const saveForm = () => {
    if (!editingId) return
    if (!form.name.trim()) {
      toast('Le nom du client est requis', 'error')
      return
    }
    updateClient(editingId, { name: form.name.trim(), phone: form.phone.trim() })
    toast(`✓ ${form.name} modifié`)
    setEditModalOpen(false)
  }

  const openSettle = (c: Client) => {
    setSettleTarget(c)
    setSettleAmount(String(c.credit))
  }

  const confirmSettle = () => {
    if (!settleTarget) return
    const amount = parseFloat(settleAmount.replace(',', '.')) || 0
    if (amount <= 0) {
      toast('Montant invalide', 'error')
      return
    }
    settleCredit(settleTarget.id, amount)
    toast(`✓ Règlement de ${fmtDH(Math.min(amount, settleTarget.credit))} enregistré`)
    setSettleTarget(null)
  }

  const confirmDelete = () => {
    if (!deleteTarget) return
    deleteClient(deleteTarget.id)
    toast(`${deleteTarget.name} supprimé`)
    setDeleteTarget(null)
  }

  const relancer = (c: Client) => {
    toast(`📞 Rappel enregistré pour ${c.name} — ${fmtDH(c.credit)} dû`)
  }

  const exportCSV = () => {
    const rows = [['Nom', 'Téléphone', 'Ville', 'Type', 'Segment', 'Total dépensé', 'Points', 'Crédit']]
    clients.forEach((c) =>
      rows.push([c.name, c.phone, c.city, c.clientType, segmentOf(c), c.totalSpent.toFixed(2), String(c.points), c.credit.toFixed(2)])
    )
    const csv = rows.map((r) => r.join(';')).join('\n')
    const blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'clients-droguerie.csv'
    a.click()
    URL.revokeObjectURL(a.href)
  }

  const initials = (name: string) =>
    name
      .split(' ')
      .slice(0, 2)
      .map((w) => w[0]?.toUpperCase() ?? '')
      .join('')

  const cards = [
    { label: 'Clients enregistrés', value: String(clients.length), icon: Users, cls: 'bg-amber-50 dark:bg-amber-500/10 text-amber-500' },
    { label: 'Crédits en cours', value: fmtDH(totalCredit), icon: Wallet, cls: totalCredit > 0 ? 'bg-rose-50 dark:bg-rose-500/10 text-rose-500 dark:text-rose-400' : 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-500 dark:text-emerald-400' },
    { label: 'Meilleur client', value: best?.name ?? '—', icon: HandCoins, cls: 'bg-yellow-50 dark:bg-yellow-500/10 text-yellow-600 dark:text-yellow-400' },
  ]

  const filters: { key: FilterKey; label: string; badge?: number }[] = [
    { key: 'tous', label: 'Tous' },
    { key: 'vip', label: 'VIP' },
    { key: 'regulier', label: 'Régulier' },
    { key: 'retards', label: 'Retards', badge: overdueCount },
  ]

  const profileSales = profileTarget ? sales.filter((s) => s.clientId === profileTarget.id).slice(-8).reverse() : []

  const SortHeader = ({ label, sortField }: { label: string; sortField: SortKey }) => (
    <button
      onClick={() => toggleSort(sortField)}
      className="flex items-center gap-1 transition hover:text-gray-700 dark:hover:text-zinc-200"
    >
      {label}
      {sortKey === sortField ? (
        sortDir === 'asc' ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />
      ) : (
        <ArrowUpDown className="h-3 w-3 opacity-40" />
      )}
    </button>
  )

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex flex-wrap items-end justify-between gap-4"
      >
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-3xl">Clients</h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-zinc-400">Fiches clients et suivi des crédits.</p>
        </div>
        <div className="flex flex-wrap gap-3">
          <button onClick={exportCSV} className="btn-secondary">
            <Download className="h-4 w-4" />
            Exporter CSV
          </button>
          <Link href="/clients/nouveau" className="btn-primary">
            <Plus className="h-4 w-4" />
            Ajouter un client
          </Link>
        </div>
      </motion.div>

      {/* Summary cards */}
      <div className="grid gap-4 sm:grid-cols-3">
        {cards.map((c, i) => (
          <motion.div
            key={c.label}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 * i, duration: 0.4 }}
            className="glass-card glass-card-hover p-5"
          >
            <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${c.cls}`}>
              <c.icon className="h-5 w-5" />
            </div>
            <p className="mt-4 text-[13px] font-medium text-gray-500 dark:text-zinc-400">{c.label}</p>
            <p className="mt-1 truncate text-[22px] font-bold leading-none tracking-tight text-gray-900 dark:text-white">
              {c.value}
            </p>
          </motion.div>
        ))}
      </div>

      {/* Segment filters */}
      <div className="flex flex-wrap gap-2">
        {filters.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-semibold transition ${
              filter === f.key
                ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-gray-900 shadow-lg shadow-amber-400/25'
                : 'border border-gray-200 bg-white text-gray-600 hover:border-amber-300 hover:bg-amber-50 dark:border-white/10 dark:bg-[#12121a] dark:text-zinc-400 dark:hover:bg-white/5'
            }`}
          >
            {f.label}
            {!!f.badge && (
              <span className="flex h-4 min-w-[16px] items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-bold text-white">
                {f.badge}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Search + filters */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative min-w-[220px] flex-1 sm:max-w-xs">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Nom, téléphone, ville…"
            className="input-field pl-10"
          />
        </div>
        <Select value={cityFilter} onChange={setCityFilter} options={cities} className="w-auto min-w-[150px]" />
        <Select
          value={typeFilter}
          onChange={setTypeFilter}
          options={['Tous', 'Particulier', 'Professionnel']}
          className="w-auto min-w-[160px]"
        />
      </div>

      {/* Table */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15, duration: 0.4 }}
        className="glass-card overflow-hidden"
      >
        <div className="overflow-x-auto">
          <table className="w-full min-w-[900px]">
            <thead>
              <tr className="border-b border-gray-100 dark:border-white/10 text-left text-[11px] font-bold uppercase tracking-wider text-gray-400 dark:text-zinc-500">
                <th className="px-5 py-3.5"><SortHeader label="Client" sortField="name" /></th>
                <th className="px-5 py-3.5"><SortHeader label="Ville" sortField="city" /></th>
                <th className="px-5 py-3.5">Segment</th>
                <th className="px-5 py-3.5">Dernière visite</th>
                <th className="px-5 py-3.5"><SortHeader label="Total dépensé" sortField="totalSpent" /></th>
                <th className="px-5 py-3.5">Points</th>
                <th className="px-5 py-3.5"><SortHeader label="Crédit" sortField="credit" /></th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {visible.map((c) => {
                const segment = segmentOf(c)
                const overdue = c.credit > 0
                const lastVisit = lastVisitOf.get(c.id)
                return (
                  <tr
                    key={c.id}
                    className={`group border-b border-gray-50 dark:border-white/5 transition-colors hover:bg-amber-50/40 dark:hover:bg-white/5 ${
                      overdue ? 'border-l-2 border-l-rose-400 dark:border-l-rose-500/60' : ''
                    }`}
                  >
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-3">
                        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 to-yellow-500 text-xs font-bold text-gray-900">
                          {initials(c.name)}
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-gray-900 dark:text-white">{c.name}</p>
                          <p className="text-xs text-gray-400 dark:text-zinc-500 tabular-nums">{c.phone || '—'}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 text-sm text-gray-600 dark:text-zinc-400">{c.city || '—'}</td>
                    <td className="px-5 py-3.5">
                      <div className="flex flex-col items-start gap-1">
                        <span className={`rounded-full border px-2 py-0.5 text-[10px] font-black uppercase ${SEGMENT_CHIP[segment]}`}>
                          {segment}
                        </span>
                        {overdue && (
                          <span className="flex items-center gap-1 rounded-full border border-rose-200 bg-rose-50 px-1.5 py-0.5 text-[9px] font-bold uppercase text-rose-600 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-400">
                            <AlertTriangle className="h-2.5 w-2.5" />
                            Retard de paiement
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-5 py-3.5 text-sm text-gray-600 dark:text-zinc-400">
                      {lastVisit
                        ? new Date(lastVisit).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })
                        : 'Aucun achat'}
                    </td>
                    <td className="px-5 py-3.5 text-sm font-semibold text-gray-900 dark:text-white tabular-nums">
                      {fmtDH(c.totalSpent)}
                    </td>
                    <td className="px-5 py-3.5">
                      <span className="inline-flex items-center gap-1 rounded-lg bg-amber-50 dark:bg-amber-500/10 px-2 py-1 text-xs font-bold text-amber-600 dark:text-amber-400 tabular-nums">
                        ⭐ {c.points}
                      </span>
                    </td>
                    <td className="px-5 py-3.5">
                      {c.credit > 0 ? (
                        <span className="rounded-lg border border-rose-200 dark:border-rose-500/20 bg-rose-50 dark:bg-rose-500/10 px-2 py-1 text-xs font-bold text-rose-600 dark:text-rose-400 tabular-nums">
                          {fmtDH(c.credit)}
                        </span>
                      ) : (
                        <span className="rounded-lg border border-emerald-200 dark:border-emerald-500/20 bg-emerald-50 dark:bg-emerald-500/10 px-2 py-1 text-xs font-bold text-emerald-600 dark:text-emerald-400">
                          À jour
                        </span>
                      )}
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center justify-end gap-1">
                        {overdue && (
                          <button
                            onClick={() => relancer(c)}
                            className="flex items-center gap-1.5 rounded-lg border border-rose-200 bg-rose-50 px-2.5 py-1.5 text-xs font-bold text-rose-600 transition hover:bg-rose-100 dark:border-rose-500/20 dark:bg-rose-500/10 dark:text-rose-400 dark:hover:bg-rose-500/20"
                            title="Relancer le client"
                          >
                            <BellRing className="h-3.5 w-3.5" />
                            Relancer
                          </button>
                        )}
                        {c.credit > 0 && (
                          <button
                            onClick={() => openSettle(c)}
                            className="btn-secondary !h-8 !px-2.5 text-xs"
                            title="Encaisser un règlement"
                          >
                            <HandCoins className="h-3.5 w-3.5" />
                            Régler
                          </button>
                        )}
                        <button
                          onClick={() => setProfileTarget(c)}
                          className="rounded-lg p-2 text-gray-400 dark:text-zinc-500 transition hover:bg-sky-50 hover:text-sky-600 dark:group-hover:text-white"
                          title="Voir profil"
                        >
                          <Eye className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => setPrintTarget(c)}
                          className="rounded-lg p-2 text-gray-400 dark:text-zinc-500 transition hover:bg-sky-50 hover:text-sky-600 dark:group-hover:text-white"
                          title="Imprimer la fiche"
                        >
                          <Printer className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => openEdit(c)}
                          className="rounded-lg p-2 text-gray-400 dark:text-zinc-500 transition hover:bg-amber-50 hover:text-amber-600 dark:group-hover:text-white"
                          title="Modifier"
                        >
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => setDeleteTarget(c)}
                          className="rounded-lg p-2 text-gray-400 dark:text-zinc-500 transition hover:bg-rose-50 hover:text-rose-500 dark:group-hover:text-white"
                          title="Supprimer"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                )
              })}
              {visible.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-5 py-10 text-center text-sm text-gray-400 dark:text-zinc-500">
                    Aucun client dans cette vue
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between border-t border-gray-100 px-5 py-3 text-xs text-gray-400 dark:border-white/10 dark:text-zinc-500">
          <p>
            Affichage de {visible.length} sur {clients.length} client(s) enregistré(s)
          </p>
        </div>
      </motion.div>

      {/* Edit modal */}
      <Modal open={editModalOpen} onClose={() => setEditModalOpen(false)} title="Modifier le client" maxWidth="max-w-sm">
        <div className="space-y-4">
          <div>
            <label className="field-label">Nom complet *</label>
            <input
              type="text"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="ex: Ahmed Bennani"
              className="input-field"
            />
          </div>
          <div>
            <label className="field-label">Téléphone</label>
            <input
              type="tel"
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              placeholder="06 XX XX XX XX"
              className="input-field"
            />
          </div>
          <div className="grid grid-cols-2 gap-3 pt-2">
            <button onClick={() => setEditModalOpen(false)} className="btn-secondary">
              Annuler
            </button>
            <button onClick={saveForm} className="btn-primary">
              Enregistrer
            </button>
          </div>
        </div>
      </Modal>

      {/* Settle credit modal */}
      <Modal
        open={!!settleTarget}
        onClose={() => setSettleTarget(null)}
        title="Encaisser un règlement"
        maxWidth="max-w-sm"
      >
        <p className="text-sm text-gray-600 dark:text-zinc-400">
          <span className="font-semibold text-gray-900 dark:text-white">{settleTarget?.name}</span> doit{' '}
          <span className="font-bold text-rose-600 dark:text-rose-400 tabular-nums">{fmtDH(settleTarget?.credit ?? 0)}</span>
        </p>
        <div className="mt-4">
          <label className="field-label">Montant reçu (DH)</label>
          <input
            type="number"
            min="0"
            value={settleAmount}
            onChange={(e) => setSettleAmount(e.target.value)}
            className="input-field"
            autoFocus
          />
        </div>
        <div className="mt-5 grid grid-cols-2 gap-3">
          <button onClick={() => setSettleTarget(null)} className="btn-secondary">
            Annuler
          </button>
          <button onClick={confirmSettle} className="btn-primary">
            <HandCoins className="h-4 w-4" />
            Encaisser
          </button>
        </div>
      </Modal>

      {/* Delete confirm */}
      <Modal
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        title="Supprimer le client ?"
        maxWidth="max-w-sm"
      >
        <p className="text-sm text-gray-600 dark:text-zinc-400">
          <span className="font-semibold text-gray-900 dark:text-white">{deleteTarget?.name}</span> sera supprimé
          définitivement.
          {deleteTarget && deleteTarget.credit > 0 && (
            <span className="mt-1 block font-semibold text-rose-600 dark:text-rose-400">
              Attention : ce client a un crédit de {fmtDH(deleteTarget.credit)}.
            </span>
          )}
        </p>
        <div className="mt-5 grid grid-cols-2 gap-3">
          <button onClick={() => setDeleteTarget(null)} className="btn-secondary">
            Annuler
          </button>
          <button onClick={confirmDelete} className="btn-danger">
            <Trash2 className="h-4 w-4" />
            Supprimer
          </button>
        </div>
      </Modal>

      {/* Client profile */}
      <Modal open={!!profileTarget} onClose={() => setProfileTarget(null)} title="Profil client" maxWidth="max-w-lg">
        {profileTarget && (
          <>
            <div className="flex items-center gap-4">
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-500 text-lg font-bold text-gray-900">
                {initials(profileTarget.name)}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-lg font-bold text-gray-900 dark:text-white">{profileTarget.name}</p>
                <p className="text-sm text-gray-500 dark:text-zinc-400 tabular-nums">{profileTarget.phone || '—'}</p>
              </div>
              <span className={`rounded-full border px-3 py-1 text-[10px] font-black uppercase ${SEGMENT_CHIP[segmentOf(profileTarget)]}`}>
                {segmentOf(profileTarget)}
              </span>
            </div>

            <div className="mt-4 grid grid-cols-3 gap-3">
              <div className="rounded-xl bg-gray-50 dark:bg-white/5 p-3 text-center">
                <p className="text-[10px] font-semibold uppercase tracking-wide text-gray-400 dark:text-zinc-500">Dépensé</p>
                <p className="mt-1 text-sm font-bold text-gray-900 dark:text-white tabular-nums">{fmtDH(profileTarget.totalSpent)}</p>
              </div>
              <div className="rounded-xl bg-gray-50 dark:bg-white/5 p-3 text-center">
                <p className="text-[10px] font-semibold uppercase tracking-wide text-gray-400 dark:text-zinc-500">Points</p>
                <p className="mt-1 text-sm font-bold text-amber-600 dark:text-amber-400 tabular-nums">⭐ {profileTarget.points}</p>
              </div>
              <div className="rounded-xl bg-gray-50 dark:bg-white/5 p-3 text-center">
                <p className="text-[10px] font-semibold uppercase tracking-wide text-gray-400 dark:text-zinc-500">Crédit</p>
                <p className={`mt-1 text-sm font-bold tabular-nums ${profileTarget.credit > 0 ? 'text-rose-600 dark:text-rose-400' : 'text-emerald-600 dark:text-emerald-400'}`}>
                  {fmtDH(profileTarget.credit)}
                </p>
              </div>
            </div>

            <p className="mt-5 text-xs font-bold uppercase tracking-wide text-gray-400 dark:text-zinc-500">
              Achats récents
            </p>
            <div className="mt-2 max-h-56 space-y-1.5 overflow-y-auto">
              {profileSales.map((s) => (
                <div key={s.id} className="flex items-center justify-between gap-3 rounded-xl bg-gray-50 dark:bg-white/5 px-3 py-2">
                  <div className="min-w-0">
                    <p className="text-xs text-gray-500 dark:text-zinc-400">
                      {new Date(s.date).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })}
                    </p>
                    <p className="text-[11px] text-gray-400 dark:text-zinc-500">
                      {s.items.reduce((a, i) => a + i.qty, 0)} article(s) · {PAYMENT_META[s.payment].label}
                    </p>
                  </div>
                  <p className="shrink-0 text-sm font-bold text-gray-900 dark:text-white tabular-nums">{fmtDH(s.total)}</p>
                </div>
              ))}
              {profileSales.length === 0 && (
                <p className="py-6 text-center text-sm text-gray-400 dark:text-zinc-500">Aucun achat enregistré</p>
              )}
            </div>

            {profileTarget.credit > 0 && (
              <button
                onClick={() => {
                  relancer(profileTarget)
                }}
                className="btn-secondary mt-4 w-full"
              >
                <BellRing className="h-4 w-4" />
                Relancer ce client
              </button>
            )}
          </>
        )}
      </Modal>

      {/* Printable fiche client */}
      <Modal open={!!printTarget} onClose={() => setPrintTarget(null)} title="Fiche client" maxWidth="max-w-md">
        {printTarget && (
          <>
            <div className="print-area rounded-xl border border-gray-200 bg-white p-5">
              <p className="text-lg font-bold text-gray-900">{printTarget.name}</p>
              <p className="text-xs text-gray-500">{segmentOf(printTarget)} · {printTarget.clientType}</p>
              <div className="my-3 border-t border-dashed border-gray-300" />
              <div className="space-y-1.5 text-sm text-gray-700">
                <p>Téléphone : <span className="font-semibold">{printTarget.phone || '—'}</span></p>
                <p>Email : <span className="font-semibold">{printTarget.email || '—'}</span></p>
                <p>Adresse : <span className="font-semibold">{printTarget.address || '—'}, {printTarget.city || '—'}</span></p>
                {printTarget.cin && <p>CIN : <span className="font-semibold">{printTarget.cin}</span></p>}
              </div>
              <div className="my-3 border-t border-dashed border-gray-300" />
              <div className="grid grid-cols-3 gap-2 text-center">
                <div>
                  <p className="text-[10px] uppercase text-gray-400">Dépensé</p>
                  <p className="font-bold text-gray-900">{fmtDH(printTarget.totalSpent)}</p>
                </div>
                <div>
                  <p className="text-[10px] uppercase text-gray-400">Points</p>
                  <p className="font-bold text-gray-900">{printTarget.points}</p>
                </div>
                <div>
                  <p className="text-[10px] uppercase text-gray-400">Crédit</p>
                  <p className="font-bold text-gray-900">{fmtDH(printTarget.credit)}</p>
                </div>
              </div>
              {printTarget.notes && (
                <>
                  <div className="my-3 border-t border-dashed border-gray-300" />
                  <p className="text-xs text-gray-500">{printTarget.notes}</p>
                </>
              )}
            </div>
            <button onClick={() => window.print()} className="btn-primary mt-4 w-full">
              <Printer className="h-4 w-4" />
              Imprimer
            </button>
          </>
        )}
      </Modal>
    </>
  )
}

export default function ClientsPage() {
  return (
    <AppShell>
      <ClientsContent />
    </AppShell>
  )
}
