'use client'

import React from 'react'
import { Ruler } from 'lucide-react'
import AppShell from '@/components/AppShell'
import AttributCrud from '@/components/AttributCrud'
import { useDroguerie } from '@/lib/store'

function Content() {
  const { ready, products, units, unitActions } = useDroguerie()
  if (!ready) {
    return <div className="flex h-64 items-center justify-center text-sm text-gray-400 dark:text-zinc-500">Chargement…</div>
  }
  return (
    <AttributCrud
      title="Unités"
      subtitle="Pièce, carton, sac, litre, kg… les unités de vente."
      icon={Ruler}
      items={units}
      usageOf={(name) => products.filter((p) => p.unit === name).length}
      actions={unitActions}
    />
  )
}

export default function UnitesPage() {
  return (
    <AppShell>
      <Content />
    </AppShell>
  )
}
