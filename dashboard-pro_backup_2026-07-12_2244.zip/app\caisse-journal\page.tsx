'use client'

import React, { useEffect, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import {
  ArrowDownCircle,
  ArrowUpCircle,
  Banknote,
  DoorClosed,
  DoorOpen,
  Landmark,
  Lock,
  Repeat,
  Wallet,
} from 'lucide-react'
import AppShell from '@/components/AppShell'
import Modal from '@/components/Modal'
import Select from '@/components/Select'
import { useToast } from '@/components/Toast'
import { fmtDH, useDroguerie } from '@/lib/store'

function Content() {
  const { ready, cash, sales, sessions, currentSession, expectedCash, openSession, closeSession, addCashEntry } =
    useDroguerie()
  const toast = useToast()

  const [openModal, setOpenModal] = useState(false)
  const [closeModal, setCloseModal] = useState(false)
  const [entryModal, setEntryModal] = useState<'depense' | 'recette' | null>(null)
  const [transferModal, setTransferModal] = useState(false)
  const [transferDirection, setTransferDirection] = useState<'sortie' | 'entree'>('sortie')
  const [openingAmount, setOpeningAmount] = useState('500')
  const [closingAmount, setClosingAmount] = useState('')
  const [entryLabel, setEntryLabel] = useState('')
  const [entryAmount, setEntryAmount] = useState('')
  const [transferAmount, setTransferAmount] = useState('')
  const urlConsumed = useRef(false)

  // Deep-link support from the sidebar "Caisse" submenu
  useEffect(() => {
    if (!ready || urlConsumed.current) return
    urlConsumed.current = true
    const action = new URLSearchParams(window.location.search).get('action')
    if (action === 'open' && !currentSession) setOpenModal(true)
    if (action === 'close' && currentSession) {
      setClosingAmount(String(Math.round(expectedCash(currentSession))))
      setCloseModal(true)
    }
    if (action === 'depense' && currentSession) setEntryModal('depense')
    if (action === 'recette' && currentSession) setEntryModal('recette')
    if (action === 'transfert' && currentSession) setTransferModal(true)
  }, [ready, currentSession, expectedCash])

  if (!ready) {
    return <div className="flex h-64 items-center justify-center text-sm text-gray-400 dark:text-zinc-500">Chargement…</div>
  }

  const since = currentSession?.openedAt ?? new Date(0).toISOString()
  const cashSales = sales
    .filter((s) => s.date >= since && (s.payment === 'especes' || s.payment === 'mixte'))
    .reduce((a, s) => a + s.total, 0)
  const sessionCash = cash.filter((c) => c.date >= since)
  const depenses = sessionCash.filter((c) => c.type === 'depense').reduce((a, c) => a + c.amount, 0)
  const expected = currentSession ? expectedCash(currentSession) : 0

  const cards = [
    { label: 'Fond de caisse', value: fmtDH(currentSession?.openingAmount ?? 0), icon: Wallet, cls: 'bg-amber-50 dark:bg-amber-500/10 text-amber-500' },
    { label: 'Ventes espèces', value: fmtDH(cashSales), icon: ArrowUpCircle, cls: 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-500 dark:text-emerald-400' },
    { label: 'Dépenses', value: fmtDH(depenses), icon: ArrowDownCircle, cls: 'bg-rose-50 dark:bg-rose-500/10 text-rose-500 dark:text-rose-400' },
    { label: 'Solde théorique', value: fmtDH(expected), icon: Banknote, cls: 'bg-sky-50 dark:bg-sky-500/10 text-sky-500 dark:text-sky-400' },
  ]

  const doOpen = () => {
    openSession(parseFloat(openingAmount.replace(',', '.')) || 0)
    toast('✓ Caisse ouverte')
    setOpenModal(false)
  }

  const doClose = () => {
    const counted = parseFloat(closingAmount.replace(',', '.')) || 0
    closeSession(counted)
    const diff = counted - expected
    toast(
      diff === 0
        ? '✓ Caisse fermée — comptes justes'
        : `Caisse fermée — écart de ${fmtDH(diff)}`,
      diff === 0 ? 'success' : 'error'
    )
    setCloseModal(false)
    setClosingAmount('')
  }

  const doEntry = () => {
    if (!entryModal) return
    const amount = parseFloat(entryAmount.replace(',', '.')) || 0
    if (!entryLabel.trim() || amount <= 0) {
      toast('Libellé et montant requis', 'error')
      return
    }
    addCashEntry(entryModal, entryLabel.trim(), amount)
    toast(`✓ ${entryModal === 'depense' ? 'Dépense' : 'Recette'} enregistrée`)
    setEntryModal(null)
    setEntryLabel('')
    setEntryAmount('')
  }

  const doTransfer = () => {
    const amount = parseFloat(transferAmount.replace(',', '.')) || 0
    if (amount <= 0) {
      toast('Montant invalide', 'error')
      return
    }
    const label = transferDirection === 'sortie' ? 'Transfert vers la banque' : 'Transfert depuis la banque'
    addCashEntry(transferDirection === 'sortie' ? 'depense' : 'recette', label, amount)
    toast(`✓ ${label} — ${fmtDH(amount)}`)
    setTransferModal(false)
    setTransferAmount('')
    setTransferDirection('sortie')
  }

  const closedSessions = sessions.filter((s) => s.closedAt)

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex flex-wrap items-end justify-between gap-4"
      >
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-3xl">Caisse</h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-zinc-400">
            {currentSession
              ? `Caisse ouverte depuis ${new Date(currentSession.openedAt).toLocaleString('fr-FR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}`
              : 'La caisse est fermée.'}
          </p>
        </div>
        <div className="flex flex-wrap gap-3">
          {currentSession ? (
            <>
              <button onClick={() => setEntryModal('recette')} className="btn-secondary">
                <ArrowUpCircle className="h-4 w-4 text-emerald-500 dark:text-emerald-400" />
                Recette
              </button>
              <button onClick={() => setEntryModal('depense')} className="btn-secondary">
                <ArrowDownCircle className="h-4 w-4 text-rose-500 dark:text-rose-400" />
                Dépense
              </button>
              <button onClick={() => setTransferModal(true)} className="btn-secondary">
                <Repeat className="h-4 w-4 text-sky-500 dark:text-sky-400" />
                Transfert
              </button>
              <button onClick={() => { setClosingAmount(String(Math.round(expected))); setCloseModal(true) }} className="btn-primary">
                <DoorClosed className="h-4 w-4" />
                Fermer la caisse
              </button>
            </>
          ) : (
            <button onClick={() => setOpenModal(true)} className="btn-primary">
              <DoorOpen className="h-4 w-4" />
              Ouvrir la caisse
            </button>
          )}
        </div>
      </motion.div>

      {currentSession && (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {cards.map((c, i) => (
            <motion.div
              key={c.label}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 * i, duration: 0.4 }}
              className="glass-card glass-card-hover p-5"
            >
              <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${c.cls}`}>
                <c.icon className="h-5 w-5" />
              </div>
              <p className="mt-4 text-[13px] font-medium text-gray-500 dark:text-zinc-400">{c.label}</p>
              <p className="mt-1 text-[22px] font-bold leading-none tracking-tight text-gray-900 dark:text-white tabular-nums">
                {c.value}
              </p>
            </motion.div>
          ))}
        </div>
      )}

      {!currentSession && (
        <div className="glass-card flex flex-col items-center gap-3 p-10 text-center">
          <Lock className="h-10 w-10 text-gray-300" />
          <p className="text-sm text-gray-500 dark:text-zinc-400">Ouvrez la caisse pour enregistrer les mouvements d&apos;espèces.</p>
        </div>
      )}

      {/* Journal */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15, duration: 0.4 }}
        className="glass-card overflow-hidden"
      >
        <div className="border-b border-gray-100 dark:border-white/10 px-5 py-4">
          <h2 className="text-base font-semibold text-gray-900 dark:text-white">Journal de caisse</h2>
          <p className="text-xs text-gray-500 dark:text-zinc-400">Dépenses et recettes (hors ventes)</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[560px]">
            <thead>
              <tr className="border-b border-gray-100 dark:border-white/10 text-left text-[11px] font-bold uppercase tracking-wider text-gray-400 dark:text-zinc-500">
                <th className="px-5 py-3">Date</th>
                <th className="px-5 py-3">Libellé</th>
                <th className="px-5 py-3">Type</th>
                <th className="px-5 py-3 text-right">Montant</th>
              </tr>
            </thead>
            <tbody>
              {cash.slice(0, 30).map((c) => (
                <tr key={c.id} className="border-b border-gray-50">
                  <td className="px-5 py-3 text-sm text-gray-600 dark:text-zinc-400">
                    {new Date(c.date).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short' })}{' '}
                    {new Date(c.date).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                  </td>
                  <td className="px-5 py-3 text-sm font-medium text-gray-900 dark:text-white">{c.label}</td>
                  <td className="px-5 py-3">
                    {c.label.startsWith('Transfert') ? (
                      <span className="rounded-lg border border-sky-200 dark:border-sky-500/20 bg-sky-50 dark:bg-sky-500/10 px-2 py-1 text-xs font-bold text-sky-700 dark:text-sky-400">
                        Transfert
                      </span>
                    ) : (
                      <span
                        className={`rounded-lg border px-2 py-1 text-xs font-bold ${
                          c.type === 'recette'
                            ? 'border-emerald-200 dark:border-emerald-500/20 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700'
                            : 'border-rose-200 dark:border-rose-500/20 bg-rose-50 dark:bg-rose-500/10 text-rose-700'
                        }`}
                      >
                        {c.type === 'recette' ? 'Recette' : 'Dépense'}
                      </span>
                    )}
                  </td>
                  <td
                    className={`px-5 py-3 text-right text-sm font-bold tabular-nums ${
                      c.type === 'recette' ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-500 dark:text-rose-400'
                    }`}
                  >
                    {c.type === 'recette' ? '+' : '−'}
                    {fmtDH(c.amount)}
                  </td>
                </tr>
              ))}
              {cash.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-5 py-8 text-center text-sm text-gray-400 dark:text-zinc-500">
                    Aucun mouvement de caisse
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Closed sessions history */}
      {closedSessions.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.4 }}
          className="glass-card overflow-hidden"
        >
          <div className="border-b border-gray-100 dark:border-white/10 px-5 py-4">
            <h2 className="text-base font-semibold text-gray-900 dark:text-white">Historique des fermetures</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[560px]">
              <thead>
                <tr className="border-b border-gray-100 dark:border-white/10 text-left text-[11px] font-bold uppercase tracking-wider text-gray-400 dark:text-zinc-500">
                  <th className="px-5 py-3">Ouverture</th>
                  <th className="px-5 py-3">Fermeture</th>
                  <th className="px-5 py-3">Attendu</th>
                  <th className="px-5 py-3">Compté</th>
                  <th className="px-5 py-3 text-right">Écart</th>
                </tr>
              </thead>
              <tbody>
                {closedSessions.map((s) => {
                  const diff = (s.closingAmount ?? 0) - (s.expectedAmount ?? 0)
                  return (
                    <tr key={s.id} className="border-b border-gray-50">
                      <td className="px-5 py-3 text-sm text-gray-600 dark:text-zinc-400">
                        {new Date(s.openedAt).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short' })}
                      </td>
                      <td className="px-5 py-3 text-sm text-gray-600 dark:text-zinc-400">
                        {s.closedAt && new Date(s.closedAt).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                      </td>
                      <td className="px-5 py-3 text-sm text-gray-600 dark:text-zinc-400 tabular-nums">{fmtDH(s.expectedAmount ?? 0)}</td>
                      <td className="px-5 py-3 text-sm font-semibold text-gray-900 dark:text-white tabular-nums">{fmtDH(s.closingAmount ?? 0)}</td>
                      <td
                        className={`px-5 py-3 text-right text-sm font-bold tabular-nums ${
                          diff === 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-500 dark:text-rose-400'
                        }`}
                      >
                        {diff > 0 ? '+' : ''}
                        {fmtDH(diff)}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </motion.div>
      )}

      {/* Open modal */}
      <Modal open={openModal} onClose={() => setOpenModal(false)} title="Ouvrir la caisse" maxWidth="max-w-sm">
        <label className="field-label">Fond de caisse (DH)</label>
        <input
          type="number"
          min="0"
          value={openingAmount}
          onChange={(e) => setOpeningAmount(e.target.value)}
          className="input-field"
          autoFocus
        />
        <div className="mt-5 grid grid-cols-2 gap-3">
          <button onClick={() => setOpenModal(false)} className="btn-secondary">Annuler</button>
          <button onClick={doOpen} className="btn-primary">Ouvrir</button>
        </div>
      </Modal>

      {/* Close modal */}
      <Modal open={closeModal} onClose={() => setCloseModal(false)} title="Fermer la caisse" maxWidth="max-w-sm">
        <div className="rounded-xl bg-gray-50 dark:bg-white/5 p-4 text-sm">
          <div className="flex justify-between text-gray-600 dark:text-zinc-400">
            <span>Solde théorique attendu</span>
            <span className="font-bold text-gray-900 dark:text-white tabular-nums">{fmtDH(expected)}</span>
          </div>
        </div>
        <div className="mt-4">
          <label className="field-label">Montant compté dans le tiroir (DH)</label>
          <input
            type="number"
            min="0"
            value={closingAmount}
            onChange={(e) => setClosingAmount(e.target.value)}
            className="input-field"
            autoFocus
          />
          {closingAmount !== '' && (
            <p
              className={`mt-1.5 text-xs font-semibold tabular-nums ${
                (parseFloat(closingAmount.replace(',', '.')) || 0) - expected === 0
                  ? 'text-emerald-600 dark:text-emerald-400'
                  : 'text-rose-500 dark:text-rose-400'
              }`}
            >
              Écart : {fmtDH((parseFloat(closingAmount.replace(',', '.')) || 0) - expected)}
            </p>
          )}
        </div>
        <div className="mt-5 grid grid-cols-2 gap-3">
          <button onClick={() => setCloseModal(false)} className="btn-secondary">Annuler</button>
          <button onClick={doClose} className="btn-primary">
            <DoorClosed className="h-4 w-4" />
            Fermer
          </button>
        </div>
      </Modal>

      {/* Entry modal */}
      <Modal
        open={!!entryModal}
        onClose={() => setEntryModal(null)}
        title={entryModal === 'depense' ? 'Nouvelle dépense' : 'Nouvelle recette'}
        maxWidth="max-w-sm"
      >
        <div className="space-y-4">
          <div>
            <label className="field-label">Libellé</label>
            <input
              type="text"
              value={entryLabel}
              onChange={(e) => setEntryLabel(e.target.value)}
              placeholder={entryModal === 'depense' ? 'ex: Transport, électricité…' : 'ex: Apport, divers…'}
              className="input-field"
            />
          </div>
          <div>
            <label className="field-label">Montant (DH)</label>
            <input
              type="number"
              min="0"
              value={entryAmount}
              onChange={(e) => setEntryAmount(e.target.value)}
              className="input-field"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <button onClick={() => setEntryModal(null)} className="btn-secondary">Annuler</button>
            <button onClick={doEntry} className="btn-primary">Enregistrer</button>
          </div>
        </div>
      </Modal>

      {/* Transfer modal */}
      <Modal open={transferModal} onClose={() => setTransferModal(false)} title="Transfert" maxWidth="max-w-sm">
        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-sky-50 dark:bg-sky-500/10 text-sky-500 dark:text-sky-400">
              <Landmark className="h-5 w-5" />
            </span>
            <p className="text-sm text-gray-600 dark:text-zinc-400">
              Déplacez de l&apos;argent entre le tiroir-caisse et la banque (ou le coffre).
            </p>
          </div>
          <div>
            <label className="field-label">Direction</label>
            <Select
              value={transferDirection}
              onChange={(v) => setTransferDirection(v as 'sortie' | 'entree')}
              options={[
                { value: 'sortie', label: 'Vers la banque (sortie de caisse)' },
                { value: 'entree', label: 'Depuis la banque (entrée en caisse)' },
              ]}
            />
          </div>
          <div>
            <label className="field-label">Montant (DH)</label>
            <input
              type="number"
              min="0"
              value={transferAmount}
              onChange={(e) => setTransferAmount(e.target.value)}
              className="input-field"
              autoFocus
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <button onClick={() => setTransferModal(false)} className="btn-secondary">Annuler</button>
            <button onClick={doTransfer} className="btn-primary">
              <Repeat className="h-4 w-4" />
              Transférer
            </button>
          </div>
        </div>
      </Modal>
    </>
  )
}

export default function CaisseJournalPage() {
  return (
    <AppShell>
      <Content />
    </AppShell>
  )
}
