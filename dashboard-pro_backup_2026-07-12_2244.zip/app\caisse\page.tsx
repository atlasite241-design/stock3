'use client'

import React, { useEffect, useMemo, useRef, useState } from 'react'
import Link from 'next/link'
import { useRouter, useSearchParams } from 'next/navigation'
import { motion } from 'framer-motion'
import {
  Banknote,
  Barcode,
  Camera,
  CreditCard,
  Layers,
  Minus,
  PauseCircle,
  PlayCircle,
  Plus,
  Printer,
  Search,
  ShoppingCart,
  Trash2,
  Wallet,
} from 'lucide-react'
import AppShell from '@/components/AppShell'
import Modal from '@/components/Modal'
import CameraScanner from '@/components/CameraScanner'
import PaymentModal from '@/components/PaymentModal'
import Select from '@/components/Select'
import { useToast } from '@/components/Toast'
import {
  fmtDH,
  loadHeldSales,
  PAYMENT_META,
  saveHeldSales,
  useDroguerie,
  uid,
  type HeldSale,
  type Product,
  type Sale,
  type SaleItem,
} from '@/lib/store'

function CaisseContent() {
  const { ready, products, clients, settings, recordSale, currentSession, openSession } = useDroguerie()
  const toast = useToast()

  const [cart, setCart] = useState<SaleItem[]>([])
  const [category, setCategory] = useState('Tous')
  const [query, setQuery] = useState('')
  const [payment, setPayment] = useState<Sale['payment']>('especes')
  const [clientId, setClientId] = useState('')
  const [receipt, setReceipt] = useState<Sale | null>(null)
  const [cameraOpen, setCameraOpen] = useState(false)
  const [held, setHeld] = useState<HeldSale[]>([])
  const [resumeOpen, setResumeOpen] = useState(false)
  const [openCaisseModal, setOpenCaisseModal] = useState(false)
  const [openingAmount, setOpeningAmount] = useState('500')
  const [cartSheetOpen, setCartSheetOpen] = useState(false)
  const [paymentSheetOpen, setPaymentSheetOpen] = useState(false)
  const barcodeRef = useRef<HTMLInputElement>(null)
  const searchRef = useRef<HTMLInputElement>(null)
  const lastQuery = useRef('')
  const router = useRouter()
  const searchParams = useSearchParams()

  useEffect(() => {
    setHeld(loadHeldSales())
  }, [])

  // Broadcast cart state so the sidebar can enable/disable "Suspendre une vente"
  useEffect(() => {
    const count = cart.reduce((a, i) => a + i.qty, 0)
    sessionStorage.setItem('dp_cart_count', String(count))
    window.dispatchEvent(new Event('droguerie-cart-change'))
    return () => {
      sessionStorage.setItem('dp_cart_count', '0')
      window.dispatchEvent(new Event('droguerie-cart-change'))
    }
  }, [cart])

  const inCart = (id: string) => cart.find((i) => i.productId === id)?.qty ?? 0

  const addToCart = (p: Product) => {
    if (p.stock <= 0) {
      toast(`${p.name} — rupture de stock`, 'error')
      return
    }
    if (inCart(p.id) >= p.stock) {
      toast(`Stock insuffisant — ${p.name} (${p.stock} disponibles)`, 'error')
      return
    }
    setCart((c) => {
      const ex = c.find((i) => i.productId === p.id)
      return ex
        ? c.map((i) => (i.productId === p.id ? { ...i, qty: i.qty + 1 } : i))
        : [...c, { productId: p.id, name: p.name, price: p.price, qty: 1 }]
    })
    toast(`✓ ${p.name} ajouté`)
  }

  const handleScan = (code: string) => {
    const c = code.trim()
    if (!c) return
    const p = products.find((x) => x.barcode === c)
    if (!p) {
      toast(`Produit introuvable : ${c}`, 'error')
      return
    }
    addToCart(p)
  }

  const handleScanRef = useRef(handleScan)
  handleScanRef.current = handleScan

  useEffect(() => {
    if (!ready) return
    const consume = () => {
      const code = sessionStorage.getItem('pendingScan')
      if (code) {
        sessionStorage.removeItem('pendingScan')
        handleScanRef.current(code)
      }
    }
    consume()
    window.addEventListener('droguerie-scan', consume)
    return () => window.removeEventListener('droguerie-scan', consume)
  }, [ready])

  useEffect(() => {
    if (ready) barcodeRef.current?.focus()
  }, [ready])

  // Deep-link support from the sidebar "Point de vente (POS)" submenu
  useEffect(() => {
    if (!ready) return
    const qs = searchParams.toString()
    if (!qs || qs === lastQuery.current) return
    lastQuery.current = qs
    if (searchParams.get('camera') === '1') setCameraOpen(true)
    if (searchParams.get('focus') === 'search') setTimeout(() => searchRef.current?.focus(), 50)
    if (searchParams.get('payment') === 'mixte') setPayment('mixte')
    if (searchParams.get('resume') === '1' && held.length > 0) setResumeOpen(true)
    if (searchParams.get('suspend') === '1') {
      if (cart.length > 0) holdSale()
      else toast('Le panier est vide — rien à suspendre', 'error')
    }
    router.replace('/caisse', { scroll: false })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, held, cart, searchParams])

  const categories = useMemo(
    () => ['Tous', ...Array.from(new Set(products.map((p) => p.category)))],
    [products]
  )

  const filtered = products.filter((p) => {
    const okCat = category === 'Tous' || p.category === category
    const q = query.trim().toLowerCase()
    const okQuery = !q || p.name.toLowerCase().includes(q) || p.barcode.includes(q)
    return okCat && okQuery
  })

  const changeQty = (id: string, delta: number) => {
    const p = products.find((x) => x.id === id)
    setCart((c) =>
      c.flatMap((i) => {
        if (i.productId !== id) return [i]
        const q = i.qty + delta
        if (q <= 0) return []
        if (p && q > p.stock) return [i]
        return [{ ...i, qty: q }]
      })
    )
  }

  const removeItem = (id: string) => setCart((c) => c.filter((i) => i.productId !== id))

  const total = cart.reduce((a, i) => a + i.price * i.qty, 0)

  const holdSale = () => {
    if (cart.length === 0) return
    const h: HeldSale = {
      id: uid(),
      date: new Date().toISOString(),
      items: cart,
      clientId,
      label: `${cart.reduce((a, i) => a + i.qty, 0)} art. — ${fmtDH(total)}`,
    }
    const next = [h, ...held]
    setHeld(next)
    saveHeldSales(next)
    setCart([])
    setClientId('')
    setCartSheetOpen(false)
    toast('Vente suspendue — reprenez-la à tout moment')
    barcodeRef.current?.focus()
  }

  const resumeSale = (h: HeldSale) => {
    setCart(h.items)
    setClientId(h.clientId)
    const next = held.filter((x) => x.id !== h.id)
    setHeld(next)
    saveHeldSales(next)
    setResumeOpen(false)
    toast('✓ Vente reprise')
  }

  const finalize = (receivedAmount?: number, autoPrint?: boolean) => {
    if (cart.length === 0) return
    if (payment === 'credit' && !clientId) {
      toast('Sélectionnez un client pour le paiement à crédit', 'error')
      return
    }
    const client = clients.find((c) => c.id === clientId) ?? null
    const sale = recordSale(cart, payment, client)
    setReceipt(sale)
    setCart([])
    setClientId('')
    setPayment('especes')
    setCartSheetOpen(false)
    setPaymentSheetOpen(false)
    if (receivedAmount !== undefined && payment === 'especes' && receivedAmount > sale.total) {
      toast(`Monnaie à rendre : ${fmtDH(receivedAmount - sale.total)}`)
    }
    if (client) {
      const pts = Math.floor(sale.total / 50)
      if (pts > 0) toast(`⭐ ${client.name} gagne ${pts} point(s) fidélité`)
    }
    if (autoPrint) {
      setTimeout(() => window.print(), 300)
    }
  }

  const closeReceipt = () => {
    setReceipt(null)
    barcodeRef.current?.focus()
  }

  if (!ready) {
    return <div className="flex h-64 items-center justify-center text-sm text-gray-400 dark:text-zinc-500">Chargement…</div>
  }

  const paymentOptions: { key: Sale['payment']; label: string; icon: typeof Banknote }[] = [
    { key: 'especes', label: 'Espèces', icon: Banknote },
    { key: 'carte', label: 'Carte', icon: CreditCard },
    { key: 'credit', label: 'Crédit', icon: Wallet },
    { key: 'mixte', label: 'Mixte', icon: Layers },
  ]

  const cartItemCount = cart.reduce((a, i) => a + i.qty, 0)

  const cartPanel = (
    <>
      <div className="flex items-center justify-between lg:hidden">
        <h2 className="flex items-center gap-2 text-base font-semibold text-gray-900 dark:text-white">
          <ShoppingCart className="h-4 w-4 text-amber-500" />
          Panier
        </h2>
        <span className="rounded-lg bg-amber-50 dark:bg-amber-500/10 px-2 py-1 text-xs font-bold text-amber-700 dark:text-amber-300 tabular-nums">
          {cartItemCount} article(s)
        </span>
      </div>

      <div className="max-h-[45vh] space-y-2 overflow-y-auto pr-1 lg:max-h-[260px]">
        {cart.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-10 text-center">
            <ShoppingCart className="h-8 w-8 text-gray-300" />
            <p className="text-sm text-gray-400 dark:text-zinc-500">Panier vide — scannez un produit</p>
          </div>
        ) : (
          cart.map((i) => (
            <div key={i.productId} className="rounded-xl border border-gray-100 dark:border-white/10 bg-gray-50/60 dark:bg-white/5 p-3">
              <div className="flex items-start justify-between gap-2">
                <p className="text-sm font-medium text-gray-900 dark:text-white">{i.name}</p>
                <button
                  onClick={() => removeItem(i.productId)}
                  className="shrink-0 rounded-lg p-2 -m-1 text-gray-400 dark:text-zinc-500 transition hover:bg-rose-50 hover:text-rose-500"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
              <div className="mt-2 flex items-center justify-between">
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => changeQty(i.productId, -1)}
                    className="flex h-9 w-9 items-center justify-center rounded-lg border border-gray-200 dark:border-white/10 bg-white dark:bg-[#12121a] text-gray-600 dark:text-zinc-400 transition hover:border-amber-300 hover:bg-amber-50 lg:h-7 lg:w-7"
                  >
                    <Minus className="h-3.5 w-3.5" />
                  </button>
                  <span className="w-8 text-center text-sm font-bold text-gray-900 dark:text-white tabular-nums">
                    {i.qty}
                  </span>
                  <button
                    onClick={() => changeQty(i.productId, 1)}
                    className="flex h-9 w-9 items-center justify-center rounded-lg border border-gray-200 dark:border-white/10 bg-white dark:bg-[#12121a] text-gray-600 dark:text-zinc-400 transition hover:border-amber-300 hover:bg-amber-50 lg:h-7 lg:w-7"
                  >
                    <Plus className="h-3.5 w-3.5" />
                  </button>
                </div>
                <p className="text-sm font-bold text-gray-900 dark:text-white tabular-nums">{fmtDH(i.price * i.qty)}</p>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Payment */}
      <div className="mt-4 border-t border-gray-100 dark:border-white/10 pt-4">
        <p className="field-label">Mode de paiement</p>
        <div className="grid grid-cols-4 gap-2">
          {paymentOptions.map((o) => (
            <button
              key={o.key}
              onClick={() => setPayment(o.key)}
              className={`flex flex-col items-center gap-1 rounded-xl border p-2 text-[11px] font-semibold transition ${
                payment === o.key
                  ? 'border-amber-400 dark:border-amber-500/40 bg-amber-50 dark:bg-amber-500/10 text-amber-800 dark:text-amber-300'
                  : 'border-gray-200 dark:border-white/10 bg-white dark:bg-[#12121a] text-gray-500 dark:text-zinc-400 hover:border-amber-200'
              }`}
            >
              <o.icon className="h-4 w-4" />
              {o.label}
            </button>
          ))}
        </div>

        <div className="mt-3">
          <p className="field-label">
            Client{' '}
            {payment === 'credit' ? <span className="text-rose-500 dark:text-rose-400">(requis)</span> : '(optionnel — points fidélité)'}
          </p>
          <Select
            value={clientId}
            onChange={setClientId}
            placeholder="— Aucun client —"
            options={[
              { value: '', label: '— Aucun client —' },
              ...clients.map((c) => ({ value: c.id, label: `${c.name} (${c.points} pts)` })),
            ]}
          />
        </div>

        <p className="mt-3 text-xs text-gray-400 dark:text-zinc-500">
          Le montant reçu et la monnaie se saisissent à l&apos;écran d&apos;encaissement.
        </p>
      </div>

      {/* Total */}
      <div className="mt-4 rounded-xl bg-gradient-to-r from-amber-50 dark:from-amber-500/10 to-yellow-50 dark:to-yellow-500/5 p-4">
        <div className="flex items-center justify-between">
          <span className="text-sm font-semibold text-gray-600 dark:text-zinc-400">Total</span>
          <span className="text-2xl font-bold tracking-tight text-gray-900 dark:text-white tabular-nums">
            {fmtDH(total)}
          </span>
        </div>
      </div>

      <button
        onClick={() => {
          if (payment === 'credit' && !clientId) {
            toast('Sélectionnez un client pour le paiement à crédit', 'error')
            return
          }
          setPaymentSheetOpen(true)
        }}
        disabled={cart.length === 0}
        className="btn-primary mt-4 h-12 w-full text-base"
      >
        Encaisser {total > 0 ? fmtDH(total) : ''}
      </button>
    </>
  )

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex flex-wrap items-end justify-between gap-4"
      >
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-3xl">
            Point de vente
          </h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-zinc-400">
            Scannez, encaissez, suspendez — tout se met à jour automatiquement.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          {held.length > 0 && (
            <button onClick={() => setResumeOpen(true)} className="btn-secondary">
              <PlayCircle className="h-4 w-4 text-amber-500" />
              Reprendre ({held.length})
            </button>
          )}
          <button onClick={holdSale} disabled={cart.length === 0} className="btn-secondary disabled:opacity-50">
            <PauseCircle className="h-4 w-4" />
            Suspendre
          </button>
        </div>
      </motion.div>

      {/* Register status banner */}
      {!currentSession && (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-amber-300 dark:border-amber-500/30 bg-amber-50 dark:bg-amber-500/10 px-5 py-3.5">
          <p className="text-sm font-semibold text-amber-800 dark:text-amber-300">
            ⚠ La caisse n&apos;est pas ouverte — ouvrez une session pour suivre les espèces.
          </p>
          <div className="flex gap-2">
            <button onClick={() => setOpenCaisseModal(true)} className="btn-primary !h-9 text-xs">
              Ouvrir la caisse
            </button>
            <Link href="/caisse-journal" className="btn-secondary !h-9 text-xs">
              Journal de caisse
            </Link>
          </div>
        </div>
      )}

      <div className="grid items-start gap-6 pb-24 lg:grid-cols-[1fr_380px] lg:pb-0">
        {/* LEFT — products */}
        <div className="space-y-4">
          {/* Barcode scanner input */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05, duration: 0.4 }}
            className="glass-card border-amber-300 dark:border-amber-500/30 p-4 shadow-glow"
          >
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Barcode className="absolute left-3.5 top-1/2 h-5 w-5 -translate-y-1/2 text-amber-500" />
                <input
                  ref={barcodeRef}
                  type="text"
                  placeholder="Scanner ou saisir le code-barres puis Entrée…"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      handleScan(e.currentTarget.value)
                      e.currentTarget.value = ''
                    }
                  }}
                  className="h-12 w-full rounded-xl border border-amber-200 dark:border-amber-500/20 bg-amber-50/50 dark:bg-white/5 pl-11 pr-4 text-base font-medium text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-zinc-500 outline-none transition focus:border-amber-400 focus:bg-white dark:focus:bg-white/[0.08] focus:ring-2 focus:ring-amber-400/25"
                />
              </div>
              <button
                onClick={() => setCameraOpen(true)}
                className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-amber-200 dark:border-amber-500/20 bg-white dark:bg-[#12121a] text-amber-500 transition hover:bg-amber-50"
                title="Scanner avec la caméra"
              >
                <Camera className="h-5 w-5" />
              </button>
            </div>
            <p className="mt-2 text-xs text-gray-500 dark:text-zinc-400">
              Douchette USB ou caméra — essayez :{' '}
              <span className="font-mono font-semibold text-amber-600 dark:text-amber-400">6118000040972</span> (Javel 5L)
            </p>
          </motion.div>

          {/* Search + categories */}
          <div className="space-y-3">
            <div className="relative">
              <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400 dark:text-zinc-500" />
              <input
                type="text"
                ref={searchRef}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Rechercher un produit…"
                className="input-field pl-10"
              />
            </div>
            <div className="flex flex-wrap gap-2">
              {categories.map((c) => (
                <button
                  key={c}
                  onClick={() => setCategory(c)}
                  className={`rounded-xl px-3.5 py-2 text-xs font-semibold transition ${
                    category === c
                      ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-gray-900 shadow-lg shadow-amber-400/25'
                      : 'border border-gray-200 dark:border-white/10 bg-white dark:bg-[#12121a] text-gray-600 dark:text-zinc-400 hover:border-amber-300 hover:bg-amber-50'
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>

          {/* Product grid */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">
            {filtered.map((p) => (
              <button
                key={p.id}
                onClick={() => addToCart(p)}
                disabled={p.stock <= 0}
                className="glass-card glass-card-hover p-4 text-left disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:translate-y-0"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="truncate rounded-md bg-gray-100 dark:bg-white/10 px-1.5 py-0.5 text-[10px] font-semibold text-gray-500 dark:text-zinc-400">
                    {p.category}
                  </span>
                  <span
                    className={`shrink-0 rounded-md px-1.5 py-0.5 text-[10px] font-bold ${
                      p.stock === 0
                        ? 'bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400'
                        : p.stock <= p.minStock
                          ? 'bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400'
                          : 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                    }`}
                  >
                    {p.stock === 0 ? 'Rupture' : `${p.stock} en stock`}
                  </span>
                </div>
                <p className="mt-2.5 line-clamp-2 min-h-[40px] text-sm font-semibold text-gray-900 dark:text-white">
                  {p.name}
                </p>
                <p className="mt-1 text-base font-bold text-amber-600 dark:text-amber-400 tabular-nums">{fmtDH(p.price)}</p>
              </button>
            ))}
            {filtered.length === 0 && (
              <p className="col-span-full py-10 text-center text-sm text-gray-400 dark:text-zinc-500">Aucun produit trouvé</p>
            )}
          </div>
        </div>

        {/* RIGHT — cart (desktop / tablet landscape sidebar) */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.4 }}
          className="glass-card hidden p-5 lg:sticky lg:top-20 lg:block"
        >
          <div className="hidden items-center justify-between lg:flex">
            <h2 className="flex items-center gap-2 text-base font-semibold text-gray-900 dark:text-white">
              <ShoppingCart className="h-4 w-4 text-amber-500" />
              Panier
            </h2>
            <span className="rounded-lg bg-amber-50 dark:bg-amber-500/10 px-2 py-1 text-xs font-bold text-amber-700 dark:text-amber-300 tabular-nums">
              {cartItemCount} article(s)
            </span>
          </div>
          <div className="mt-4">{cartPanel}</div>
        </motion.div>
      </div>

      {/* Mobile / tablet portrait — floating cart bar, opens the cart as a bottom sheet */}
      {cart.length > 0 && (
        <button
          onClick={() => setCartSheetOpen(true)}
          className="fixed inset-x-3 bottom-3 z-40 flex items-center justify-between gap-3 rounded-2xl bg-gray-900 px-5 py-4 text-white shadow-2xl lg:hidden"
        >
          <span className="flex items-center gap-2 text-sm font-semibold">
            <ShoppingCart className="h-5 w-5 text-amber-400" />
            {cartItemCount} article(s)
          </span>
          <span className="flex items-center gap-2 text-base font-bold tabular-nums">
            {fmtDH(total)}
            <span className="rounded-lg bg-amber-400 px-3 py-1.5 text-xs font-bold text-gray-900 dark:text-white">
              Voir le panier
            </span>
          </span>
        </button>
      )}

      <Modal open={cartSheetOpen} onClose={() => setCartSheetOpen(false)} title="Panier" maxWidth="max-w-lg">
        {cartPanel}
      </Modal>

      {/* Checkout / payment screen */}
      <PaymentModal
        open={paymentSheetOpen}
        onClose={() => setPaymentSheetOpen(false)}
        total={total}
        payment={payment}
        onPaymentChange={setPayment}
        clientSelected={!!clientId}
        onConfirm={(receivedAmount, print) => finalize(receivedAmount, print)}
      />

      {/* Camera scanner */}
      <CameraScanner open={cameraOpen} onClose={() => setCameraOpen(false)} onDetect={(code) => handleScan(code)} />

      {/* Resume held sales */}
      <Modal open={resumeOpen} onClose={() => setResumeOpen(false)} title="Ventes suspendues" maxWidth="max-w-sm">
        <div className="space-y-2">
          {held.map((h) => (
            <button
              key={h.id}
              onClick={() => resumeSale(h)}
              className="flex w-full items-center justify-between gap-3 rounded-xl border border-gray-200 dark:border-white/10 bg-gray-50/60 dark:bg-white/5 px-4 py-3 text-left transition hover:border-amber-300 hover:bg-amber-50"
            >
              <div>
                <p className="text-sm font-semibold text-gray-900 dark:text-white">{h.label}</p>
                <p className="text-xs text-gray-500 dark:text-zinc-400">
                  {new Date(h.date).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
              <PlayCircle className="h-5 w-5 shrink-0 text-amber-500" />
            </button>
          ))}
          {held.length === 0 && <p className="py-6 text-center text-sm text-gray-400 dark:text-zinc-500">Aucune vente suspendue</p>}
        </div>
      </Modal>

      {/* Open register */}
      <Modal open={openCaisseModal} onClose={() => setOpenCaisseModal(false)} title="Ouvrir la caisse" maxWidth="max-w-sm">
        <p className="text-sm text-gray-600 dark:text-zinc-400">Montant en espèces dans le tiroir au démarrage.</p>
        <div className="mt-4">
          <label className="field-label">Fond de caisse (DH)</label>
          <input
            type="number"
            min="0"
            value={openingAmount}
            onChange={(e) => setOpeningAmount(e.target.value)}
            className="input-field"
            autoFocus
          />
        </div>
        <div className="mt-5 grid grid-cols-2 gap-3">
          <button onClick={() => setOpenCaisseModal(false)} className="btn-secondary">
            Annuler
          </button>
          <button
            onClick={() => {
              openSession(parseFloat(openingAmount.replace(',', '.')) || 0)
              setOpenCaisseModal(false)
            }}
            className="btn-primary"
          >
            Ouvrir
          </button>
        </div>
      </Modal>

      {/* Receipt modal */}
      <Modal open={!!receipt} onClose={closeReceipt} title="Vente enregistrée ✓" maxWidth="max-w-sm">
        {receipt && (
          <>
            <div className="print-area rounded-xl border border-dashed border-gray-300 dark:border-white/15 bg-gray-50/60 dark:bg-white/5 p-4 font-mono text-sm">
              <p className="text-center text-base font-bold text-gray-900 dark:text-white">{settings.storeName}</p>
              <p className="text-center text-xs text-gray-500 dark:text-zinc-400">{settings.address}</p>
              <p className="text-center text-xs text-gray-500 dark:text-zinc-400">{settings.phone}</p>
              <p className="mt-1 text-center text-xs text-gray-500 dark:text-zinc-400">
                {new Date(receipt.date).toLocaleString('fr-FR')}
              </p>
              <div className="my-3 border-t border-dashed border-gray-300 dark:border-white/15" />
              {receipt.items.map((i) => (
                <div key={i.productId} className="flex justify-between gap-2 text-xs text-gray-700 dark:text-zinc-300">
                  <span className="min-w-0 flex-1 truncate">
                    {i.qty} × {i.name}
                  </span>
                  <span className="shrink-0 tabular-nums">{fmtDH(i.price * i.qty)}</span>
                </div>
              ))}
              <div className="my-3 border-t border-dashed border-gray-300 dark:border-white/15" />
              <div className="flex justify-between text-base font-bold text-gray-900 dark:text-white">
                <span>TOTAL</span>
                <span className="tabular-nums">{fmtDH(receipt.total)}</span>
              </div>
              <p className="mt-1 text-xs text-gray-600 dark:text-zinc-400">
                Paiement : {PAYMENT_META[receipt.payment].label}
                {receipt.clientName ? ` — ${receipt.clientName}` : ''}
              </p>
              <p className="mt-3 text-center text-xs text-gray-500 dark:text-zinc-400">{settings.ticketMessage}</p>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-3">
              <button onClick={() => window.print()} className="btn-secondary">
                <Printer className="h-4 w-4" />
                Imprimer
              </button>
              <button onClick={closeReceipt} className="btn-primary">
                Nouvelle vente
              </button>
            </div>
          </>
        )}
      </Modal>
    </>
  )
}

export default function CaissePage() {
  return (
    <AppShell>
      <CaisseContent />
    </AppShell>
  )
}
