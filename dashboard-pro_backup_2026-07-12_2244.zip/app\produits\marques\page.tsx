'use client'

import React from 'react'
import { Tag } from 'lucide-react'
import AppShell from '@/components/AppShell'
import AttributCrud from '@/components/AttributCrud'
import { useDroguerie } from '@/lib/store'

function Content() {
  const { ready, products, brands, brandActions } = useDroguerie()
  if (!ready) {
    return <div className="flex h-64 items-center justify-center text-sm text-gray-400 dark:text-zinc-500">Chargement…</div>
  }
  return (
    <AttributCrud
      title="Marques"
      subtitle="Les marques référencées dans votre catalogue."
      icon={Tag}
      items={brands}
      usageOf={(name) => products.filter((p) => p.brand === name).length}
      actions={brandActions}
    />
  )
}

export default function MarquesPage() {
  return (
    <AppShell>
      <Content />
    </AppShell>
  )
}
