'use client'

import { useCallback, useEffect, useState } from 'react'

// ------------------------------------------------------------------
// Types
// ------------------------------------------------------------------

export interface Product {
  id: string
  name: string
  barcode: string
  category: string
  brand: string
  unit: string
  price: number
  cost: number
  stock: number
  minStock: number
}

export interface SaleItem {
  productId: string
  name: string
  price: number
  qty: number
}

export interface Sale {
  id: string
  date: string
  items: SaleItem[]
  total: number
  profit: number
  payment: 'especes' | 'carte' | 'credit' | 'mixte'
  clientId?: string
  clientName?: string
}

export interface Client {
  id: string
  name: string
  phone: string
  email: string
  address: string
  city: string
  cin: string
  clientType: 'Particulier' | 'Professionnel'
  creditLimit: number
  notes: string
  creditDueDate?: string
  discountBalance: number
  credit: number
  totalSpent: number
  points: number
}

export interface ClientPayment {
  id: string
  date: string
  clientId: string
  clientName: string
  amount: number
  method: 'especes' | 'carte' | 'virement' | 'cheque'
  note: string
}

export interface LoyaltyMovement {
  id: string
  date: string
  clientId: string
  clientName: string
  type: 'gain' | 'utilisation'
  points: number
  note: string
}

export interface SupplierPayment {
  id: string
  date: string
  supplierId: string
  supplierName: string
  amount: number
  method: 'especes' | 'carte' | 'virement' | 'cheque'
  note: string
}

export interface Supplier {
  id: string
  name: string
  phone: string
  address: string
  balance: number
  totalPurchased: number
}

export interface StockMovement {
  id: string
  date: string
  productId: string
  productName: string
  type: 'entree' | 'sortie' | 'ajustement' | 'vente' | 'reception' | 'retour' | 'inventaire'
  qty: number
  note: string
}

export interface PurchaseItem {
  productId: string
  name: string
  cost: number
  qty: number
}

export interface Purchase {
  id: string
  ref: string
  date: string
  supplierId: string
  supplierName: string
  items: PurchaseItem[]
  total: number
  paid: number
  status: 'en_attente' | 'recue' | 'retournee'
}

export interface Quote {
  id: string
  ref: string
  date: string
  clientName: string
  items: SaleItem[]
  total: number
  status: 'en_attente' | 'accepte' | 'refuse' | 'converti'
}

export interface SaleReturn {
  id: string
  date: string
  saleId: string
  clientName: string
  items: SaleItem[]
  total: number
  method: 'especes' | 'avoir'
}

export interface CashEntry {
  id: string
  date: string
  type: 'depense' | 'recette'
  label: string
  amount: number
}

export interface RegisterSession {
  id: string
  openedAt: string
  openingAmount: number
  closedAt?: string
  closingAmount?: number
  expectedAmount?: number
}

export interface AppUser {
  id: string
  name: string
  phone: string
  role: 'Administrateur' | 'Caissier' | 'Vendeur'
  active: boolean
}

export interface ActivityLog {
  id: string
  date: string
  user: string
  action: string
}

export interface Attribute {
  id: string
  name: string
}

export interface Settings {
  storeName: string
  phone: string
  address: string
  tva: number
  currency: string
  ticketMessage: string
  pointsPerAmount: number
  pointValueDH: number
  opexBudget: number
}

export interface Expense {
  id: string
  date: string
  category: string
  label: string
  amount: number
  status: 'payee' | 'a_payer' | 'retard'
  dueDate?: string
  note: string
}

export const EXPENSE_CATEGORIES = ['Loyer', 'Électricité', 'Internet', 'Fournitures', 'Assurance', 'Bureau', 'Transport', 'Autre']

export interface HeldSale {
  id: string
  date: string
  items: SaleItem[]
  clientId: string
  label: string
}

// ------------------------------------------------------------------
// Storage keys / helpers
// ------------------------------------------------------------------

const K = {
  products: 'dp_products',
  sales: 'dp_sales',
  clients: 'dp_clients',
  settings: 'dp_settings',
  movements: 'dp_movements',
  suppliers: 'dp_suppliers',
  purchases: 'dp_purchases',
  quotes: 'dp_quotes',
  returns: 'dp_returns',
  cash: 'dp_cash',
  sessions: 'dp_sessions',
  users: 'dp_users',
  activity: 'dp_activity',
  catAttr: 'dp_attr_categories',
  brandAttr: 'dp_attr_marques',
  unitAttr: 'dp_attr_unites',
  held: 'dp_held_sales',
  backups: 'dp_backups',
  clientPayments: 'dp_client_payments',
  loyalty: 'dp_loyalty_movements',
  supplierPayments: 'dp_supplier_payments',
  expenses: 'dp_expenses',
}

export const DEFAULT_SETTINGS: Settings = {
  storeName: 'Droguerie Pro',
  phone: '06 61 00 00 00',
  address: 'Casablanca, Maroc',
  tva: 20,
  currency: 'MAD (DH)',
  ticketMessage: 'Merci de votre visite !',
  pointsPerAmount: 50,
  pointValueDH: 1,
  opexBudget: 58000,
}

export const CLIENT_PAYMENT_META: Record<ClientPayment['method'], { label: string }> = {
  especes: { label: 'Espèces' },
  carte: { label: 'Carte bancaire' },
  virement: { label: 'Virement' },
  cheque: { label: 'Chèque' },
}

export const SUPPLIER_PAYMENT_META: Record<SupplierPayment['method'], { label: string }> = {
  especes: { label: 'Espèces' },
  carte: { label: 'Carte bancaire' },
  virement: { label: 'Virement' },
  cheque: { label: 'Chèque' },
}

export const PAYMENT_META: Record<Sale['payment'], { label: string; chip: string }> = {
  especes: { label: 'Espèces', chip: 'border-emerald-200 bg-emerald-50 text-emerald-700' },
  carte: { label: 'Carte', chip: 'border-sky-200 bg-sky-50 text-sky-700' },
  credit: { label: 'Crédit', chip: 'border-amber-200 bg-amber-50 text-amber-700' },
  mixte: { label: 'Mixte', chip: 'border-violet-200 bg-violet-50 text-violet-700' },
}

export const MOVEMENT_META: Record<StockMovement['type'], { label: string; chip: string }> = {
  entree: { label: 'Entrée', chip: 'border-emerald-200 bg-emerald-50 text-emerald-700' },
  sortie: { label: 'Sortie', chip: 'border-rose-200 bg-rose-50 text-rose-700' },
  ajustement: { label: 'Ajustement', chip: 'border-sky-200 bg-sky-50 text-sky-700' },
  vente: { label: 'Vente', chip: 'border-amber-200 bg-amber-50 text-amber-700' },
  reception: { label: 'Réception', chip: 'border-emerald-200 bg-emerald-50 text-emerald-700' },
  retour: { label: 'Retour', chip: 'border-violet-200 bg-violet-50 text-violet-700' },
  inventaire: { label: 'Inventaire', chip: 'border-gray-200 bg-gray-50 text-gray-700' },
}

export const fmtDH = (n: number) => `${n.toFixed(2).replace('.', ',')} DH`

export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7)

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key)
    return raw ? (JSON.parse(raw) as T) : fallback
  } catch {
    return fallback
  }
}

function save(key: string, value: unknown) {
  localStorage.setItem(key, JSON.stringify(value))
}

// ------------------------------------------------------------------
// Seed data
// ------------------------------------------------------------------

const seedProducts: Omit<Product, 'id'>[] = [
  { name: 'Peinture blanche 5L', barcode: '6111234500017', category: 'Peinture', brand: 'Astral', unit: 'Pièce', price: 185, cost: 140, stock: 24, minStock: 5 },
  { name: 'Ciment colle 25kg', barcode: '6111234500024', category: 'Quincaillerie', brand: 'Générique', unit: 'Sac', price: 65, cost: 48, stock: 40, minStock: 10 },
  { name: 'Ampoule LED 12W', barcode: '6111234500031', category: 'Électricité', brand: 'Schneider', unit: 'Pièce', price: 25, cost: 15, stock: 80, minStock: 20 },
  { name: 'Câble électrique 2.5mm (10m)', barcode: '6111234500048', category: 'Électricité', brand: 'Générique', unit: 'Mètre', price: 95, cost: 70, stock: 35, minStock: 8 },
  { name: 'Robinet mélangeur', barcode: '6111234500055', category: 'Plomberie', brand: 'Générique', unit: 'Pièce', price: 220, cost: 160, stock: 12, minStock: 3 },
  { name: 'Tuyau PVC 32mm (2m)', barcode: '6111234500062', category: 'Plomberie', brand: 'Générique', unit: 'Pièce', price: 45, cost: 30, stock: 50, minStock: 10 },
  { name: 'Marteau 500g', barcode: '6111234500079', category: 'Outillage', brand: 'Stanley', unit: 'Pièce', price: 75, cost: 50, stock: 18, minStock: 5 },
  { name: 'Tournevis set 6 pièces', barcode: '6111234500086', category: 'Outillage', brand: 'Facom', unit: 'Boîte', price: 89, cost: 60, stock: 22, minStock: 5 },
  { name: 'Vis assorties 1kg', barcode: '6111234500093', category: 'Quincaillerie', brand: 'Générique', unit: 'Kg', price: 40, cost: 25, stock: 60, minStock: 15 },
  { name: 'Clous 1kg', barcode: '6111234500109', category: 'Quincaillerie', brand: 'Générique', unit: 'Kg', price: 28, cost: 18, stock: 55, minStock: 15 },
  { name: 'Colle forte 50ml', barcode: '6111234500116', category: 'Quincaillerie', brand: 'Générique', unit: 'Pièce', price: 18, cost: 10, stock: 90, minStock: 20 },
  { name: 'Javel 5L', barcode: '6118000040972', category: 'Droguerie', brand: 'Générique', unit: 'Litre', price: 22, cost: 14, stock: 70, minStock: 20 },
  { name: 'Diluant 1L', barcode: '6111234500130', category: 'Peinture', brand: 'Astral', unit: 'Litre', price: 35, cost: 24, stock: 30, minStock: 8 },
  { name: 'Pinceau 50mm', barcode: '6111234500147', category: 'Peinture', brand: 'Générique', unit: 'Pièce', price: 15, cost: 8, stock: 45, minStock: 10 },
  { name: 'Gants de travail', barcode: '6111234500154', category: 'Sécurité', brand: 'Générique', unit: 'Pièce', price: 20, cost: 12, stock: 65, minStock: 15 },
  { name: 'Serrure 3 clés', barcode: '6111234500161', category: 'Quincaillerie', brand: 'Générique', unit: 'Pièce', price: 130, cost: 95, stock: 10, minStock: 3 },
]

const SEED_CATEGORIES = ['Droguerie', 'Quincaillerie', 'Électricité', 'Plomberie', 'Peinture', 'Jardin', 'Outillage', 'Sanitaire', 'Cuisine', 'Entretien', 'Automobile', 'Sécurité']
const SEED_BRANDS = ['Astral', 'Facom', 'Stanley', 'Bosch', 'Schneider', 'Générique']
const SEED_UNITS = ['Pièce', 'Carton', 'Sac', 'Litre', 'Kg', 'Mètre', 'Boîte']

function seedSales(products: Product[]): Sale[] {
  const sales: Sale[] = []
  const now = new Date()
  for (let d = 13; d >= 0; d--) {
    const count = 2 + Math.floor(Math.random() * 4)
    for (let s = 0; s < count; s++) {
      const items: SaleItem[] = []
      const nItems = 1 + Math.floor(Math.random() * 3)
      let total = 0
      let profit = 0
      for (let it = 0; it < nItems; it++) {
        const p = products[Math.floor(Math.random() * products.length)]
        const qty = 1 + Math.floor(Math.random() * 3)
        items.push({ productId: p.id, name: p.name, price: p.price, qty })
        total += p.price * qty
        profit += (p.price - p.cost) * qty
      }
      const date = new Date(now)
      date.setDate(now.getDate() - d)
      date.setHours(9 + Math.floor(Math.random() * 10), Math.floor(Math.random() * 60), 0, 0)
      const r = Math.random()
      sales.push({
        id: uid() + s,
        date: date.toISOString(),
        items,
        total,
        profit,
        payment: r < 0.7 ? 'especes' : r < 0.9 ? 'carte' : 'credit',
      })
    }
  }
  return sales.sort((a, b) => a.date.localeCompare(b.date))
}

function iso(daysAgo: number, h = 10, m = 0) {
  const d = new Date()
  d.setDate(d.getDate() - daysAgo)
  d.setHours(h, m, 0, 0)
  return d.toISOString()
}

export function ensureSeeded() {
  if (typeof window === 'undefined') return

  if (!localStorage.getItem(K.products)) {
    save(K.products, seedProducts.map((p, i) => ({ ...p, id: `p${i + 1}` })))
  }
  const products = load<Product[]>(K.products, [])

  if (!localStorage.getItem(K.sales)) save(K.sales, seedSales(products))
  if (!localStorage.getItem(K.clients)) {
    save(K.clients, [
      {
        id: 'c1', name: 'Ahmed Bennani', phone: '0661 23 45 67', email: 'ahmed.bennani@gmail.com',
        address: '12 Rue des Orangers', city: 'Casablanca', cin: 'BK123456', clientType: 'Particulier',
        creditLimit: 1000, notes: '', creditDueDate: iso(-5), discountBalance: 0,
        credit: 350, totalSpent: 4820, points: 96,
      },
      {
        id: 'c2', name: 'Fatima Zahra', phone: '0662 88 99 00', email: 'fatima.zahra@gmail.com',
        address: '5 Avenue Hassan II', city: 'Casablanca', cin: '', clientType: 'Particulier',
        creditLimit: 500, notes: '', discountBalance: 0,
        credit: 0, totalSpent: 2140, points: 42,
      },
      {
        id: 'c3', name: 'Mohammed Alami', phone: '0663 44 55 66', email: 'contact@alami-btp.ma',
        address: '48 Zone Industrielle Sidi Bernoussi', city: 'Casablanca', cin: '', clientType: 'Professionnel',
        creditLimit: 5000, notes: 'Client BTP — commandes groupées fréquentes', creditDueDate: iso(-2), discountBalance: 0,
        credit: 120, totalSpent: 6375, points: 127,
      },
      {
        id: 'c4', name: 'Karim El Fassi', phone: '0664 11 22 33', email: 'karim.elfassi@gmail.com',
        address: '3 Rue Ibn Sina', city: 'Rabat', cin: 'RB98765', clientType: 'Particulier',
        creditLimit: 300, notes: '', discountBalance: 0,
        credit: 0, totalSpent: 980, points: 19,
      },
    ] satisfies Client[])
  }
  if (!localStorage.getItem(K.clientPayments)) {
    save(K.clientPayments, [
      { id: 'cp1', date: iso(6, 14, 0), clientId: 'c1', clientName: 'Ahmed Bennani', amount: 200, method: 'especes', note: 'Règlement partiel' },
      { id: 'cp2', date: iso(3, 10, 30), clientId: 'c3', clientName: 'Mohammed Alami', amount: 500, method: 'virement', note: 'Règlement partiel' },
    ] satisfies ClientPayment[])
  }
  if (!localStorage.getItem(K.loyalty)) {
    save(K.loyalty, [
      { id: 'lm1', date: iso(6), clientId: 'c1', clientName: 'Ahmed Bennani', type: 'gain', points: 24, note: 'Achat en magasin' },
      { id: 'lm2', date: iso(3), clientId: 'c3', clientName: 'Mohammed Alami', type: 'gain', points: 40, note: 'Achat en magasin' },
    ] satisfies LoyaltyMovement[])
  }
  if (!localStorage.getItem(K.settings)) save(K.settings, DEFAULT_SETTINGS)
  if (!localStorage.getItem(K.catAttr)) save(K.catAttr, SEED_CATEGORIES.map((name, i) => ({ id: `cat${i}`, name })))
  if (!localStorage.getItem(K.brandAttr)) save(K.brandAttr, SEED_BRANDS.map((name, i) => ({ id: `br${i}`, name })))
  if (!localStorage.getItem(K.unitAttr)) save(K.unitAttr, SEED_UNITS.map((name, i) => ({ id: `un${i}`, name })))

  if (!localStorage.getItem(K.suppliers)) {
    save(K.suppliers, [
      { id: 's1', name: 'Comptoir Marocain de Quincaillerie', phone: '0522 30 40 50', address: 'Derb Omar, Casablanca', balance: 2400, totalPurchased: 18600 },
      { id: 's2', name: 'Droguerie Centrale SARL', phone: '0522 61 72 83', address: 'Aïn Sebaâ, Casablanca', balance: 0, totalPurchased: 9400 },
      { id: 's3', name: 'ElectroPlus Distribution', phone: '0537 20 21 22', address: 'Rabat', balance: 860, totalPurchased: 5200 },
    ])
  }
  if (!localStorage.getItem(K.supplierPayments)) {
    save(K.supplierPayments, [
      { id: 'sp1', date: iso(4, 11, 0), supplierId: 's1', supplierName: 'Comptoir Marocain de Quincaillerie', amount: 1600, method: 'virement', note: 'Règlement partiel BC-0001' },
      { id: 'sp2', date: iso(2, 9, 0), supplierId: 's3', supplierName: 'ElectroPlus Distribution', amount: 800, method: 'especes', note: 'Règlement partiel' },
    ] satisfies SupplierPayment[])
  }
  if (!localStorage.getItem(K.expenses)) {
    save(K.expenses, [
      { id: 'ex1', date: iso(9, 9, 0), category: 'Loyer', label: 'Loyer entrepôt principal', amount: 15000, status: 'payee', note: '' },
      { id: 'ex2', date: iso(11, 10, 0), category: 'Électricité', label: 'Facture Lydec — Février', amount: 2450, status: 'a_payer', dueDate: iso(-2, 12, 0), note: '' },
      { id: 'ex3', date: iso(16, 14, 0), category: 'Assurance', label: 'RC Professionnelle AXA', amount: 8200, status: 'retard', dueDate: iso(3, 12, 0), note: '' },
      { id: 'ex4', date: iso(20, 9, 30), category: 'Bureau', label: 'Consommables informatiques', amount: 1200, status: 'payee', note: '' },
      { id: 'ex5', date: iso(6, 11, 0), category: 'Internet', label: 'Abonnement fibre — Mars', amount: 899, status: 'payee', note: '' },
      { id: 'ex6', date: iso(14, 8, 0), category: 'Fournitures', label: 'Sacs et emballages', amount: 1650, status: 'payee', note: '' },
      { id: 'ex7', date: iso(28, 9, 0), category: 'Transport', label: 'Location camionnette livraison', amount: 950, status: 'payee', note: '' },
      { id: 'ex8', date: iso(35, 10, 0), category: 'Loyer', label: 'Loyer entrepôt — mois précédent', amount: 15000, status: 'payee', note: '' },
      { id: 'ex9', date: iso(40, 9, 0), category: 'Électricité', label: 'Facture Lydec — Janvier', amount: 2100, status: 'payee', note: '' },
    ] satisfies Expense[])
  }

  if (!localStorage.getItem(K.purchases)) {
    save(K.purchases, [
      {
        id: 'po1', ref: 'BC-0001', date: iso(6, 9, 30), supplierId: 's1', supplierName: 'Comptoir Marocain de Quincaillerie',
        items: [
          { productId: 'p9', name: 'Vis assorties 1kg', cost: 25, qty: 40 },
          { productId: 'p10', name: 'Clous 1kg', cost: 18, qty: 30 },
        ],
        total: 40 * 25 + 30 * 18, paid: 0, status: 'recue',
      },
      {
        id: 'po2', ref: 'BC-0002', date: iso(1, 11, 0), supplierId: 's3', supplierName: 'ElectroPlus Distribution',
        items: [
          { productId: 'p3', name: 'Ampoule LED 12W', cost: 15, qty: 100 },
          { productId: 'p4', name: 'Câble électrique 2.5mm (10m)', cost: 70, qty: 20 },
        ],
        total: 100 * 15 + 20 * 70, paid: 0, status: 'en_attente',
      },
    ])
  }

  if (!localStorage.getItem(K.movements)) {
    save(K.movements, [
      { id: 'm1', date: iso(6, 9, 45), productId: 'p9', productName: 'Vis assorties 1kg', type: 'reception', qty: 40, note: 'BC-0001' },
      { id: 'm2', date: iso(6, 9, 45), productId: 'p10', productName: 'Clous 1kg', type: 'reception', qty: 30, note: 'BC-0001' },
      { id: 'm3', date: iso(4, 15, 10), productId: 'p1', productName: 'Peinture blanche 5L', type: 'sortie', qty: -1, note: 'Pot endommagé' },
      { id: 'm4', date: iso(2, 10, 5), productId: 'p12', productName: 'Javel 5L', type: 'entree', qty: 24, note: 'Livraison directe' },
    ] satisfies StockMovement[])
  }

  if (!localStorage.getItem(K.quotes)) {
    save(K.quotes, [
      {
        id: 'q1', ref: 'DEV-0001', date: iso(3, 12, 0), clientName: 'Société Atlas Bâtiment',
        items: [
          { productId: 'p1', name: 'Peinture blanche 5L', price: 185, qty: 10 },
          { productId: 'p14', name: 'Pinceau 50mm', price: 15, qty: 12 },
        ],
        total: 185 * 10 + 15 * 12, status: 'en_attente',
      },
    ] satisfies Quote[])
  }

  if (!localStorage.getItem(K.returns)) save(K.returns, [])
  if (!localStorage.getItem(K.cash)) {
    save(K.cash, [
      { id: 'ce1', date: iso(0, 9, 15), type: 'depense', label: 'Transport livraison', amount: 80 },
    ] satisfies CashEntry[])
  }
  if (!localStorage.getItem(K.sessions)) {
    save(K.sessions, [
      { id: 'rs1', openedAt: iso(0, 8, 30), openingAmount: 500 },
    ] satisfies RegisterSession[])
  }
  if (!localStorage.getItem(K.users)) {
    save(K.users, [
      { id: 'u1', name: 'Yassir A.', phone: '0661 00 00 00', role: 'Administrateur', active: true },
      { id: 'u2', name: 'Hamid Tazi', phone: '0662 11 22 33', role: 'Caissier', active: true },
      { id: 'u3', name: 'Sara Mansouri', phone: '0663 44 55 66', role: 'Vendeur', active: false },
    ] satisfies AppUser[])
  }
  if (!localStorage.getItem(K.activity)) {
    save(K.activity, [
      { id: 'a1', date: iso(0, 8, 30), user: 'Yassir A.', action: 'Ouverture de caisse (500,00 DH)' },
    ] satisfies ActivityLog[])
  }
}

// Normalizers for data created by older versions of the app
const normProduct = (p: Product): Product => ({
  ...p,
  brand: p.brand ?? '',
  unit: p.unit ?? 'Pièce',
})
type LegacyClient = Partial<Client> & Pick<Client, 'id' | 'name' | 'phone' | 'credit' | 'totalSpent' | 'points'>
const normClient = (c: LegacyClient): Client => ({
  email: '',
  address: '',
  city: '',
  cin: '',
  clientType: 'Particulier',
  creditLimit: 0,
  notes: '',
  discountBalance: 0,
  ...c,
  points: c.points ?? 0,
})

export function loadProducts(): Product[] {
  ensureSeeded()
  return load<Product[]>(K.products, []).map(normProduct)
}

export function resetDemoData() {
  Object.values(K).forEach((k) => localStorage.removeItem(k))
  ensureSeeded()
}

// ------------------------------------------------------------------
// Held sales (POS suspend/resume)
// ------------------------------------------------------------------

export function loadHeldSales(): HeldSale[] {
  return load<HeldSale[]>(K.held, [])
}

export function saveHeldSales(held: HeldSale[]) {
  save(K.held, held)
}

// ------------------------------------------------------------------
// CSV / backup helpers
// ------------------------------------------------------------------

function downloadFile(name: string, content: string, type: string) {
  const blob = new Blob(['﻿' + content], { type })
  const a = document.createElement('a')
  a.href = URL.createObjectURL(blob)
  a.download = name
  a.click()
  URL.revokeObjectURL(a.href)
}

export function exportSalesCSV(sales: Sale[]) {
  const rows = [['N°', 'Date', 'Articles', 'Paiement', 'Total DH', 'Profit DH']]
  sales.forEach((s) =>
    rows.push([
      s.id,
      new Date(s.date).toLocaleString('fr-FR'),
      String(s.items.reduce((a, i) => a + i.qty, 0)),
      PAYMENT_META[s.payment].label,
      s.total.toFixed(2),
      s.profit.toFixed(2),
    ])
  )
  downloadFile('ventes-droguerie.csv', rows.map((r) => r.join(';')).join('\n'), 'text/csv;charset=utf-8')
}

export function exportProductsCSV(products: Product[]) {
  const rows = [['Nom', 'Code-barres', 'Catégorie', 'Marque', 'Unité', 'Prix achat', 'Prix vente', 'Stock', 'Stock min']]
  products.forEach((p) =>
    rows.push([p.name, p.barcode, p.category, p.brand, p.unit, p.cost.toFixed(2), p.price.toFixed(2), String(p.stock), String(p.minStock)])
  )
  downloadFile('produits-droguerie.csv', rows.map((r) => r.join(';')).join('\n'), 'text/csv;charset=utf-8')
}

/** Parse a products CSV (semicolon or comma separated, FR headers accepted). Returns parsed rows. */
export function parseProductsCSV(text: string): Omit<Product, 'id'>[] {
  const lines = text.replace(/^﻿/, '').split(/\r?\n/).filter((l) => l.trim())
  if (lines.length < 2) return []
  const sep = lines[0].includes(';') ? ';' : ','
  const header = lines[0].split(sep).map((h) => h.trim().toLowerCase())
  const idx = (...names: string[]) => header.findIndex((h) => names.some((n) => h.includes(n)))
  const iName = idx('nom', 'name', 'produit')
  const iBarcode = idx('code', 'barcode')
  const iCat = idx('cat')
  const iBrand = idx('marque', 'brand')
  const iUnit = idx('unit')
  const iCost = idx('achat', 'cost', 'cout', 'coût')
  const iPrice = idx('vente', 'prix vente', 'price')
  const iStock = header.findIndex((h) => h === 'stock' || h.includes('quantit'))
  const iMin = idx('min')
  if (iName < 0) return []
  const num = (v?: string) => parseFloat((v ?? '').replace(',', '.')) || 0
  const out: Omit<Product, 'id'>[] = []
  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(sep).map((c) => c.trim())
    const name = cols[iName]
    if (!name) continue
    out.push({
      name,
      barcode: iBarcode >= 0 ? cols[iBarcode] ?? '' : '',
      category: (iCat >= 0 && cols[iCat]) || 'Divers',
      brand: iBrand >= 0 ? cols[iBrand] ?? '' : '',
      unit: (iUnit >= 0 && cols[iUnit]) || 'Pièce',
      cost: iCost >= 0 ? num(cols[iCost]) : 0,
      price: iPrice >= 0 ? num(cols[iPrice]) : 0,
      stock: iStock >= 0 ? Math.round(num(cols[iStock])) : 0,
      minStock: iMin >= 0 ? Math.round(num(cols[iMin])) : 5,
    })
  }
  return out
}

export interface Backup {
  id: string
  date: string
  label: string
  data: Record<string, unknown>
}

export function listBackups(): Backup[] {
  return load<Backup[]>(K.backups, [])
}

export function createBackup(label: string): Backup {
  const data: Record<string, unknown> = {}
  Object.entries(K).forEach(([, key]) => {
    if (key === K.backups) return
    const raw = localStorage.getItem(key)
    if (raw) data[key] = JSON.parse(raw)
  })
  const backup: Backup = { id: uid(), date: new Date().toISOString(), label, data }
  const all = [backup, ...listBackups()].slice(0, 5)
  save(K.backups, all)
  return backup
}

export function restoreBackup(backup: Backup) {
  Object.entries(backup.data).forEach(([key, value]) => save(key, value))
}

export function deleteBackup(id: string) {
  save(K.backups, listBackups().filter((b) => b.id !== id))
}

export function exportAllJSON() {
  const data: Record<string, unknown> = {}
  Object.values(K).forEach((key) => {
    const raw = localStorage.getItem(key)
    if (raw) data[key] = JSON.parse(raw)
  })
  downloadFile('droguerie-sauvegarde.json', JSON.stringify(data, null, 2), 'application/json')
}

export function importAllJSON(text: string): boolean {
  try {
    const data = JSON.parse(text)
    if (!data || typeof data !== 'object' || !data[K.products]) return false
    Object.entries(data).forEach(([key, value]) => {
      if (Object.values(K).includes(key)) save(key, value)
    })
    return true
  } catch {
    return false
  }
}

// ------------------------------------------------------------------
// Main hook
// ------------------------------------------------------------------

export function useDroguerie() {
  const [products, setProducts] = useState<Product[]>([])
  const [sales, setSales] = useState<Sale[]>([])
  const [clients, setClients] = useState<Client[]>([])
  const [suppliers, setSuppliers] = useState<Supplier[]>([])
  const [movements, setMovements] = useState<StockMovement[]>([])
  const [purchases, setPurchases] = useState<Purchase[]>([])
  const [quotes, setQuotes] = useState<Quote[]>([])
  const [returns, setReturns] = useState<SaleReturn[]>([])
  const [cash, setCash] = useState<CashEntry[]>([])
  const [sessions, setSessions] = useState<RegisterSession[]>([])
  const [users, setUsers] = useState<AppUser[]>([])
  const [activity, setActivity] = useState<ActivityLog[]>([])
  const [categories, setCategories] = useState<Attribute[]>([])
  const [brands, setBrands] = useState<Attribute[]>([])
  const [units, setUnits] = useState<Attribute[]>([])
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS)
  const [clientPayments, setClientPayments] = useState<ClientPayment[]>([])
  const [loyaltyMovements, setLoyaltyMovements] = useState<LoyaltyMovement[]>([])
  const [supplierPayments, setSupplierPayments] = useState<SupplierPayment[]>([])
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [ready, setReady] = useState(false)

  useEffect(() => {
    ensureSeeded()
    setProducts(load<Product[]>(K.products, []).map(normProduct))
    setSales(load(K.sales, []))
    setClients(load<Client[]>(K.clients, []).map(normClient))
    setSuppliers(load(K.suppliers, []))
    setMovements(load(K.movements, []))
    setPurchases(load(K.purchases, []))
    setQuotes(load(K.quotes, []))
    setReturns(load(K.returns, []))
    setCash(load(K.cash, []))
    setSessions(load(K.sessions, []))
    setUsers(load(K.users, []))
    setActivity(load(K.activity, []))
    setCategories(load(K.catAttr, []))
    setBrands(load(K.brandAttr, []))
    setUnits(load(K.unitAttr, []))
    setClientPayments(load(K.clientPayments, []))
    setLoyaltyMovements(load(K.loyalty, []))
    setSupplierPayments(load(K.supplierPayments, []))
    setExpenses(load(K.expenses, []))
    setSettings({ ...DEFAULT_SETTINGS, ...load<Partial<Settings>>(K.settings, {}) })
    setReady(true)
  }, [])

  const makePersist = <T,>(key: string, setter: (v: T) => void) =>
    (next: T) => {
      setter(next)
      save(key, next)
    }

  /* eslint-disable react-hooks/exhaustive-deps */
  const persistProducts = useCallback(makePersist<Product[]>(K.products, setProducts), [])
  const persistSales = useCallback(makePersist<Sale[]>(K.sales, setSales), [])
  const persistClients = useCallback(makePersist<Client[]>(K.clients, setClients), [])
  const persistSuppliers = useCallback(makePersist<Supplier[]>(K.suppliers, setSuppliers), [])
  const persistMovements = useCallback(makePersist<StockMovement[]>(K.movements, setMovements), [])
  const persistPurchases = useCallback(makePersist<Purchase[]>(K.purchases, setPurchases), [])
  const persistQuotes = useCallback(makePersist<Quote[]>(K.quotes, setQuotes), [])
  const persistReturns = useCallback(makePersist<SaleReturn[]>(K.returns, setReturns), [])
  const persistCash = useCallback(makePersist<CashEntry[]>(K.cash, setCash), [])
  const persistSessions = useCallback(makePersist<RegisterSession[]>(K.sessions, setSessions), [])
  const persistUsers = useCallback(makePersist<AppUser[]>(K.users, setUsers), [])
  const persistActivity = useCallback(makePersist<ActivityLog[]>(K.activity, setActivity), [])
  const persistCategories = useCallback(makePersist<Attribute[]>(K.catAttr, setCategories), [])
  const persistBrands = useCallback(makePersist<Attribute[]>(K.brandAttr, setBrands), [])
  const persistUnits = useCallback(makePersist<Attribute[]>(K.unitAttr, setUnits), [])
  const persistClientPayments = useCallback(makePersist<ClientPayment[]>(K.clientPayments, setClientPayments), [])
  const persistLoyalty = useCallback(makePersist<LoyaltyMovement[]>(K.loyalty, setLoyaltyMovements), [])
  const persistSupplierPayments = useCallback(makePersist<SupplierPayment[]>(K.supplierPayments, setSupplierPayments), [])
  const persistExpenses = useCallback(makePersist<Expense[]>(K.expenses, setExpenses), [])
  /* eslint-enable react-hooks/exhaustive-deps */

  const saveSettings = useCallback((next: Settings) => {
    setSettings(next)
    save(K.settings, next)
  }, [])

  const logActivity = (action: string, base?: ActivityLog[]) => {
    const entry: ActivityLog = { id: uid(), date: new Date().toISOString(), user: 'Yassir A.', action }
    persistActivity([entry, ...(base ?? activity)].slice(0, 200))
  }

  // ---- Products ----
  const addProduct = (data: Omit<Product, 'id'>) => {
    persistProducts([{ ...data, id: uid() }, ...products])
    logActivity(`Produit ajouté : ${data.name}`)
  }

  const updateProduct = (id: string, data: Partial<Product>) => {
    persistProducts(products.map((p) => (p.id === id ? { ...p, ...data } : p)))
  }

  const deleteProduct = (id: string) => {
    const p = products.find((x) => x.id === id)
    persistProducts(products.filter((x) => x.id !== id))
    if (p) logActivity(`Produit supprimé : ${p.name}`)
  }

  const importProducts = (rows: Omit<Product, 'id'>[]) => {
    let added = 0
    let updated = 0
    let next = [...products]
    rows.forEach((r) => {
      const existing = r.barcode ? next.find((p) => p.barcode === r.barcode) : undefined
      if (existing) {
        next = next.map((p) => (p.id === existing.id ? { ...p, ...r } : p))
        updated++
      } else {
        next = [{ ...r, id: uid() }, ...next]
        added++
      }
    })
    persistProducts(next)
    logActivity(`Import produits : ${added} ajoutés, ${updated} mis à jour`)
    return { added, updated }
  }

  // ---- Stock movements ----
  const addMovement = (
    productId: string,
    type: StockMovement['type'],
    qty: number,
    note = '',
    baseProducts?: Product[],
    baseMovements?: StockMovement[]
  ) => {
    const list = baseProducts ?? products
    const p = list.find((x) => x.id === productId)
    if (!p) return
    const nextProducts = list.map((x) =>
      x.id === productId ? { ...x, stock: Math.max(0, x.stock + qty) } : x
    )
    persistProducts(nextProducts)
    const mv: StockMovement = {
      id: uid(),
      date: new Date().toISOString(),
      productId,
      productName: p.name,
      type,
      qty,
      note,
    }
    persistMovements([mv, ...(baseMovements ?? movements)])
    return nextProducts
  }

  const adjustStock = (id: string, delta: number, note = 'Ajustement manuel') => {
    addMovement(id, 'ajustement', delta, note)
  }

  const applyInventory = (counts: { productId: string; counted: number }[]) => {
    let curProducts = products
    let curMovements = movements
    counts.forEach(({ productId, counted }) => {
      const p = curProducts.find((x) => x.id === productId)
      if (!p || p.stock === counted) return
      const delta = counted - p.stock
      curProducts = curProducts.map((x) => (x.id === productId ? { ...x, stock: counted } : x))
      curMovements = [
        {
          id: uid(),
          date: new Date().toISOString(),
          productId,
          productName: p.name,
          type: 'inventaire' as const,
          qty: delta,
          note: `Inventaire physique (écart ${delta > 0 ? '+' : ''}${delta})`,
        },
        ...curMovements,
      ]
    })
    persistProducts(curProducts)
    persistMovements(curMovements)
    logActivity('Inventaire physique validé')
  }

  // ---- Sales ----
  const recordSale = (items: SaleItem[], payment: Sale['payment'], client?: Client | null): Sale => {
    const total = items.reduce((s, i) => s + i.price * i.qty, 0)
    const profit = items.reduce((s, i) => {
      const p = products.find((x) => x.id === i.productId)
      return s + (i.price - (p?.cost ?? 0)) * i.qty
    }, 0)
    const sale: Sale = {
      id: uid(),
      date: new Date().toISOString(),
      items,
      total,
      profit,
      payment,
      clientId: client?.id,
      clientName: client?.name,
    }
    persistSales([...sales, sale])
    persistProducts(
      products.map((p) => {
        const qty = items.filter((i) => i.productId === p.id).reduce((s, i) => s + i.qty, 0)
        return qty ? { ...p, stock: Math.max(0, p.stock - qty) } : p
      })
    )
    persistMovements([
      ...items.map((i) => ({
        id: uid() + i.productId,
        date: sale.date,
        productId: i.productId,
        productName: i.name,
        type: 'vente' as const,
        qty: -i.qty,
        note: `Vente ${sale.id.slice(-5)}`,
      })),
      ...movements,
    ])
    if (client) {
      const gained = Math.floor(total / settings.pointsPerAmount)
      persistClients(
        clients.map((c) =>
          c.id === client.id
            ? {
                ...c,
                totalSpent: c.totalSpent + total,
                credit: payment === 'credit' ? c.credit + total : c.credit,
                points: c.points + gained,
              }
            : c
        )
      )
      if (gained > 0) {
        persistLoyalty([
          {
            id: uid(),
            date: sale.date,
            clientId: client.id,
            clientName: client.name,
            type: 'gain',
            points: gained,
            note: `Vente ${sale.id.slice(-5)}`,
          },
          ...loyaltyMovements,
        ])
      }
    }
    logActivity(`Vente encaissée : ${fmtDH(total)} (${PAYMENT_META[payment].label})`)
    return sale
  }

  const recordReturn = (sale: Sale, items: SaleItem[], method: SaleReturn['method']) => {
    const total = items.reduce((s, i) => s + i.price * i.qty, 0)
    const ret: SaleReturn = {
      id: uid(),
      date: new Date().toISOString(),
      saleId: sale.id,
      clientName: sale.clientName ?? '',
      items,
      total,
      method,
    }
    persistReturns([ret, ...returns])
    persistProducts(
      products.map((p) => {
        const qty = items.filter((i) => i.productId === p.id).reduce((s, i) => s + i.qty, 0)
        return qty ? { ...p, stock: p.stock + qty } : p
      })
    )
    persistMovements([
      ...items.map((i) => ({
        id: uid() + i.productId,
        date: ret.date,
        productId: i.productId,
        productName: i.name,
        type: 'retour' as const,
        qty: i.qty,
        note: `Retour vente ${sale.id.slice(-5)}`,
      })),
      ...movements,
    ])
    if (method === 'especes') {
      persistCash([
        { id: uid(), date: ret.date, type: 'depense', label: `Remboursement retour ${ret.id.slice(-5)}`, amount: total },
        ...cash,
      ])
    } else if (sale.clientId) {
      persistClients(
        clients.map((c) => (c.id === sale.clientId ? { ...c, credit: Math.max(0, c.credit - total) } : c))
      )
    }
    logActivity(`Retour client : ${fmtDH(total)}`)
    return ret
  }

  // ---- Clients ----
  const addClient = (
    data: Partial<Omit<Client, 'id' | 'credit' | 'totalSpent' | 'points' | 'discountBalance'>> & {
      name: string
      phone: string
    }
  ) => {
    const client: Client = {
      id: uid(),
      name: data.name,
      phone: data.phone,
      email: data.email ?? '',
      address: data.address ?? '',
      city: data.city ?? '',
      cin: data.cin ?? '',
      clientType: data.clientType ?? 'Particulier',
      creditLimit: data.creditLimit ?? 0,
      notes: data.notes ?? '',
      creditDueDate: data.creditDueDate,
      discountBalance: 0,
      credit: 0,
      totalSpent: 0,
      points: 0,
    }
    persistClients([client, ...clients])
    return client
  }

  const updateClient = (id: string, data: Partial<Client>) => {
    persistClients(clients.map((c) => (c.id === id ? { ...c, ...data } : c)))
  }

  const deleteClient = (id: string) => {
    persistClients(clients.filter((c) => c.id !== id))
  }

  const settleCredit = (id: string, amount: number, method: ClientPayment['method'] = 'especes') => {
    const c = clients.find((x) => x.id === id)
    persistClients(
      clients.map((x) => (x.id === id ? { ...x, credit: Math.max(0, x.credit - amount) } : x))
    )
    persistCash([
      { id: uid(), date: new Date().toISOString(), type: 'recette', label: `Règlement crédit — ${c?.name ?? ''}`, amount },
      ...cash,
    ])
    persistClientPayments([
      {
        id: uid(),
        date: new Date().toISOString(),
        clientId: id,
        clientName: c?.name ?? '',
        amount,
        method,
        note: 'Règlement crédit',
      },
      ...clientPayments,
    ])
    logActivity(`Règlement crédit ${c?.name ?? ''} : ${fmtDH(amount)}`)
  }

  const redeemPoints = (id: string, points: number) => {
    const c = clients.find((x) => x.id === id)
    if (!c || points <= 0 || points > c.points) return
    const discount = points * settings.pointValueDH
    persistClients(
      clients.map((x) =>
        x.id === id ? { ...x, points: x.points - points, discountBalance: x.discountBalance + discount } : x
      )
    )
    persistLoyalty([
      {
        id: uid(),
        date: new Date().toISOString(),
        clientId: id,
        clientName: c.name,
        type: 'utilisation',
        points,
        note: `Converti en ${fmtDH(discount)} de remise`,
      },
      ...loyaltyMovements,
    ])
    logActivity(`${c.name} a converti ${points} points en ${fmtDH(discount)} de remise`)
  }

  // ---- Expenses ----
  const addExpense = (data: Omit<Expense, 'id'>) => {
    const expense: Expense = { ...data, id: uid() }
    persistExpenses([expense, ...expenses])
    if (expense.status === 'payee') {
      persistCash([
        { id: uid(), date: expense.date, type: 'depense', label: `${expense.category} — ${expense.label}`, amount: expense.amount },
        ...cash,
      ])
    }
    logActivity(`Dépense enregistrée : ${expense.label} (${fmtDH(expense.amount)})`)
    return expense
  }

  const markExpensePaid = (id: string) => {
    const e = expenses.find((x) => x.id === id)
    if (!e || e.status === 'payee') return
    persistExpenses(expenses.map((x) => (x.id === id ? { ...x, status: 'payee' } : x)))
    persistCash([
      { id: uid(), date: new Date().toISOString(), type: 'depense', label: `${e.category} — ${e.label}`, amount: e.amount },
      ...cash,
    ])
    logActivity(`Dépense payée : ${e.label} (${fmtDH(e.amount)})`)
  }

  const deleteExpense = (id: string) => {
    persistExpenses(expenses.filter((x) => x.id !== id))
  }

  // ---- Suppliers ----
  const addSupplier = (data: { name: string; phone: string; address: string }) => {
    persistSuppliers([{ ...data, id: uid(), balance: 0, totalPurchased: 0 }, ...suppliers])
  }

  const updateSupplier = (id: string, data: Partial<Supplier>) => {
    persistSuppliers(suppliers.map((s) => (s.id === id ? { ...s, ...data } : s)))
  }

  const deleteSupplier = (id: string) => {
    persistSuppliers(suppliers.filter((s) => s.id !== id))
  }

  const paySupplier = (id: string, amount: number, method: SupplierPayment['method'] = 'especes') => {
    const s = suppliers.find((x) => x.id === id)
    persistSuppliers(
      suppliers.map((x) => (x.id === id ? { ...x, balance: Math.max(0, x.balance - amount) } : x))
    )
    persistCash([
      { id: uid(), date: new Date().toISOString(), type: 'depense', label: `Paiement fournisseur — ${s?.name ?? ''}`, amount },
      ...cash,
    ])
    persistSupplierPayments([
      { id: uid(), date: new Date().toISOString(), supplierId: id, supplierName: s?.name ?? '', amount, method, note: 'Règlement solde' },
      ...supplierPayments,
    ])
    logActivity(`Paiement fournisseur ${s?.name ?? ''} : ${fmtDH(amount)}`)
  }

  // ---- Purchases ----
  const addPurchase = (supplierId: string, items: PurchaseItem[]) => {
    const supplier = suppliers.find((s) => s.id === supplierId)
    if (!supplier) return
    const total = items.reduce((a, i) => a + i.cost * i.qty, 0)
    const po: Purchase = {
      id: uid(),
      ref: `BC-${String(purchases.length + 1).padStart(4, '0')}`,
      date: new Date().toISOString(),
      supplierId,
      supplierName: supplier.name,
      items,
      total,
      paid: 0,
      status: 'en_attente',
    }
    persistPurchases([po, ...purchases])
    logActivity(`Commande fournisseur ${po.ref} créée (${fmtDH(total)})`)
    return po
  }

  const receivePurchase = (id: string) => {
    const po = purchases.find((p) => p.id === id)
    if (!po || po.status !== 'en_attente') return
    let curProducts = products
    let curMovements = movements
    po.items.forEach((i) => {
      const p = curProducts.find((x) => x.id === i.productId)
      if (!p) return
      curProducts = curProducts.map((x) => (x.id === i.productId ? { ...x, stock: x.stock + i.qty, cost: i.cost } : x))
      curMovements = [
        { id: uid() + i.productId, date: new Date().toISOString(), productId: i.productId, productName: i.name, type: 'reception' as const, qty: i.qty, note: po.ref },
        ...curMovements,
      ]
    })
    persistProducts(curProducts)
    persistMovements(curMovements)
    persistPurchases(purchases.map((p) => (p.id === id ? { ...p, status: 'recue' } : p)))
    persistSuppliers(
      suppliers.map((s) =>
        s.id === po.supplierId
          ? { ...s, balance: s.balance + po.total, totalPurchased: s.totalPurchased + po.total }
          : s
      )
    )
    logActivity(`Réception ${po.ref} — stock mis à jour`)
  }

  const payPurchase = (id: string, amount: number, method: SupplierPayment['method'] = 'especes') => {
    const po = purchases.find((p) => p.id === id)
    if (!po) return
    const pay = Math.min(amount, po.total - po.paid)
    persistPurchases(purchases.map((p) => (p.id === id ? { ...p, paid: p.paid + pay } : p)))
    persistSuppliers(
      suppliers.map((s) => (s.id === po.supplierId ? { ...s, balance: Math.max(0, s.balance - pay) } : s))
    )
    persistCash([
      { id: uid(), date: new Date().toISOString(), type: 'depense', label: `Facture ${po.ref} — ${po.supplierName}`, amount: pay },
      ...cash,
    ])
    persistSupplierPayments([
      { id: uid(), date: new Date().toISOString(), supplierId: po.supplierId, supplierName: po.supplierName, amount: pay, method, note: `Facture ${po.ref}` },
      ...supplierPayments,
    ])
    logActivity(`Paiement facture ${po.ref} : ${fmtDH(pay)}`)
  }

  const returnPurchase = (id: string) => {
    const po = purchases.find((p) => p.id === id)
    if (!po || po.status !== 'recue') return
    let curProducts = products
    let curMovements = movements
    po.items.forEach((i) => {
      curProducts = curProducts.map((x) =>
        x.id === i.productId ? { ...x, stock: Math.max(0, x.stock - i.qty) } : x
      )
      curMovements = [
        { id: uid() + i.productId, date: new Date().toISOString(), productId: i.productId, productName: i.name, type: 'retour' as const, qty: -i.qty, note: `Retour ${po.ref}` },
        ...curMovements,
      ]
    })
    persistProducts(curProducts)
    persistMovements(curMovements)
    persistPurchases(purchases.map((p) => (p.id === id ? { ...p, status: 'retournee' } : p)))
    persistSuppliers(
      suppliers.map((s) =>
        s.id === po.supplierId ? { ...s, balance: Math.max(0, s.balance - (po.total - po.paid)) } : s
      )
    )
    logActivity(`Retour fournisseur ${po.ref}`)
  }

  // ---- Quotes ----
  const addQuote = (clientName: string, items: SaleItem[]) => {
    const total = items.reduce((a, i) => a + i.price * i.qty, 0)
    const q: Quote = {
      id: uid(),
      ref: `DEV-${String(quotes.length + 1).padStart(4, '0')}`,
      date: new Date().toISOString(),
      clientName,
      items,
      total,
      status: 'en_attente',
    }
    persistQuotes([q, ...quotes])
    logActivity(`Devis ${q.ref} créé (${fmtDH(total)})`)
    return q
  }

  const setQuoteStatus = (id: string, status: Quote['status']) => {
    persistQuotes(quotes.map((q) => (q.id === id ? { ...q, status } : q)))
  }

  const deleteQuote = (id: string) => {
    persistQuotes(quotes.filter((q) => q.id !== id))
  }

  // ---- Cash register ----
  const addCashEntry = (type: CashEntry['type'], label: string, amount: number) => {
    persistCash([{ id: uid(), date: new Date().toISOString(), type, label, amount }, ...cash])
    logActivity(`${type === 'depense' ? 'Dépense' : 'Recette'} : ${label} (${fmtDH(amount)})`)
  }

  const openSession = (openingAmount: number) => {
    const s: RegisterSession = { id: uid(), openedAt: new Date().toISOString(), openingAmount }
    persistSessions([s, ...sessions])
    logActivity(`Ouverture de caisse (${fmtDH(openingAmount)})`)
  }

  const currentSession = sessions.find((s) => !s.closedAt) ?? null

  const expectedCash = (session: RegisterSession) => {
    const since = session.openedAt
    const cashSales = sales
      .filter((s) => s.date >= since && (s.payment === 'especes' || s.payment === 'mixte'))
      .reduce((a, s) => a + s.total, 0)
    const dep = cash.filter((c) => c.date >= since && c.type === 'depense').reduce((a, c) => a + c.amount, 0)
    const rec = cash.filter((c) => c.date >= since && c.type === 'recette').reduce((a, c) => a + c.amount, 0)
    return session.openingAmount + cashSales + rec - dep
  }

  const closeSession = (closingAmount: number) => {
    if (!currentSession) return
    const expected = expectedCash(currentSession)
    persistSessions(
      sessions.map((s) =>
        s.id === currentSession.id
          ? { ...s, closedAt: new Date().toISOString(), closingAmount, expectedAmount: expected }
          : s
      )
    )
    logActivity(`Fermeture de caisse — compté ${fmtDH(closingAmount)}, attendu ${fmtDH(expected)}`)
  }

  // ---- Users ----
  const addUser = (data: Omit<AppUser, 'id'>) => persistUsers([{ ...data, id: uid() }, ...users])
  const updateUser = (id: string, data: Partial<AppUser>) =>
    persistUsers(users.map((u) => (u.id === id ? { ...u, ...data } : u)))
  const deleteUser = (id: string) => persistUsers(users.filter((u) => u.id !== id))

  // ---- Attributes ----
  const attrActions = (list: Attribute[], persist: (v: Attribute[]) => void) => ({
    add: (name: string) => persist([{ id: uid(), name: name.trim() }, ...list]),
    rename: (id: string, name: string) => persist(list.map((a) => (a.id === id ? { ...a, name } : a))),
    remove: (id: string) => persist(list.filter((a) => a.id !== id)),
  })

  return {
    ready,
    products,
    sales,
    clients,
    suppliers,
    movements,
    purchases,
    quotes,
    returns,
    cash,
    sessions,
    users,
    activity,
    categories,
    brands,
    units,
    clientPayments,
    loyaltyMovements,
    supplierPayments,
    expenses,
    settings,
    currentSession,
    expectedCash,
    addProduct,
    updateProduct,
    deleteProduct,
    importProducts,
    addMovement,
    adjustStock,
    applyInventory,
    recordSale,
    recordReturn,
    addClient,
    updateClient,
    deleteClient,
    settleCredit,
    redeemPoints,
    addSupplier,
    updateSupplier,
    deleteSupplier,
    paySupplier,
    addPurchase,
    receivePurchase,
    payPurchase,
    returnPurchase,
    addQuote,
    setQuoteStatus,
    deleteQuote,
    addCashEntry,
    openSession,
    closeSession,
    addUser,
    updateUser,
    deleteUser,
    addExpense,
    markExpensePaid,
    deleteExpense,
    categoryActions: attrActions(categories, persistCategories),
    brandActions: attrActions(brands, persistBrands),
    unitActions: attrActions(units, persistUnits),
    saveSettings,
  }
}
