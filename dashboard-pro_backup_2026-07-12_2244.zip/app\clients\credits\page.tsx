'use client'

import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { AlertTriangle, HandCoins, Search, Wallet } from 'lucide-react'
import AppShell from '@/components/AppShell'
import Modal from '@/components/Modal'
import Select from '@/components/Select'
import { useToast } from '@/components/Toast'
import { fmtDH, useDroguerie, type Client } from '@/lib/store'

type Status = 'En cours' | 'Partiellement payé' | 'Soldé' | 'En retard'

const STATUS_CHIP: Record<Status, string> = {
  'En cours': 'bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-sky-200 dark:border-sky-500/20',
  'Partiellement payé': 'bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-200 dark:border-amber-500/20',
  'Soldé': 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-500/20',
  'En retard': 'bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-200 dark:border-rose-500/20',
}

function Content() {
  const { ready, clients, clientPayments, settleCredit } = useDroguerie()
  const toast = useToast()
  const [query, setQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState('Tous')
  const [settleTarget, setSettleTarget] = useState<Client | null>(null)
  const [settleAmount, setSettleAmount] = useState('')

  if (!ready) {
    return <div className="flex h-64 items-center justify-center text-sm text-gray-400 dark:text-zinc-500">Chargement…</div>
  }

  const now = new Date()

  const statusOf = (c: Client): Status => {
    if (c.credit === 0) return 'Soldé'
    if (c.creditDueDate && new Date(c.creditDueDate) < now) return 'En retard'
    const hasPayment = clientPayments.some((p) => p.clientId === c.id)
    return hasPayment ? 'Partiellement payé' : 'En cours'
  }

  const withCredit = clients.filter((c) => c.credit > 0)
  const totalOutstanding = withCredit.reduce((a, c) => a + c.credit, 0)
  const overdueCount = withCredit.filter((c) => statusOf(c) === 'En retard').length

  const visible = withCredit
    .filter((c) => statusFilter === 'Tous' || statusOf(c) === statusFilter)
    .filter((c) => {
      const q = query.trim().toLowerCase()
      return !q || c.name.toLowerCase().includes(q) || c.phone.includes(q)
    })
    .sort((a, b) => b.credit - a.credit)

  const openSettle = (c: Client) => {
    setSettleTarget(c)
    setSettleAmount(String(c.credit))
  }

  const confirmSettle = () => {
    if (!settleTarget) return
    const amount = parseFloat(settleAmount.replace(',', '.')) || 0
    if (amount <= 0) {
      toast('Montant invalide', 'error')
      return
    }
    settleCredit(settleTarget.id, amount)
    toast(`✓ Règlement de ${fmtDH(Math.min(amount, settleTarget.credit))} enregistré`)
    setSettleTarget(null)
  }

  const cards = [
    { label: 'Clients avec crédit', value: String(withCredit.length), icon: Wallet, cls: 'bg-amber-50 dark:bg-amber-500/10 text-amber-500' },
    { label: 'Total encours', value: fmtDH(totalOutstanding), icon: HandCoins, cls: 'bg-rose-50 dark:bg-rose-500/10 text-rose-500 dark:text-rose-400' },
    { label: 'En retard', value: String(overdueCount), icon: AlertTriangle, cls: overdueCount > 0 ? 'bg-rose-50 dark:bg-rose-500/10 text-rose-500 dark:text-rose-400' : 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-500 dark:text-emerald-400' },
  ]

  return (
    <>
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
        <h1 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-3xl">Crédits clients</h1>
        <p className="mt-1 text-sm text-gray-500 dark:text-zinc-400">Suivi des soldes, échéances et statuts de paiement.</p>
      </motion.div>

      <div className="grid gap-4 sm:grid-cols-3">
        {cards.map((c, i) => (
          <motion.div
            key={c.label}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 * i, duration: 0.4 }}
            className="glass-card glass-card-hover p-5"
          >
            <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${c.cls}`}>
              <c.icon className="h-5 w-5" />
            </div>
            <p className="mt-4 text-[13px] font-medium text-gray-500 dark:text-zinc-400">{c.label}</p>
            <p className="mt-1 text-[22px] font-bold leading-none tracking-tight text-gray-900 dark:text-white tabular-nums">
              {c.value}
            </p>
          </motion.div>
        ))}
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <div className="relative min-w-[220px] flex-1 sm:max-w-xs">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Nom ou téléphone…"
            className="input-field pl-10"
          />
        </div>
        <Select
          value={statusFilter}
          onChange={setStatusFilter}
          options={['Tous', 'En cours', 'Partiellement payé', 'En retard', 'Soldé']}
          className="w-auto min-w-[200px]"
        />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15, duration: 0.4 }}
        className="glass-card overflow-hidden"
      >
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px]">
            <thead>
              <tr className="border-b border-gray-100 dark:border-white/10 text-left text-[11px] font-bold uppercase tracking-wider text-gray-400 dark:text-zinc-500">
                <th className="px-5 py-3.5">Client</th>
                <th className="px-5 py-3.5">Solde restant</th>
                <th className="px-5 py-3.5">Plafond</th>
                <th className="px-5 py-3.5">Date d&apos;échéance</th>
                <th className="px-5 py-3.5">Statut</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {visible.map((c) => {
                const status = statusOf(c)
                return (
                  <tr key={c.id} className="border-b border-gray-50 dark:border-white/5 transition-colors hover:bg-amber-50/40 dark:hover:bg-white/5">
                    <td className="px-5 py-3.5">
                      <p className="text-sm font-semibold text-gray-900 dark:text-white">{c.name}</p>
                      <p className="text-xs text-gray-400 dark:text-zinc-500 tabular-nums">{c.phone || '—'}</p>
                    </td>
                    <td className="px-5 py-3.5 text-sm font-bold text-rose-600 dark:text-rose-400 tabular-nums">
                      {fmtDH(c.credit)}
                    </td>
                    <td className="px-5 py-3.5 text-sm text-gray-600 dark:text-zinc-400 tabular-nums">
                      {c.creditLimit > 0 ? fmtDH(c.creditLimit) : '—'}
                    </td>
                    <td className="px-5 py-3.5 text-sm text-gray-600 dark:text-zinc-400">
                      {c.creditDueDate
                        ? new Date(c.creditDueDate).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })
                        : '—'}
                    </td>
                    <td className="px-5 py-3.5">
                      <span className={`rounded-lg border px-2 py-1 text-xs font-bold ${STATUS_CHIP[status]}`}>{status}</span>
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <button onClick={() => openSettle(c)} className="btn-secondary !h-8 !px-2.5 text-xs">
                        <HandCoins className="h-3.5 w-3.5" />
                        Régler
                      </button>
                    </td>
                  </tr>
                )
              })}
              {visible.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-5 py-10 text-center text-sm text-gray-400 dark:text-zinc-500">
                    Aucun crédit dans cette vue
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </motion.div>

      <Modal open={!!settleTarget} onClose={() => setSettleTarget(null)} title="Encaisser un règlement" maxWidth="max-w-sm">
        <p className="text-sm text-gray-600 dark:text-zinc-400">
          <span className="font-semibold text-gray-900 dark:text-white">{settleTarget?.name}</span> doit{' '}
          <span className="font-bold text-rose-600 dark:text-rose-400 tabular-nums">{fmtDH(settleTarget?.credit ?? 0)}</span>
        </p>
        <div className="mt-4">
          <label className="field-label">Montant reçu (DH)</label>
          <input
            type="number"
            min="0"
            value={settleAmount}
            onChange={(e) => setSettleAmount(e.target.value)}
            className="input-field"
            autoFocus
          />
        </div>
        <div className="mt-5 grid grid-cols-2 gap-3">
          <button onClick={() => setSettleTarget(null)} className="btn-secondary">
            Annuler
          </button>
          <button onClick={confirmSettle} className="btn-primary">
            <HandCoins className="h-4 w-4" />
            Encaisser
          </button>
        </div>
      </Modal>
    </>
  )
}

export default function CreditsPage() {
  return (
    <AppShell>
      <Content />
    </AppShell>
  )
}
