'use client'

import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { Banknote, FileWarning, Search } from 'lucide-react'
import AppShell from '@/components/AppShell'
import Modal from '@/components/Modal'
import Select from '@/components/Select'
import { useToast } from '@/components/Toast'
import { fmtDH, useDroguerie, type Purchase } from '@/lib/store'

function Content() {
  const { ready, purchases, payPurchase } = useDroguerie()
  const toast = useToast()
  const [query, setQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState('Toutes')
  const [payTarget, setPayTarget] = useState<Purchase | null>(null)
  const [payAmount, setPayAmount] = useState('')
  const [method, setMethod] = useState<'especes' | 'carte' | 'virement' | 'cheque'>('especes')

  if (!ready) {
    return <div className="flex h-64 items-center justify-center text-sm text-gray-400 dark:text-zinc-500">Chargement…</div>
  }

  const invoices = purchases.filter((p) => p.status === 'recue' || p.status === 'retournee')
  const unpaid = invoices.reduce((a, p) => a + (p.total - p.paid), 0)

  const visible = invoices
    .filter((p) => {
      if (statusFilter === 'Payées') return p.paid >= p.total
      if (statusFilter === 'Impayées') return p.paid === 0
      if (statusFilter === 'Partielles') return p.paid > 0 && p.paid < p.total
      return true
    })
    .filter((p) => {
      const q = query.trim().toLowerCase()
      return !q || p.ref.toLowerCase().includes(q) || p.supplierName.toLowerCase().includes(q)
    })

  const confirmPay = () => {
    if (!payTarget) return
    const amount = parseFloat(payAmount.replace(',', '.')) || 0
    if (amount <= 0) {
      toast('Montant invalide', 'error')
      return
    }
    payPurchase(payTarget.id, amount, method)
    toast(`✓ Paiement enregistré — ${payTarget.ref}`)
    setPayTarget(null)
    setMethod('especes')
  }

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex flex-wrap items-end justify-between gap-4"
      >
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-3xl">Factures fournisseurs</h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-zinc-400">
            Suivi des factures reçues et de leur règlement.
            {unpaid > 0 && <span className="ml-2 font-semibold text-rose-500 dark:text-rose-400">Impayé : {fmtDH(unpaid)}</span>}
          </p>
        </div>
      </motion.div>

      <div className="flex flex-wrap items-center gap-3">
        <div className="relative min-w-[220px] flex-1 sm:max-w-xs">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Référence ou fournisseur…"
            className="input-field pl-10"
          />
        </div>
        <Select
          value={statusFilter}
          onChange={setStatusFilter}
          options={['Toutes', 'Payées', 'Partielles', 'Impayées']}
          className="w-auto min-w-[160px]"
        />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.4 }}
        className="glass-card overflow-hidden"
      >
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px]">
            <thead>
              <tr className="border-b border-gray-100 dark:border-white/10 text-left text-[11px] font-bold uppercase tracking-wider text-gray-400 dark:text-zinc-500">
                <th className="px-5 py-3.5">Référence</th>
                <th className="px-5 py-3.5">Fournisseur</th>
                <th className="px-5 py-3.5">Total</th>
                <th className="px-5 py-3.5">Payé</th>
                <th className="px-5 py-3.5">Reste dû</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {visible.map((p) => {
                const reste = p.total - p.paid
                return (
                  <tr key={p.id} className="border-b border-gray-50 dark:border-white/5 transition-colors hover:bg-amber-50/40 dark:hover:bg-white/5">
                    <td className="px-5 py-3.5 text-sm font-bold text-gray-900 dark:text-white">{p.ref}</td>
                    <td className="px-5 py-3.5 text-sm text-gray-700 dark:text-zinc-300">{p.supplierName}</td>
                    <td className="px-5 py-3.5 text-sm font-bold text-gray-900 dark:text-white tabular-nums">{fmtDH(p.total)}</td>
                    <td className="px-5 py-3.5 text-sm font-semibold text-emerald-600 dark:text-emerald-400 tabular-nums">{fmtDH(p.paid)}</td>
                    <td className="px-5 py-3.5">
                      {reste > 0 ? (
                        <span className="rounded-lg border border-rose-200 dark:border-rose-500/20 bg-rose-50 dark:bg-rose-500/10 px-2 py-1 text-xs font-bold text-rose-600 dark:text-rose-400 tabular-nums">
                          {fmtDH(reste)}
                        </span>
                      ) : (
                        <span className="rounded-lg border border-emerald-200 dark:border-emerald-500/20 bg-emerald-50 dark:bg-emerald-500/10 px-2 py-1 text-xs font-bold text-emerald-600 dark:text-emerald-400">
                          Soldée
                        </span>
                      )}
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      {reste > 0 && (
                        <button
                          onClick={() => {
                            setPayTarget(p)
                            setPayAmount(String(reste))
                          }}
                          className="btn-primary !h-8 !px-2.5 text-xs"
                        >
                          <Banknote className="h-3.5 w-3.5" />
                          Payer
                        </button>
                      )}
                    </td>
                  </tr>
                )
              })}
              {visible.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-5 py-10 text-center text-sm text-gray-400 dark:text-zinc-500">
                    <FileWarning className="mx-auto mb-2 h-6 w-6 text-gray-300" />
                    Aucune facture dans cette vue
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Pay modal */}
      <Modal open={!!payTarget} onClose={() => setPayTarget(null)} title="Payer la facture" maxWidth="max-w-sm">
        <p className="text-sm text-gray-600 dark:text-zinc-400">
          <span className="font-semibold text-gray-900 dark:text-white">{payTarget?.ref}</span> — reste à payer :{' '}
          <span className="font-bold text-rose-500 dark:text-rose-400 tabular-nums">
            {fmtDH((payTarget?.total ?? 0) - (payTarget?.paid ?? 0))}
          </span>
        </p>
        <div className="mt-4">
          <label className="field-label">Montant (DH)</label>
          <input
            type="number"
            min="0"
            value={payAmount}
            onChange={(e) => setPayAmount(e.target.value)}
            className="input-field"
            autoFocus
          />
        </div>
        <div className="mt-4">
          <label className="field-label">Mode de paiement</label>
          <Select
            value={method}
            onChange={(v) => setMethod(v as typeof method)}
            options={[
              { value: 'especes', label: 'Espèces' },
              { value: 'carte', label: 'Carte bancaire' },
              { value: 'virement', label: 'Virement' },
              { value: 'cheque', label: 'Chèque' },
            ]}
          />
        </div>
        <div className="mt-5 grid grid-cols-2 gap-3">
          <button onClick={() => setPayTarget(null)} className="btn-secondary">
            Annuler
          </button>
          <button onClick={confirmPay} className="btn-primary">
            <Banknote className="h-4 w-4" />
            Payer
          </button>
        </div>
      </Modal>
    </>
  )
}

export default function FacturesFournisseursPage() {
  return (
    <AppShell>
      <Content />
    </AppShell>
  )
}
